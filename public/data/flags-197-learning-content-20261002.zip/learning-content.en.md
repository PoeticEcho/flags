# 197-country learning content

Edition: 2026-10-02-education

## Afghanistan · AF

Capital / seat: Kabul

1. Afghanistan is in Asia. Its capital is Kabul.

2. The Minaret of Jam is a brick tower about 65 metres tall. Repeating brick patterns and blue tiles show the skill of its builders.

3. The tower stands in a mountain valley where the Hari Rud and Jam rivers meet. A place where rivers join is called a confluence.

Explorer words: Kabul · Minaret of Jam · Hari Rud River · Jam River · bricks · blue tiles · repeating patterns · mountain valley · confluence · 12th-century architecture

Postcard scene: Minaret and Archaeological Remains of Jam

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/af/
- https://whc.unesco.org/en/list/211/

## Albania · AL

Capital / seat: Tirana

1. Albania is in Europe. Its capital is Tirana.

2. Butrint preserves a theatre and building remains from Greek and Roman times. One place can reveal how people lived in different periods.

3. Butrint's hill is surrounded by a lake and the Vivari Channel. Its mosaics are pictures made from many small pieces.

Explorer words: Tirana · Butrint · Lake Butrint · Vivari Channel · ancient theatre · mosaics · ancient Greece · Roman period · archaeology · wetlands

Postcard scene: Butrint

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/al/
- https://whc.unesco.org/en/list/570/

## Algeria · DZ

Capital / seat: Algiers

1. Algeria is in Africa. Its capital is Algiers.

2. The Kasbah is an old district of Algiers overlooking the Mediterranean. Its citadel, mosques and palaces tell the story of the city's streets.

3. The Kasbah is an example of a traditional town called a medina. The arrangement of homes and streets records the history of community life.

Explorer words: Algiers · Kasbah of Algiers · Mediterranean Sea · medina · citadel · mosques · palaces · historic streets · coastal city · community

Postcard scene: Kasbah of Algiers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dz/
- https://whc.unesco.org/en/list/565/

## Andorra · AD

Capital / seat: Andorra la Vella

1. Andorra is in Europe. Its capital is Andorra la Vella.

2. The Madriu-Perafita-Claror Valley lies in the Pyrenees. High pastures and wooded valleys show a landscape shaped by ancient glaciers.

3. Stone paths, terraced fields and summer homes remain in the valley. They reveal how people adapted to raising livestock in the mountains.

Explorer words: Andorra la Vella · Madriu Valley · Pyrenees · pastures · glaciers · stone paths · terraced fields · summer homes · pastoralism · Madriu-Perafita-Claror Valley

Postcard scene: Madriu-Perafita-Claror Valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ad/
- https://whc.unesco.org/en/list/1160/

## Angola · AO

Capital / seat: Luanda

1. Angola is in Africa. Its capital is Luanda.

2. Mbanza Kongo was the capital of the old Kingdom of Kongo. Royal residences and court sites show how this centre of government was organised.

3. The town stands on a plateau. Buildings made with local materials and later stone structures record encounters between different cultures.

Explorer words: Luanda · Mbanza Kongo · Kingdom of Kongo · plateau · royal residence · customary court · stone buildings · local materials · cultural exchange · archaeological remains

Postcard scene: Mbanza Kongo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ao/
- https://whc.unesco.org/en/list/1511/

## Antigua and Barbuda · AG

Capital / seat: Saint John's

1. Antigua and Barbuda is in Americas. Its capital is Saint John's.

2. English Harbour on Antigua is a deep, narrow bay surrounded by hills. This sheltered setting helped make it a place for repairing ships.

3. The old dockyard buildings preserve the history of ships and harbours. They also remind us of the enslaved Africans forced to help build them.

Explorer words: Saint John's · Antigua · Barbuda · English Harbour · Antigua Naval Dockyard · bay · harbour · ship repair · historic storehouses · history of labour

Postcard scene: Antigua Naval Dockyard

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ag/
- https://whc.unesco.org/en/list/1499/

## Argentina · AR

Capital / seat: Buenos Aires

1. Buenos Aires is Argentina’s capital. Its Obelisk stands on the wide Avenida 9 de Julio.

2. The Andes run along Argentina’s west, and Aconcagua is the highest mountain in the Americas.

3. Tango is a style of dance and music that grew around the Río de la Plata region, including Buenos Aires.

Explorer words: Buenos Aires · Obelisk · Andes · Aconcagua · Patagonia · Iguazú Falls · tango · mate · Spanish · football

Postcard scene: Buenos Aires Obelisk & La Boca

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Armenia · AM

Capital / seat: Yerevan

1. Armenia is in Asia. Its capital is Yerevan.

2. Echmiatsin's churches develop a design with a central dome. Comparing their shapes helps reveal changes in Armenian architecture.

3. Columns and foundations survive at Zvartnots. Archaeology studies such remains to help us understand buildings that no longer stand.

Explorer words: Yerevan · Echmiatsin · Zvartnots · cathedral · dome · columns · foundations · Armenian architecture · churches · archaeology

Postcard scene: Echmiatsin Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/am/
- https://whc.unesco.org/en/list/1011/

## Australia · AU

Capital / seat: Canberra

1. Canberra is Australia’s capital. The Sydney Opera House roof looks like sails or shells.

2. A huge reef off northeast Australia is home to corals and many sea creatures.

3. Australia is home to the ancient and diverse cultures of Aboriginal and Torres Strait Islander peoples.

Explorer words: Canberra · Sydney · Opera House · Great Barrier Reef · Uluru · kangaroo · koala · meat pie · First Nations cultures · cricket

Postcard scene: Sydney Opera House & Harbour Bridge

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Austria · AT

Capital / seat: Vienna

1. Austria is in Europe. Its capital is Vienna.

2. Vienna has long been a city of composers and performers. Its historic buildings, as well as its concerts, tell a story of cultural life.

3. Vienna's Ringstrasse is lined with grand buildings and parks. Palaces, gardens and architecture from different periods stand together in the historic centre.

Explorer words: Vienna · historic Vienna · Ringstrasse · St Stephen's Cathedral · music · composers · palaces · gardens · Baroque architecture · city parks

Postcard scene: Historic Centre of Vienna — St Stephen's Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/at/
- https://whc.unesco.org/en/list/1033/

## Azerbaijan · AZ

Capital / seat: Baku

1. Azerbaijan is in Asia. Its capital is Baku.

2. Baku's walled city contains the Maiden Tower and Shirvanshahs' Palace. The stone tower and palace record the city's growth through different periods.

3. The old city, called Icheri Sheher, preserves historic defensive walls. Walls helped protect a town and organise the ways people entered it.

Explorer words: Baku · walled city of Baku · Maiden Tower · Shirvanshahs' Palace · Icheri Sheher · city walls · stone tower · old town · defensive architecture · cultural encounters

Postcard scene: Walled City of Baku — Maiden Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/az/
- https://whc.unesco.org/en/list/958/

## Bahamas · BS

Capital / seat: Nassau

1. Bahamas is in Americas. Its capital is Nassau.

2. Dean's Blue Hole is on Long Island in the Bahamas. Its deep coastal water appears a rich blue.

3. Low rock cliffs and a sandy beach border Dean's Blue Hole, beside turquoise shallow water.

Explorer words: Nassau · Long Island · Dean's Blue Hole · Limestone shore · Sandy beach · Turquoise shallows · water depth · blue hole · colour contrast · coastal landforms

Postcard scene: Dean's Blue Hole, Long Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bahamas.com/natural-wonders/deans-blue-hole

## Bahrain · BH

Capital / seat: Manama

1. Bahrain is in Asia. Its capital is Manama.

2. Layers left by generations of residents lie beneath Bahrain Fort. This kind of archaeological mound is called a tell, with different traces in each layer.

3. The area was a centre of the Dilmun civilisation and a trading port. Remains of homes, markets and religious buildings reveal trade and daily life.

Explorer words: Manama · Bahrain Fort · Dilmun civilisation · tell · archaeological layers · trading port · excavation · ancient house remains · markets · trade

Postcard scene: Qal’at al-Bahrain

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bh/
- https://whc.unesco.org/en/list/1192/

## Bangladesh · BD

Capital / seat: Dhaka

1. Bangladesh’s capital, Dhaka, is close to the Buriganga River.

2. Bangladesh lies in a broad delta shaped by the Ganges and Brahmaputra river systems.

3. The Sundarbans mangrove forest is home to many plants and animals, including Bengal tigers.

Explorer words: Dhaka · Lalbagh Fort · Buriganga River · Sundarbans · Bengal tiger · rickshaw art · Bangla · hilsa · Jamdani weaving · Padma Bridge

Postcard scene: Lalbagh Fort

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Barbados · BB

Capital / seat: Bridgetown

1. Barbados is in Americas. Its capital is Bridgetown.

2. Bridgetown's old streets preserve buildings from the 17th to 19th centuries. Homes and public buildings record Atlantic trade and the colonial period.

3. Bridgetown's historic streets curve rather than following a straight grid. Street patterns show that towns can develop in different ways.

Explorer words: Bridgetown · historic Bridgetown · historic garrison · Atlantic Ocean · curving streets · town planning · public buildings · historic houses · trade · colonial period

Postcard scene: Historic Bridgetown and its Garrison

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bb/
- https://whc.unesco.org/en/list/1376/

## Belarus · BY

Capital / seat: Minsk

1. Belarus is in Europe. Its capital is Minsk.

2. Mir Castle combines Gothic, Renaissance and Baroque work added over time. One building can show how walls and windows changed across different periods.

3. Mir Castle was later restored after damage and war. Its preservation, together with the surrounding park, passes architecture and history to future generations.

Explorer words: Minsk · Mir Castle · Gothic style · Renaissance · Baroque style · castle towers · brick architecture · restoration · park · heritage conservation

Postcard scene: Mir Castle Complex

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/by/
- https://whc.unesco.org/en/list/625/

## Belgium · BE

Capital / seat: Brussels

1. Belgium is in Europe. Its capital is Brussels.

2. Brussels' Grand-Place is a square surrounded by historic buildings. Public buildings and merchants' houses reveal the life of the old city.

3. Buildings around the square largely preserve late-17th-century designs. Compare their roofs and facades to distinguish the buildings gathered around one square.

Explorer words: Brussels · Grand-Place · town square · town hall · merchants' houses · public buildings · facade · roof decorations · 17th century · urban life

Postcard scene: La Grand-Place, Brussels

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/be/
- https://whc.unesco.org/en/list/857/

## Belize · BZ

Capital / seat: Belmopan

1. Belize is in Americas. Its capital is Belmopan.

2. Belize's reef reserves include coral reefs, sandy islands and mangrove forests. Mangroves are trees that grow along shallow coastal waters.

3. The area provides important habitat for sea turtles and manatees. Protecting both reefs and coastal forests helps marine animals survive.

Explorer words: Belmopan · Belize Barrier Reef · coral · sand cays · mangroves · lagoon · sea turtles · manatee · habitat · marine ecosystem

Postcard scene: Belize Barrier Reef Reserve System

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bz/
- https://whc.unesco.org/en/list/764/

## Benin · BJ

Capital / seat: Porto-Novo

Porto-Novo is the official capital; many government offices are in Cotonou.

1. Porto-Novo is the official capital; many government offices are in Cotonou.

2. The Royal Palaces of Abomey were built by generations of rulers. Palaces within a shared enclosure record the history of the old kingdom.

3. Abomey's palaces used earthen walls and local materials. Building large structures with nearby resources is an important form of architectural knowledge.

Explorer words: Porto-Novo · Royal Palaces of Abomey · historic kingdom · earthen walls · local materials · palaces · enclosure walls · building materials · royal history · cultural heritage

Postcard scene: Royal Palaces of Abomey

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bj/
- https://whc.unesco.org/en/list/323/

## Bhutan · BT

Capital / seat: Thimphu

1. Bhutan is in Asia. Its capital is Thimphu.

2. Tashichho Dzong stands beside the Wang Chhu River in Thimphu. Bhutan's fortress-like dzongs serve as centres of administration and religion.

3. Tashichho Dzong has white walls and decorated wooden windows. At the Thimphu Tshechu festival, masked dances and performances pass on traditional stories.

Explorer words: Thimphu · Tashichho Dzong · Wang Chhu River · dzong · white walls · wooden windows · Thimphu Tshechu · masked dances · fortress architecture · Thimphu valley

Postcard scene: Thimphu valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thimphu.gov.bt/tashichho-dzong/

## Bolivia · BO

Capital / seat: Sucre

Sucre is the constitutional capital; La Paz is the seat of government and parliament.

1. Sucre is Bolivia’s constitutional capital. The government and parliament are in La Paz, so the two cities have different roles.

2. Sucre’s UNESCO-listed historic centre preserves white-walled buildings, squares and churches.

3. Tiwanaku preserves an ancient Andean civilisation, with stone buildings and carvings.

Explorer words: Sucre · La Paz · constitutional capital · historic Sucre · Tiwanaku · Andes · Lake Titicaca · stone architecture · stone carvings · ancient civilisation

Postcard scene: City of Potosí

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bo/
- https://whc.unesco.org/en/list/566/
- https://whc.unesco.org/en/list/567/

## Bosnia and Herzegovina · BA

Capital / seat: Sarajevo

1. Bosnia and Herzegovina is in Europe. Its capital is Sarajevo.

2. Mostar's Old Bridge connects the banks of the Neretva River. Bridges provide important routes linking people across rivers and deep valleys.

3. The bridge was destroyed in war and rebuilt with international help. Its reconstruction also represents the possibility of different cultures living together.

Explorer words: Sarajevo · Mostar · Stari Most · Neretva River · stone bridge · arch · valley · reconstruction · historic houses · Old Bridge Area of the Old City of Mostar

Postcard scene: Old Bridge Area of the Old City of Mostar

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ba/
- https://whc.unesco.org/en/list/946/

## Botswana · BW

Capital / seat: Gaborone

1. Gaborone is Botswana’s capital. Botswana is a landlocked country in southern Africa.

2. The Okavango Delta is an inland wetland whose waters do not reach the sea. Floods arrive during the dry season and support many animals.

3. The Tsodilo Hills preserve ancient rock paintings and archaeological sites that tell the region’s long human history.

Explorer words: Gaborone · Okavango Delta · Okavango River · wetlands · inland delta · Tsodilo · rock paintings · Kalahari · elephants · lions

Postcard scene: Okavango Delta

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bw/
- https://whc.unesco.org/en/list/1432/
- https://whc.unesco.org/en/list/1021/

## Brazil · BR

Capital / seat: Brasília

1. Brazil is the largest country in South America, and Brasília is its capital.

2. The Amazon rainforest is home to a huge variety of plants and animals.

3. Portuguese is spoken in Brazil, and Rio de Janeiro is known for its coast and mountains.

Explorer words: Brasília · Amazon · Rio de Janeiro · Christ the Redeemer · Atlantic Ocean · jaguar · Portuguese · samba · coffee · football

Postcard scene: Christ the Redeemer

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Brunei · BN

Capital / seat: Bandar Seri Begawan

1. Brunei is in Asia. Its capital is Bandar Seri Begawan.

2. Kampong Ayer is a water village near the capital on the Brunei River. Homes stand on stilts and are connected by wooden paths and bridges.

3. Boats are important transport in Kampong Ayer. Its cultural gallery explains the history and everyday life of communities living beside the river.

Explorer words: Bandar Seri Begawan · Kampong Ayer · Brunei River · water village · stilt houses · wooden bridges · boats · river life · cultural gallery · Bandar Seri Begawan riverfront

Postcard scene: Bandar Seri Begawan riverfront

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bruneitourism.com/places/kampong-ayer/

## Bulgaria · BG

Capital / seat: Sofia

1. Bulgaria is in Europe. Its capital is Sofia.

2. Rila Monastery began in the 10th century. After serious fire damage, it was rebuilt in the 19th century, continuing its older traditions.

3. Its buildings reflect a period of renewed Bulgarian cultural life. Repairing and protecting old places is another way of passing on history.

Explorer words: Sofia · Rila Monastery · St John of Rila · monastery · 10th century · 19th century · rebuilding · Bulgarian culture · religious architecture · cultural preservation

Postcard scene: Rila Monastery

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bg/
- https://whc.unesco.org/en/list/216/

## Burkina Faso · BF

Capital / seat: Ouagadougou

1. Burkina Faso is in Africa. Its capital is Ouagadougou.

2. The Royal Court of Tiébélé has earthen houses joined by narrow passages. Their arrangement reflects how the Kasena community lives together.

3. Women decorate the walls with meaningful patterns and pass on their skills. Decorating a home preserves a living tradition as well as creating beauty.

Explorer words: Ouagadougou · Tiébélé · Kasena people · earthen houses · wall patterns · traditional skills · passageways · courtyards · symbols · living tradition

Postcard scene: Royal Court of Tiébélé

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bf/
- https://whc.unesco.org/en/list/1713/

## Burundi · BI

Capital / seat: Gitega

1. Burundi is in Africa. Its capital is Gitega.

2. Burundi's royal drum tradition combines coordinated drumming and dancing. Songs and poetry join the performance to tell the community's stories.

3. The performance is an art of movement as well as sound. Keeping a shared rhythm means listening to others and watching their movements.

Explorer words: Gitega · royal drums · drumming · rhythm · dance · songs · poetry · community · traditional performance · Gitega and its surroundings

Postcard scene: Gitega and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/decisions/9.COM/10.10

## Cambodia · KH

Capital / seat: Phnom Penh

1. Cambodia is in Asia. Its capital is Phnom Penh.

2. Angkor contains remains of several capitals of the Khmer Empire. Angkor Wat and the Bayon display architecture and sculpture from different periods.

3. Forests surround Angkor's monuments. Protecting buildings and their natural setting helps preserve carved stonework and the landscape around it.

Explorer words: Phnom Penh · Angkor · Angkor Wat · Bayon · Khmer Empire · temples · stone carvings · ancient capitals · forest · site conservation

Postcard scene: Angkor

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kh/
- https://whc.unesco.org/en/list/668/

## Cameroon · CM

Capital / seat: Yaoundé

1. Cameroon is in Africa. Its capital is Yaoundé.

2. The Dja Faunal Reserve is a rainforest almost surrounded by the Dja River. The river forms a boundary and provides water and habitat for wildlife.

3. Many primates and other mammals live in Dja. Biodiversity describes the variety of living things found together in a place.

Explorer words: Yaoundé · Dja Faunal Reserve · Dja River · rainforest · primates · mammals · biodiversity · habitat · river boundary · nature conservation

Postcard scene: Dja Faunal Reserve

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cm/
- https://whc.unesco.org/en/list/407/

## Canada · CA

Capital / seat: Ottawa

1. Ottawa is Canada’s capital. Niagara Falls lies on the border between Canada and the United States.

2. Canada borders the Pacific, Atlantic and Arctic Oceans.

3. Canada is home to First Nations, Inuit and Métis communities, with many cultures and languages.

Explorer words: Ottawa · Niagara Falls · maple leaf · Rocky Mountains · Arctic Ocean · beaver · ice hockey · poutine · French · Inuit

Postcard scene: Niagara Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Cape Verde · CV

Capital / seat: Praia

1. Cape Verde is in Africa. Its capital is Praia.

2. Cidade Velha on Santiago Island preserves historic streets, churches and a royal fortress. It is a different town from today's capital, Praia.

3. This port town records Atlantic trade and the colonial period. Learning its history means remembering people's lives as well as its buildings.

Explorer words: Praia · Santiago Island · Cidade Velha · Ribeira Grande · Atlantic Ocean · royal fortress · port town · historic streets · churches · colonial period

Postcard scene: Cidade Velha, Historic Centre of Ribeira Grande

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cv/
- https://whc.unesco.org/en/list/1310/

## Central African Republic · CF

Capital / seat: Bangui

1. Central African Republic is in Africa. Its capital is Bangui.

2. The Sangha Trinational forests are protected by the Central African Republic, Cameroon and Congo. Connected parks protect wildlife habitat across borders.

3. Grassy clearings occur within the forests, where forest elephants and gorillas live. Forest and open areas provide different kinds of habitat.

Explorer words: Bangui · Sangha River · Sangha Trinational · forest elephant · western lowland gorilla · tropical forest · forest clearings · national parks · borders · habitat connectivity

Postcard scene: Sangha Trinational

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cf/
- https://whc.unesco.org/en/list/1380/

## Chad · TD

Capital / seat: N'Djamena

1. Chad is in Africa. Its capital is N'Djamena.

2. Water and wind have shaped Ennedi's sandstone into cliffs and natural arches. The wearing away of rock and soil is called erosion.

3. Ennedi's caves and rocks preserve ancient paintings and carvings. Even in the dry Sahara, water in its valleys supports people and animals.

Explorer words: N'Djamena · Ennedi · Sahara · sandstone · natural arches · erosion · cliffs · rock art · caves · Ennedi Massif: Natural and Cultural Landscape

Postcard scene: Ennedi Massif: Natural and Cultural Landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/td/
- https://whc.unesco.org/en/list/1475/

## Chile · CL

Capital / seat: Santiago

1. Chile’s capital, Santiago, sits in a broad valley facing the Andes Mountains.

2. Moai statues made by the Rapa Nui people stand on Rapa Nui Island in the Pacific.

3. Chile is a long country stretching north to south along the Pacific coast.

Explorer words: Santiago · Rapa Nui · moai · Pacific Ocean · Andes Mountains · Atacama Desert · copper · empanada · Spanish · Andean condor

Postcard scene: Moai of Rapa Nui

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## China · CN

Capital / seat: Beijing

1. Beijing is China’s capital. China is a very large country with many kinds of landscapes and climates.

2. The Great Wall is a long system of old walls and watchtowers that crosses mountain ridges.

3. Giant pandas live in mountain bamboo forests in China.

Explorer words: Beijing · Great Wall · giant panda · Yangtze River · Yellow River · dumplings · Peking duck · Mandarin Chinese · Spring Festival · paper cutting

Postcard scene: Great Wall

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Colombia · CO

Capital / seat: Bogotá

1. Colombia’s capital, Bogotá, sits on a high plateau in the Andes.

2. Cartagena’s walled Old Town lies on Colombia’s Caribbean coast.

3. Colombia grows much of its fragrant coffee in mountain regions.

Explorer words: Bogotá · Cartagena · walled city · Caribbean Sea · Andes Mountains · coffee · arepa · Spanish · emerald · Andean condor

Postcard scene: Cartagena Walled City

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Comoros · KM

Capital / seat: Moroni

1. Comoros is in Africa. Its capital is Moroni.

2. Comoros' historic sultanate towns grew through Indian Ocean trade and migration. Their buildings and streets record meetings between different cultures.

3. These towns are spread across several islands and retain living social traditions. Different islands within one country can have distinct histories and ways of life.

Explorer words: Moroni · sultanate towns · medinas · Indian Ocean · island towns · maritime trade · migration · city-states · traditional customs · cultural exchange

Postcard scene: The Medinas of the Historic Sultanates of the Comoros

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/km/
- https://whc.unesco.org/en/list/1768/

## Costa Rica · CR

Capital / seat: San José

1. San José is Costa Rica’s capital. Costa Rica is in Central America, which is part of North America.

2. Costa Rica’s tropical forests and national parks shelter sloths, monkeys and many birds. Protected areas help conserve this wildlife.

3. The Diquís region has large stone spheres made by earlier communities. Archaeological sites with these spheres are protected as World Heritage.

Explorer words: San José · Central America · tropical forest · sloth · monkey · national parks · Pacific Ocean · Caribbean Sea · Diquís · stone spheres

Postcard scene: Arenal Volcano

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cr/
- https://www.visitcostarica.com/where-to-go/central-pacific
- https://whc.unesco.org/en/list/1453/

## Croatia · HR

Capital / seat: Zagreb

1. Croatia is in Europe. Its capital is Zagreb.

2. Plitvice's lakes and waterfalls are linked by natural barriers formed as minerals build up in the water. Water continues to reshape this landscape.

3. Bears, wolves and many birds live in the surrounding forests. Protecting the woods as well as the lakes keeps wildlife habitats connected.

Explorer words: Zagreb · Plitvice Lakes · waterfalls · limestone · natural barriers · minerals · bears · wolves · forests · Dubrovnik

Postcard scene: Dubrovnik

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hr/
- https://whc.unesco.org/en/list/98/

## Cuba · CU

Capital / seat: Havana

1. Havana is Cuba’s capital. Old Havana preserves historic squares, fortifications and buildings from different periods.

2. Viñales Valley has rounded limestone hills called mogotes, with farming villages and fields between them.

3. Cuba is an island country in the Caribbean. Old Havana and Viñales Valley are UNESCO World Heritage sites.

Explorer words: Havana · Old Havana · Viñales Valley · mogotes · limestone · Caribbean Sea · island country · fortifications · squares · Spanish

Postcard scene: Old Havana

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cu/
- https://whc.unesco.org/en/list/204/
- https://whc.unesco.org/en/list/840/

## Cyprus · CY

Capital / seat: Nicosia

1. Cyprus is in Europe. Its capital is Nicosia.

2. Choirokoitia is a village site from the Neolithic period. House remains and excavated objects reveal daily life before written records.

3. Parts of the site are left unexcavated for future research. Even a small object underground can be an important clue to past life.

Explorer words: Nicosia · Choirokoitia · Neolithic period · house remains · excavated objects · prehistory · archaeology · village · Mediterranean Sea · Paphos mosaics

Postcard scene: Paphos mosaics

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cy/
- https://whc.unesco.org/en/list/848/

## Czechia · CZ

Capital / seat: Prague

1. Prague is Czechia’s capital. The Vltava River flows through the city, with historic buildings on both banks.

2. Charles Bridge is a historic stone bridge across the Vltava. It offers views of Prague Castle and the city’s towers.

3. Prague’s UNESCO-listed historic centre preserves Gothic, Renaissance and Baroque buildings together.

Explorer words: Prague · Charles Bridge · Vltava River · Prague Castle · St Vitus Cathedral · Old Town · Gothic architecture · Renaissance · Baroque · Czech

Postcard scene: Charles Bridge, Prague

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cz/
- https://whc.unesco.org/en/list/616/
- https://prague.eu/en/objevujte/charles-bridge-karluv-most/

## Denmark · DK

Capital / seat: Copenhagen

1. Copenhagen is Denmark’s capital. Nyhavn harbour is lined with colourful houses and boats.

2. Hans Christian Andersen was a Danish storyteller. Copenhagen’s Little Mermaid statue was inspired by his fairy tale.

3. Many people in Copenhagen cycle to school or work, using the city’s connected cycling routes.

Explorer words: Copenhagen · Nyhavn · Little Mermaid statue · Hans Christian Andersen · fairy tales · bicycles · harbour · canal · boats · Danish

Postcard scene: Nyhavn, Copenhagen

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dk/
- https://www.visitdenmark.com/denmark/plan-your-trip/nyhavn-harbour-gdk426287
- https://www.visitdenmark.com/denmark/plan-your-trip/the-little-mermaid-gdk586951
- https://www.visitcopenhagen.com/

## Djibouti · DJ

Capital / seat: Djibouti

1. Djibouti is in Africa. Its capital is Djibouti.

2. Lake Assal lies below sea level. Sea level gives us a reference for comparing whether land is higher or lower.

3. Djibouti has traditions of telling stories through songs, poetry and dance. The ways of life of different communities contribute to its varied culture.

Explorer words: Djibouti · Lake Assal · sea level · depression · lake · songs · poetry · dance · nomadic traditions · cultural encounters

Postcard scene: Lake Assal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guide.visitdjibouti.dj/

## Dominica · DM

Capital / seat: Roseau

1. Dominica is in Americas. Its capital is Roseau.

2. Morne Trois Pitons National Park combines tropical forest and volcanic landscapes. Steep valleys and lakes show the variety of a volcanic island.

3. Boiling Lake and hot springs show how heat underground affects water. Dominica is a different country from the similarly named Dominican Republic.

Explorer words: Roseau · Morne Trois Pitons · Boiling Lake · volcanoes · hot springs · geothermal heat · tropical forest · valleys · volcanic island · freshwater lakes

Postcard scene: Boiling Lake

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dm/
- https://whc.unesco.org/en/list/814/

## Dominican Republic · DO

Capital / seat: Santo Domingo

1. Santo Domingo is the Dominican Republic’s capital. Its historic centre stands near the mouth of the Ozama River.

2. The Dominican Republic shares the Caribbean island of Hispaniola with Haiti. It is a different country from Dominica.

3. Merengue is music and dance from the Dominican Republic, shared at festivals and gatherings.

Explorer words: Santo Domingo · historic Santo Domingo · Hispaniola · Ozama River · Caribbean Sea · merengue · dance · festivals · Haiti · Spanish

Postcard scene: Colonial City of Santo Domingo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/do/
- https://whc.unesco.org/en/list/526/
- https://ich.unesco.org/en/RL/music-and-dance-of-the-merengue-in-the-dominican-republic-01162

## DR Congo · CD

Capital / seat: Kinshasa

1. DR Congo is in Africa. Its capital is Kinshasa.

2. Virunga National Park includes volcanic grasslands, wetlands and high mountain snowfields. Different heights and landscapes create different wildlife habitats.

3. Virunga is home to mountain gorillas. Birds also arrive from distant regions for winter, showing how wildlife conservation connects different places.

Explorer words: Kinshasa · Virunga · mountain gorilla · volcanoes · wetlands · Rwenzori Mountains · grasslands · hippopotamus · migratory birds · habitat

Postcard scene: Virunga volcanoes and mountain gorillas

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cd/
- https://whc.unesco.org/en/list/63/

## Ecuador · EC

Capital / seat: Quito

1. Ecuador is in Americas. Its capital is Quito.

2. Giant tortoises and different finches live in the Galápagos Islands. Long-isolated islands can develop wildlife different from that found elsewhere.

3. Ocean currents meet around the Galápagos, whose islands were shaped by volcanoes. Observing their animals helped Darwin develop his studies of evolution.

Explorer words: Quito · Galápagos Islands · giant tortoise · finches · iguana · ocean currents · volcanoes · Charles Darwin · evolution · Basilica del Voto Nacional

Postcard scene: Basilica del Voto Nacional, Quito

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ec/
- https://whc.unesco.org/en/list/1/

## Egypt · EG

Capital / seat: Cairo

1. Cairo is Egypt’s capital. The Nile flows through the desert toward the Mediterranean Sea.

2. The Pyramids of Giza are enormous stone tombs built in ancient Egypt.

3. Today, many people live and farm in towns along the Nile.

Explorer words: Cairo · Pyramids of Giza · Nile River · Sahara Desert · Great Sphinx · hieroglyphs · Arabic · dates · Red Sea · pharaohs

Postcard scene: Pyramids of Giza

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## El Salvador · SV

Capital / seat: San Salvador

1. El Salvador is in Americas. Its capital is San Salvador.

2. Joya de Cerén is an old farming village buried by a volcanic eruption. Remains preserved beneath ash reveal how its residents lived.

3. Unlike a palace or great temple, this site records ordinary farmers' lives. Homes and farming remains can be important evidence for history.

Explorer words: San Salvador · Joya de Cerén · volcanic ash · Laguna Caldera volcano · farming village · ancient homes · farming · excavation · daily life · archaeology

Postcard scene: Joya de Cerén

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sv/
- https://whc.unesco.org/en/list/675/

## Equatorial Guinea · GQ

Capital / seat: Ciudad de la Paz

In January 2026, Ciudad de la Paz replaced Malabo as the capital.

1. In January 2026, Ciudad de la Paz replaced Malabo as the capital.

2. Pico Basile is a high mountain on Bioko Island in Equatorial Guinea. This postcard scene is separate from the capital on the mainland.

3. Bioko has forests that change with elevation, bringing tropical and mountain habitats together.

Explorer words: Ciudad de la Paz · Africa · French · Portuguese · Bioko Island · Pico Basile · Montane forest · Spanish · altitude · habitats

Postcard scene: Pico Basilé on Bioko Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.guineaecuatorialpress.com/noticias/decreto_ley_por_el_que_se_declara_la_ciudad_de_la_paz_djibloho_capital_de_la_republica_de_guinea_ecuatorial
- https://minturismo.gob.gq/lugares-turisticos/
- https://www.unesco.org/en/mab/isla-de-bioko

## Eritrea · ER

Capital / seat: Asmara

1. Eritrea is in Africa. Its capital is Asmara.

2. Asmara stands more than 2,000 metres above sea level. Compare this high city's position with lower land near the sea on the map.

3. Asmara preserves early-20th-century modernist buildings. Cinemas, shops and religious buildings show different designs from a period of new urban planning.

Explorer words: Asmara · Asmara modernist architecture · Fiat Tagliero · elevation · highland city · urban planning · cinemas · shops · modernist architecture · 20th century

Postcard scene: Asmara modernist city and Fiat Tagliero

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/er/
- https://whc.unesco.org/en/list/1550/

## Estonia · EE

Capital / seat: Tallinn

1. Estonia is in Europe. Its capital is Tallinn.

2. Tallinn was an important trading city of the Hanseatic League. Merchants' houses and public buildings preserve traces of that history.

3. Tallinn's Old Town preserves medieval streets and buildings. Caring for older buildings helps people learn how a city developed.

Explorer words: Tallinn · Tallinn Old Town · Hanseatic League · trade · merchants' houses · medieval streets · churches · castle · public buildings · urban conservation

Postcard scene: Tallinn Old Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ee/
- https://whc.unesco.org/en/list/822/

## Eswatini · SZ

Capital / seat: Mbabane

Mbabane is the administrative capital; Lobamba is the royal and legislative centre.

1. Mbabane is the administrative capital; Lobamba is the royal and legislative centre.

2. Sibebe, north of Mbabane, is a huge rounded rock formation. Its shape and surrounding valleys show that mountains can take very different forms.

3. Eswatini's Umhlanga Reed Dance is a community tradition. Songs, dances and the gathering of reeds help pass on its cultural heritage.

Explorer words: Mbabane · Sibebe Rock · Mantenga Falls · Lobamba · Umhlanga · reeds · Reed Dance · rock formation · valleys · community celebrations

Postcard scene: Mantenga Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.thekingdomofeswatini.com/central-eswatini/sibebe-rock/
- https://www.thekingdomofeswatini.com/news-blogs/backpacker-tours-visitor-guide-to-the-2026-umhlanga-reed-dance/

## Ethiopia · ET

Capital / seat: Addis Ababa

1. Addis Ababa is Ethiopia’s capital. Ethiopia has highlands and historic cultural sites.

2. Lalibela’s churches were carved from solid rock, with buildings and passageways cut into the stone.

3. Yayu Biosphere Reserve protects mountain rainforest with wild Arabica coffee and many other living things.

Explorer words: Addis Ababa · Lalibela · rock-hewn churches · rock carving · Yayu · coffee forest · Arabica coffee · Ethiopian Highlands · biodiversity · Amharic

Postcard scene: Rock-Hewn Churches of Lalibela

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/et/
- https://whc.unesco.org/en/list/18/
- https://www.unesco.org/en/mab/yayu?hub=66369

## Fiji · FJ

Capital / seat: Suva

1. Fiji is in Oceania. Its capital is Suva.

2. Levuka is a historic port town in Fiji. Low buildings, coconut palms and mango trees line the seafront, showing a town shaped by the sea.

3. Levuka preserves traces of local residents and people who arrived by sea. Warehouses, schools and shops show that ports connected knowledge as well as goods.

Explorer words: Suva · Levuka · Bouma waterfalls · port town · coconut palms · mango trees · seafront · warehouses · shops · cultural exchange

Postcard scene: Bouma waterfalls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fj/
- https://whc.unesco.org/en/list/1399/

## Finland · FI

Capital / seat: Helsinki

1. Finland’s capital, Helsinki, is home to the white-domed Helsinki Cathedral.

2. Finland has many forests and lakes where people spend time outdoors.

3. Finnish and Swedish are the official languages of Finland.

Explorer words: Helsinki · Helsinki Cathedral · Senate Square · Baltic Sea · Finnish · sauna · reindeer · blueberries · rye bread · northern lights

Postcard scene: Helsinki Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## France · FR

Capital / seat: Paris

1. Paris is France’s capital. The Eiffel Tower was built for the 1889 World’s Fair.

2. France has the high Alps as well as Atlantic and Mediterranean coasts.

3. The Louvre in Paris is home to many well-known works of art.

Explorer words: Paris · Eiffel Tower · Louvre · Seine River · Alps · baguette · croissant · French · lavender · cheese

Postcard scene: Eiffel Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Gabon · GA

Capital / seat: Libreville

1. Gabon is in Africa. Its capital is Libreville.

2. Lopé-Okanda combines dense rainforest and open savanna. Where forest meets grassland, wildlife can find several different kinds of habitat.

3. The area also preserves old settlement remains, iron-working traces and rock carvings. A nature reserve can hold a long human history too.

Explorer words: Libreville · Lopé-Okanda · rainforest · savanna · mandrill · ecosystem · rock carvings · iron-working · settlement remains · habitat

Postcard scene: Lopé-Okanda landscape and mandrill

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ga/
- https://whc.unesco.org/en/list/1147/

## Gambia · GM

Capital / seat: Banjul

1. Gambia is in Africa. Its capital is Banjul.

2. Sites around Kunta Kinteh Island record encounters between Africa and Europe along the River Gambia. They teach the history of the slave trade and its abolition.

3. Protecting these sites means more than preserving buildings. It also means remembering people denied their freedom and reflecting on everyone's dignity.

Explorer words: Banjul · River Gambia · Kunta Kinteh Island · Senegambian stone circles · historic sites · slave trade · abolition · freedom · dignity · historical memory

Postcard scene: Senegambian stone circles

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gm/
- https://whc.unesco.org/en/list/761/

## Georgia · GE

Capital / seat: Tbilisi

1. Georgia is in Asia. Its capital is Tbilisi.

2. Gelati Monastery displays medieval Georgian architecture and art. Large dressed stones and decorative arches record the skills of its builders.

3. Gelati also housed an academy for scholarship and education. It shows how religious buildings could become centres of learning and culture.

Explorer words: Tbilisi · Gelati Monastery · Narikala Fortress · academy · stone architecture · arches · medieval Georgia · science · education · craftsmanship

Postcard scene: Tbilisi and Narikala Fortress

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ge/
- https://whc.unesco.org/en/list/710/

## Germany · DE

Capital / seat: Berlin

1. Berlin is Germany’s capital, and the Brandenburg Gate is one of its best-known historic landmarks.

2. Germany’s landscapes range from the North and Baltic seas to the Alps in the south.

3. The Berlin Wall once divided the city; when it opened in 1989, people could travel between its sides again.

Explorer words: Berlin · Brandenburg Gate · Berlin Wall · Rhine River · Black Forest · Alps · pretzel · bread · German · football

Postcard scene: Brandenburg Gate

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Ghana · GH

Capital / seat: Accra

1. Accra is Ghana’s capital, on the country’s Atlantic coast.

2. Kente is made by joining narrow woven strips. Its colours and patterns carry meanings and community stories.

3. Coastal forts and castles preserve the history of trade and the suffering caused by the slave trade. Remembering it helps us learn about human rights.

Explorer words: Accra · kente · weaving · woven strips · loom · cotton · Atlantic Ocean · Elmina Castle · Cape Coast Castle · Jamestown

Postcard scene: Black Star Square, Accra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gh/
- https://ich.unesco.org/en/RL/craftsmanship-of-traditional-woven-textile-kente-02130
- https://whc.unesco.org/en/list/34/

## Greece · GR

Capital / seat: Athens

1. Greece’s capital, Athens, has the Acropolis, where the Parthenon stands on a hill.

2. Greece has mountains, coastlines, and many large and small islands.

3. The ancient Olympic Games were held at Olympia in Greece.

Explorer words: Athens · Parthenon · Acropolis · Olympia · Aegean Sea · Mount Olympus · olives · feta cheese · Greek · Greek islands

Postcard scene: Acropolis & Parthenon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Grenada · GD

Capital / seat: St. George's

1. Grenada is in Americas. Its capital is St. George's.

2. Grenada's spice gardens grow nutmeg and other aromatic plants. Spices are plant ingredients that add flavour and aroma to food.

3. Spices such as nutmeg are also used in syrups, jams and sauces. One plant ingredient can become part of many different foods.

Explorer words: St. George's · nutmeg · spices · herbs · spice garden · syrup · jam · sauce · plant aromas · Carenage

Postcard scene: Carenage, St. George’s

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.puregrenada.com/de-la-grenade-nutmeg-garden/

## Guatemala · GT

Capital / seat: Guatemala City

1. Guatemala is in Americas. Its capital is Guatemala City.

2. Tikal is an ancient Maya city within tropical forest. Tall temples, palaces and broad squares reveal Maya building skills.

3. Remains of ordinary homes are scattered around the larger buildings. Understanding a city means studying everyday spaces as well as grand monuments.

Explorer words: Guatemala City · Tikal · Maya civilisation · tropical forest · temples · palaces · public squares · house remains · city ruins · excavation

Postcard scene: Tikal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gt/
- https://whc.unesco.org/en/list/64/

## Guinea · GN

Capital / seat: Conakry

1. Guinea is in Africa. Its capital is Conakry.

2. Mount Nimba has forested slopes and grassy uplands. Lower and higher parts of the mountain provide different habitats for plants and animals.

3. Some chimpanzees around Mount Nimba use stones as tools. Watching animals can show how members of the same species live in different ways.

Explorer words: Conakry · Mount Nimba · chimpanzee · stone tools · mountain forest · grasslands · slopes · endemic species · animal behaviour · nature reserve

Postcard scene: Mount Nimba

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gn/
- https://whc.unesco.org/en/list/155/

## Guinea-Bissau · GW

Capital / seat: Bissau

1. Guinea-Bissau is in Africa. Its capital is Bissau.

2. The Bijagós Islands contain mangroves, mudflats and shallow seas. Rising and falling tides create changing habitats along the shore.

3. Sea turtles, manatees and travelling shorebirds use these islands. Protecting seas and island coasts helps preserve places for many animals.

Explorer words: Bissau · Bijagós Archipelago · mangroves · mudflats · high tide · low tide · sea turtles · manatee · shorebirds · coastal ecosystem

Postcard scene: Bijagós coastal and marine ecosystems

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gw/
- https://whc.unesco.org/en/list/1431/

## Guyana · GY

Capital / seat: Georgetown

1. Guyana is in Americas. Its capital is Georgetown.

2. At Kaieteur Falls, the Potaro River flows through rainforest before dropping over a high cliff. Spray forms as falling water breaks into tiny droplets.

3. Different birds and plants live in the forest around the waterfall. Study the connected river and forest, rather than the waterfall alone.

Explorer words: Georgetown · Kaieteur Falls · Potaro River · rainforest · spray · cliff · national park · forest birds · river water · ecological connections

Postcard scene: Kaieteur Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guyanatourism.com/kaieteur-falls/

## Haiti · HT

Capital / seat: Port-au-Prince

1. Haiti is in Americas. Its capital is Port-au-Prince.

2. The Citadelle Laferrière and Sans-Souci Palace were built after Haiti gained independence. They record a time when newly free people were building a country.

3. Haiti's history park communicates the meaning of freedom as well as preserving buildings. Its monuments invite us to think about independence and human dignity.

Explorer words: Port-au-Prince · Citadelle Laferrière · Sans-Souci Palace · Ramiers · independence · freedom · dignity · history park · fortress · 19th century

Postcard scene: Citadelle Laferrière

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ht/
- https://whc.unesco.org/en/list/180/

## Honduras · HN

Capital / seat: Tegucigalpa

1. Honduras is in Americas. Its capital is Tegucigalpa.

2. Copán is an ancient Maya city site. Large squares and building remains reveal how the city changed through different periods.

3. Archaeologists excavate sites and compare surviving traces. Even an abandoned city such as Copán can teach us about past life and architecture.

Explorer words: Tegucigalpa · Copán · Maya civilisation · public squares · city remains · foundations · excavation · archaeologists · ancient city · urban change

Postcard scene: Copán

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hn/
- https://whc.unesco.org/en/list/129/

## Hungary · HU

Capital / seat: Budapest

1. Hungary is in Europe. Its capital is Budapest.

2. Budapest spreads along both banks of the Danube, with the Buda Castle Quarter and historic buildings. The river shapes its scenery and movement through the city.

3. Compare Budapest's Roman remains with architecture from later periods. Buildings surviving together reveal a city's long history of change.

Explorer words: Budapest · Danube · Buda Castle · Andrássy Avenue · Aquincum · Roman remains · riverbanks · Gothic architecture · cityscape · Hungarian Parliament

Postcard scene: Hungarian Parliament, Budapest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hu/
- https://whc.unesco.org/en/list/400/

## Iceland · IS

Capital / seat: Reykjavik

1. Iceland is in Europe. Its capital is Reykjavik.

2. The outdoor assembly called the Althing began at Thingvellir in 930. Its historic site records where people gathered to make laws and settle disputes.

3. Traces of shelters made from turf and stone remain at Thingvellir. A meeting place can become important heritage even without a grand palace.

Explorer words: Reykjavik · Thingvellir · Althing · open-air assembly · laws · assembly · turf and stone · historic shelters · farming remains · Reykjavík and aurora

Postcard scene: Reykjavík and aurora

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/is/
- https://whc.unesco.org/en/list/1152/

## India · IN

Capital / seat: New Delhi

1. India is in South Asia, and New Delhi is its capital.

2. The Himalayas rise in the north, and the Indian Ocean borders India to the south.

3. The Taj Mahal is a marble monument in the city of Agra.

Explorer words: New Delhi · Taj Mahal · Himalayas · Ganges River · Bengal tiger · mango · samosa · Hindi · Diwali · yoga

Postcard scene: Taj Mahal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Indonesia · ID

Capital / seat: Jakarta

1. Jakarta is Indonesia’s capital. Nusantara, a planned future capital, is being built on the island of Borneo.

2. Indonesia stretches across many islands between the Indian and Pacific Oceans.

3. Borobudur on Java is an ancient Buddhist temple with stone stupas and story carvings.

Explorer words: Jakarta · Nusantara · Java · Borobudur · Komodo dragon · volcanoes · nasi goreng · satay · Bahasa Indonesia · batik

Postcard scene: Borobudur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Iran · IR

Capital / seat: Tehran

1. Iran is in Asia. Its capital is Tehran.

2. Persepolis was a capital of the Achaemenid Empire. Its great palaces stood on a raised terrace, displaying the skills of ancient builders.

3. The terrace beneath the palaces combines natural landforms with constructed sections. Ancient builders adapted the ground while creating their buildings.

Explorer words: Tehran · Persepolis · Achaemenid Empire · Darius I · palaces · raised terrace · ancient architecture · ruins · landforms · builders

Postcard scene: Persepolis

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ir/
- https://whc.unesco.org/en/list/114/

## Iraq · IQ

Capital / seat: Baghdad

1. Iraq is in Asia. Its capital is Baghdad.

2. Babylon was an important city of ancient Mesopotamia. Its walls, gates, palaces and temple remains reveal the structure of a large ancient city.

3. Villages and farming areas also surrounded Babylon. Ancient cities depended on nearby farmland as well as the buildings within their walls.

Explorer words: Baghdad · Babylon · Mesopotamia · city walls · city gates · palaces · temples · farmland · ancient city · Ziggurat of Ur

Postcard scene: Ziggurat of Ur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/iq/
- https://whc.unesco.org/en/list/278/

## Ireland · IE

Capital / seat: Dublin

1. Ireland is in Europe. Its capital is Dublin.

2. Brú na Bóinne near the River Boyne contains prehistoric sites such as Newgrange, Knowth and Dowth. They display building and art using large stones.

3. These monuments reveal social life as well as funerary and religious practices. Buildings and objects can tell human stories even without written records.

Explorer words: Dublin · Brú na Bóinne · River Boyne · Newgrange · Knowth · Dowth · prehistory · megalithic architecture · archaeology · Cliffs of Moher

Postcard scene: Cliffs of Moher

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ie/
- https://whc.unesco.org/en/list/659/

## Israel · IL

Capital / seat: Jerusalem

Israel’s government is based in Jerusalem, which it designates as its capital. The city’s international status is disputed.

1. Israel’s government is based in Jerusalem, which it designates as its capital. The city’s international status is disputed.

2. The Bahá'í holy places in Haifa include a shrine and surrounding gardens. Religious buildings and landscaped grounds are cared for together.

3. Bahá'í holy places are spread across Haifa and Western Galilee. Pilgrimage is a tradition of travelling to places that hold spiritual meaning.

Explorer words: Jerusalem · Haifa · Bahá'í Gardens · Shrine of the Báb · Acre · Western Galilee · gardens · shrine · pilgrimage · religious architecture

Postcard scene: Bahá’í Gardens and Shrine in Haifa

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/il/
- https://whc.unesco.org/en/list/1220/

## Italy · IT

Capital / seat: Rome

1. Rome is Italy’s capital, with many buildings from ancient times.

2. The Colosseum is a huge arena built in ancient Rome for public events.

3. Italy has a boot-shaped peninsula reaching into the Mediterranean Sea, plus many islands.

Explorer words: Rome · Colosseum · Leaning Tower of Pisa · Venice · Mediterranean Sea · pizza · pasta · gelato · Italian · Alps

Postcard scene: Colosseum

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Ivory Coast · CI

Capital / seat: Yamoussoukro

1. Ivory Coast is in Africa. Its capital is Yamoussoukro.

2. Taï National Park protects an ancient tropical forest in West Africa. Its dense woods support many interconnected plants and animals.

3. Pygmy hippos and different monkeys live in Taï. Losing even a small habitat can make a big difference to the animals that depend on it.

Explorer words: Yamoussoukro · Taï National Park · pygmy hippopotamus · monkeys · tropical forest · West Africa · plants · biodiversity · habitat protection · Basilica of Our Lady of Peace

Postcard scene: Basilica of Our Lady of Peace, Yamoussoukro

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ci/
- https://whc.unesco.org/en/list/195/

## Jamaica · JM

Capital / seat: Kingston

1. Jamaica is in Americas. Its capital is Kingston.

2. The Blue and John Crow Mountains are steep, forested uplands. Trails and settlements preserve traces of life in Maroon communities.

3. Maroons escaped enslavement and formed communities in the mountains. Forests supplied resources, while traditions such as songs and dances continued.

Explorer words: Kingston · Blue Mountains · John Crow Mountains · Maroon communities · mountain forest · Nanny Town Heritage Route · mountain trails · freedom · traditional dances · forest resources

Postcard scene: Blue Mountains and Kingston coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jm/
- https://whc.unesco.org/en/list/1356/

## Japan · JP

Capital / seat: Tokyo

1. Japan is an island country in East Asia, and Tokyo is its capital.

2. Mount Fuji is Japan’s tallest mountain.

3. Japan has many islands and a network of fast Shinkansen trains.

Explorer words: Tokyo · Mount Fuji · five-story pagoda · cherry blossom · Hokkaido · sushi · ramen · Japanese · Shinkansen · origami

Postcard scene: Mount Fuji & Five-Story Pagoda

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Jordan · JO

Capital / seat: Amman

1. Jordan is in Asia. Its capital is Amman.

2. Petra is an ancient city partly carved into rock. Built structures and carved rock faces stand together among mountains and narrow gorges.

3. Petra was a crossroads for caravan trade between regions. Travelling traders brought together goods, cultures and different building traditions.

Explorer words: Amman · Petra · Nabataeans · rock-cut architecture · gorges · caravan trade · crossroads · Red Sea · Dead Sea · cultural exchange

Postcard scene: Petra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jo/
- https://whc.unesco.org/en/list/326/

## Kazakhstan · KZ

Capital / seat: Astana

1. Kazakhstan is in Asia. Its capital is Astana.

2. Saryarka's grasslands and lakes provide resting places for migratory waterbirds. Birds travel between regions to find food and breeding grounds.

3. The Mausoleum of Khoja Ahmed Yasawi in Turkestan is a large Timurid building. Construction methods tried there later influenced work in other cities.

Explorer words: Astana · Saryarka · steppe · lakes · migratory birds · wetlands · Turkestan · Yasawi Mausoleum · Timurid period · Baiterek Tower

Postcard scene: Baiterek Tower, Astana

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kz/
- https://whc.unesco.org/en/list/1102/
- https://whc.unesco.org/en/list/1103/

## Kenya · KE

Capital / seat: Nairobi

1. Nairobi is Kenya’s capital. Kenya has grasslands, mountains, large lakes and part of the Great Rift Valley.

2. Zebras and wildebeest move across the Maasai Mara grasslands during seasonal migrations.

3. Kiswahili and English are official languages in Kenya, and communities also speak many other languages.

Explorer words: Nairobi · Maasai Mara · Mount Kenya · Great Rift Valley · wildebeest · giraffe · Kiswahili · ugali · track and field · Lake Victoria

Postcard scene: Maasai Mara

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Kiribati · KI

Capital / seat: South Tarawa

1. Kiribati is in Oceania. Its capital is South Tarawa.

2. The Phoenix Islands Protected Area conserves coral islands and surrounding seas. Beneath the surface are seamounts and deep-water habitats.

3. Corals, fish and seabirds use the same ocean in different ways. Consider why conservation must protect wide areas of sea as well as islands.

Explorer words: South Tarawa · Phoenix Islands · coral islands · seamounts · corals · fish · seabirds · deep sea · marine protected area · Maneaba meeting house

Postcard scene: Maneaba meeting house

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ki/
- https://whc.unesco.org/en/list/1325/

## Kosovo · XK

Capital / seat: Pristina

1. Kosovo is in Europe. Its capital is Pristina.

2. Pristina's National Library collects materials such as books, newspapers and photographs. Preserving different records helps people learn about earlier life and culture.

3. The library also presents historical materials through digital collections. Paper records and digital resources are both ways to pass knowledge to others.

Explorer words: Pristina · National Library in Pristina · books · newspapers · photographs · digital collections · cultural records · library · document preservation · Pristina and its surroundings

Postcard scene: Pristina and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://bkk-pjeterbogdani.rks-gov.net/en/

## Kuwait · KW

Capital / seat: Kuwait City

1. Kuwait is in Asia. Its capital is Kuwait City.

2. The rounded parts of the Kuwait Towers include water storage facilities. An eye-catching building can also help meet a city's everyday needs.

3. Water stored high above the ground can use gravity to flow downwards. Look for three-dimensional shapes, such as spheres and columns, in water towers.

Explorer words: Kuwait City · Kuwait Towers · water storage · water reservoir · gravity · spheres · columns · city life · everyday architecture · water use

Postcard scene: Kuwait City waterfront and Kuwait Towers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.archnet.org/sites/135

## Kyrgyzstan · KG

Capital / seat: Bishkek

1. Kyrgyzstan is in Asia. Its capital is Bishkek.

2. Sulaiman-Too stands behind Osh at a crossroads of the Silk Roads. Travellers long used the mountain as an important landmark.

3. The mountain has caves, rock carvings and old places of worship. Images of people, animals and geometric forms record a long cultural history.

Explorer words: Bishkek · Osh · Sulaiman-Too · Silk Roads · Fergana Valley · caves · petroglyphs · geometric patterns · landmark mountain · places of worship

Postcard scene: Sulaiman-Too Sacred Mountain in Osh

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kg/
- https://whc.unesco.org/en/list/1230/

## Laos · LA

Capital / seat: Vientiane

1. Laos is in Asia. Its capital is Vientiane.

2. Luang Prabang preserves Lao traditional buildings alongside European colonial architecture. Roofs and streets reveal how different cultures met.

3. Conserving an old town means caring for streets and neighbouring buildings, not just one monument. These connections shape Luang Prabang's distinctive townscape.

Explorer words: Vientiane · Luang Prabang · Lao traditional architecture · townscape · streets · roofs · cultural exchange · colonial period · architectural conservation · Pha That Luang

Postcard scene: Pha That Luang

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/la/
- https://whc.unesco.org/en/list/479/

## Latvia · LV

Capital / seat: Riga

1. Latvia is in Europe. Its capital is Riga.

2. Riga grew as a trading city of the Hanseatic League. Its old centre and later wooden buildings record the city's expansion.

3. Riga preserves many Art Nouveau buildings. Curves and decorations on their facades show that architecture can also be art.

Explorer words: Riga · historic Riga · Art Nouveau · Hanseatic League · wooden buildings · old town · facade · trade · curving decoration · Riga Art Nouveau architecture

Postcard scene: Riga Art Nouveau architecture

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lv/
- https://whc.unesco.org/en/list/852/

## Lebanon · LB

Capital / seat: Beirut

1. Lebanon is in Asia. Its capital is Beirut.

2. Baalbek preserves large temples built in Roman times. Their tall stone columns and scale offer clues to the building skills of the past.

3. Baalbek has roots in the Phoenician period and was once called Heliopolis. A city's names and buildings can preserve the history of different eras.

Explorer words: Beirut · Baalbek · Roman temples · stone columns · Phoenicia · Heliopolis · building skills · archaeological remains · city names · changing eras

Postcard scene: Baalbek Roman temple ruins

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lb/
- https://whc.unesco.org/en/list/294/

## Lesotho · LS

Capital / seat: Maseru

1. Lesotho is in Africa. Its capital is Maseru.

2. Lesotho's Sehlabathebe and a park in South Africa form the Maloti-Drakensberg Park. Protecting nature can bring neighbouring countries together across a border.

3. The park contains sandstone cliffs, caves and rock pools. Different habitats provide homes for plants, fish and birds such as the bearded vulture.

Explorer words: Maseru · Sehlabathebe · Maloti-Drakensberg · sandstone cliffs · caves · rock pools · habitats · bearded vulture · cross-border cooperation · Maletsunyane Falls

Postcard scene: Maletsunyane Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ls/
- https://whc.unesco.org/en/list/985/

## Liberia · LR

Capital / seat: Monrovia

1. Liberia is in Africa. Its capital is Monrovia.

2. Sapo National Park protects tropical forest in Liberia. Pygmy hippopotamuses, chimpanzees and forest elephants are among the animals living there.

3. Protecting a forest means considering both wildlife and nearby communities. Local residents, forest authorities and conservation organisations work together to care for Sapo.

Explorer words: Monrovia · Sapo National Park · tropical forest · pygmy hippopotamus · chimpanzee · forest elephant · local communities · forest conservation · wildlife · shared stewardship

Postcard scene: Sapo National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.fauna-flora.org/projects/implementing-effective-management-sapo-national-park/

## Libya · LY

Capital / seat: Tripoli

1. Libya is in Africa. Its capital is Tripoli.

2. Leptis Magna flourished in Roman times. Its harbour, market, storehouses and residential remains reveal how people worked and lived.

3. Septimius Severus was born here and later became a Roman emperor. The city expanded under him, linking a person's history with changes in a town.

Explorer words: Tripoli · Leptis Magna · Roman period · ancient harbour · market · storehouses · house remains · Septimius Severus · urban growth · archaeology

Postcard scene: Archaeological Site of Leptis Magna

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ly/
- https://whc.unesco.org/en/list/183/

## Liechtenstein · LI

Capital / seat: Vaduz

1. Liechtenstein is in Europe. Its capital is Vaduz.

2. Vaduz Castle stands on a hill above the capital. A castle on high ground offered a wide view of the surrounding roads and settlement.

3. The area around the castle offers views of the Rhine Valley. Comparing hills and valleys helps us think about how terrain influences where buildings stand.

Explorer words: Vaduz · Vaduz Castle · Rhine Valley · hills · castle · high ground · valleys · observing terrain · settlement landscape · building location

Postcard scene: Vaduz Castle and Alpine Rhine Valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://tourismus.li/en/activities/popular-sights-the-countryside/sights/?pn=6&sortBy=0

## Lithuania · LT

Capital / seat: Vilnius

1. Lithuania is in Europe. Its capital is Vilnius.

2. Vilnius's historic centre includes Gothic, Renaissance and Baroque buildings. Comparing windows, roofs and decorations reveals changing tastes across different periods.

3. Vilnius preserves its medieval street layout. Historic streets and buildings show the city's long role as a centre of cultural life.

Explorer words: Vilnius · historic Vilnius · Gothic style · Renaissance · Baroque · medieval streets · windows · roofs · building decorations · Vilnius Old Town

Postcard scene: Vilnius Old Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lt/
- https://whc.unesco.org/en/list/541/

## Luxembourg · LU

Capital / seat: Luxembourg

1. Luxembourg is in Europe. Its capital is Luxembourg.

2. Luxembourg City preserves fortifications built and strengthened over different periods. Its important location led successive rulers to reshape its defences.

3. Parts of the fortifications were dismantled from 1867, but historic defences remain. Comparing them with the old town reveals how a city's uses can change.

Explorer words: Luxembourg · Luxembourg old town · fortifications · city walls · defences · strategic location · 1867 · historic architecture · changes of rule · urban change

Postcard scene: Luxembourg Old Quarters and Fortifications

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lu/
- https://whc.unesco.org/en/list/699/

## Madagascar · MG

Capital / seat: Antananarivo

1. Madagascar is in Africa. Its capital is Antananarivo.

2. Madagascar's tsingy are landscapes of sharp limestone pinnacles. Water slowly dissolves and wears away the rock, creating an unusual stone forest.

3. The Andrefana Dry Forests shelter lemurs and many birds. Protecting forests, wetlands and mangroves also protects the living things that depend on them.

Explorer words: Antananarivo · tsingy · limestone · stone forest · Andrefana Dry Forests · lemurs · mangroves · wetlands · erosion · Baobab landscape

Postcard scene: Baobab landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mg/
- https://whc.unesco.org/en/list/494/

## Malawi · MW

Capital / seat: Lilongwe

1. Malawi is in Africa. Its capital is Lilongwe.

2. Lake Malawi is home to many kinds of cichlid fish. Different food sources and habitats within one lake are associated with fish that have different characteristics.

3. Many Lake Malawi fish occur naturally only in this lake. A species restricted to one area is called endemic, so protecting its habitat is especially important.

Explorer words: Lilongwe · Lake Malawi · cichlids · freshwater fish · endemic species · habitat · fish diets · lake ecosystem · biological diversity · habitat protection

Postcard scene: Lake Malawi

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mw/
- https://whc.unesco.org/en/list/289/

## Malaysia · MY

Capital / seat: Kuala Lumpur

Kuala Lumpur is the capital; Putrajaya is the administrative centre.

1. Kuala Lumpur is the capital; Putrajaya is the administrative centre.

2. Around Mount Kinabalu on Borneo, life ranges from lowland rainforest to high-mountain plants. Changes in altitude help explain differences in climate and vegetation.

3. Kinabalu Park has plants with connections to Southeast Asia, the Himalayas and other regions. Studying one mountain can reveal the history of how living things spread.

Explorer words: Kuala Lumpur · Mount Kinabalu · Borneo · rainforest · altitude · mountain climate · plants · Himalayas · species distribution · Petronas Twin Towers

Postcard scene: Petronas Twin Towers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/my/
- https://whc.unesco.org/en/list/1012/

## Maldives · MV

Capital / seat: Malé

1. Maldives is in Asia. Its capital is Malé.

2. Hukuru Miskiy in Malé is an old mosque built with coral stone. Patterns carved into the stone show craftsmanship developed in these ocean islands.

3. Traditional Maldivian mosques also use timber columns, roofs and lacquer decoration. Seeing how materials work together connects the study of architecture with crafts.

Explorer words: Malé · Hukuru Miskiy · coral stone · stone carving · timber columns · roofs · lacquerwork · traditional mosques · craftspeople · Maldivian atoll

Postcard scene: Maldivian atoll

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://visitmaldives.com/en/experience/mosques-in-maldives-a-standing-testament-to-the-local-craftsmanship
- https://whc.unesco.org/en/tentativelists/5812/

## Mali · ML

Capital / seat: Bamako

1. Mali is in Africa. Its capital is Bamako.

2. Timbuktu was long a centre of learning. Sankore and its historic mosques preserve the story of a city where people studied and shared knowledge.

3. Timbuktu's heritage needs to be understood alongside its desert setting. UNESCO identifies risks from desertification, showing why both the environment and cultural heritage need care.

Explorer words: Bamako · Timbuktu · Sankore · centre of learning · sharing knowledge · historic mosques · desert · desertification · heritage conservation · Great Mosque of Djenné

Postcard scene: Great Mosque of Djenné

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ml/
- https://whc.unesco.org/en/list/119/

## Malta · MT

Capital / seat: Valletta

1. Malta is in Europe. Its capital is Valletta.

2. Valletta brings together fortifications, palaces and churches. Historic buildings stand close together, allowing a small area to reveal the history of different periods.

3. The Order of St John played an important role in Valletta's history. The city's fortifications show how architecture was used to protect a harbour and its settlement.

Explorer words: Valletta · city walls · fortifications · palaces · churches · Order of St John · harbour · defensive architecture · urban history · Valletta Grand Harbour

Postcard scene: Valletta Grand Harbour

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mt/
- https://whc.unesco.org/en/list/131/

## Marshall Islands · MH

Capital / seat: Majuro

1. Marshall Islands is in Oceania. Its capital is Majuro.

2. Marshallese navigators travelled between islands by observing waves and winds. Charts made with palm strips and shells helped them learn patterns of ocean movement.

3. These charts did not show distances at an exact scale like a paper map. Navigators studied them on land, then used experience and observation to find their way at sea.

Explorer words: Majuro · navigation charts · palm strips · shells · waves · winds · navigators · canoes · scale · Majuro Atoll

Postcard scene: Majuro Atoll

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mh/
- https://ocean.si.edu/human-connections/history-cultures/navigating-waters-micronesian-stick-charts

## Mauritania · MR

Capital / seat: Nouakchott

1. Mauritania is in Africa. Its capital is Nouakchott.

2. Banc d'Arguin National Park combines dunes, shallow seas and coastal wetlands. Many migratory birds stop there to feed or rest.

3. Migratory birds travel between distant regions with the seasons. Protecting resting wetlands supports journeys that extend beyond the borders of any one country.

Explorer words: Nouakchott · Banc d'Arguin · migratory birds · coastal wetlands · shallow seas · dunes · seasonal migration · bird feeding · resting sites · wetland conservation

Postcard scene: Banc d’Arguin

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mr/
- https://whc.unesco.org/en/list/506/

## Mauritius · MU

Capital / seat: Port Louis

1. Mauritius is in Africa. Its capital is Port Louis.

2. Le Morne is a rocky mountain overlooking the sea. People escaping enslavement once sought refuge there, making it a place that remembers the search for freedom.

3. Stories about Le Morne have also survived through memory and oral tradition. Studying history includes listening to these stories and respecting people's dignity.

Explorer words: Port Louis · Le Morne · rocky mountain · Indian Ocean · refuge · freedom · oral tradition · memory · human dignity · learning history

Postcard scene: Le Morne Cultural Landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mu/
- https://whc.unesco.org/en/list/1259/

## Mexico · MX

Capital / seat: Mexico City

1. Mexico City, Mexico’s capital, sits high in a valley surrounded by mountains.

2. Chichén Itzá was an ancient Maya city, with a great stone pyramid called El Castillo.

3. Maize is used in many Mexican foods, and many Indigenous languages and cultures continue today.

Explorer words: Mexico City · Chichén Itzá · Yucatán Peninsula · Copper Canyon · monarch butterfly · maize · tacos · Spanish · Nahuatl · mariachi

Postcard scene: Chichén Itzá

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Micronesia · FM

Capital / seat: Palikir

1. Micronesia is in Oceania. Its capital is Palikir.

2. Nan Madol on Pohnpei is a historic settlement built on small artificial islands. Channels run between islands constructed with basalt and coral materials.

3. Nan Madol preserves remains of palaces and ceremonial places used by past leaders. Its layout reveals an approach to building a settlement alongside the sea.

Explorer words: Palikir · Nan Madol · Pohnpei · artificial islands · basalt · coral materials · channels · historic palaces · ceremonial places · island layout

Postcard scene: Nan Madol

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fm/
- https://whc.unesco.org/en/list/1503/

## Moldova · MD

Capital / seat: Chișinău

1. Moldova is in Europe. Its capital is Chișinău.

2. Moldova has a survey point in the Struve Geodetic Arc. Measurements linking points across several countries in triangles helped scientists study Earth's size and shape.

3. This survey was a nineteenth-century scientific collaboration across countries. Triangles help us explore how careful measurement contributes to making accurate maps.

Explorer words: Chișinău · Struve Geodetic Arc · surveying · triangles · survey points · Earth's size · mapmaking · 19th century · scientific cooperation · Old Orhei

Postcard scene: Old Orhei

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/md/
- https://whc.unesco.org/en/list/1187/

## Monaco · MC

Capital / seat: Monaco

1. Monaco is in Europe. Its capital is Monaco.

2. Monaco's Oceanographic Museum introduces marine life and ocean research. Observing aquarium animals can be a starting point for learning about habitats beneath the sea.

3. The museum presents both ocean nature and conservation. When exploring an exhibit, ask not only an animal's name but also where it lives and what it needs.

Explorer words: Monaco · Oceanographic Museum of Monaco · aquarium · ocean research · marine life · habitats · Mediterranean Sea · conservation · observation · Monaco harbor and Mediterranean coast

Postcard scene: Monaco harbor and Mediterranean coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://musee.oceano.org/en/

## Mongolia · MN

Capital / seat: Ulaanbaatar

1. Ulaanbaatar is Mongolia’s capital. The Orkhon Valley preserves the history of herding communities, old cities and monasteries.

2. Naadam is a Mongolian festival celebrating traditional horse racing, wrestling and archery.

3. The morin khuur is a two-stringed instrument decorated with a horse’s head. A bow makes its strings sound.

Explorer words: Ulaanbaatar · Orkhon Valley · Erdene Zuu Monastery · grasslands · nomadic herding · Naadam · horse racing · wrestling · archery · morin khuur

Postcard scene: Gobi landscape and ger

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mn/
- https://whc.unesco.org/en/list/1081/
- https://ich.unesco.org/en/RL/naadam-mongolian-traditional-festival-00395
- https://ich.unesco.org/en/RL/traditional-music-of-the-morin-khuur-00068

## Montenegro · ME

Capital / seat: Podgorica

1. Montenegro is in Europe. Its capital is Podgorica.

2. Kotor is a historic harbour town in an Adriatic bay. Its walls, churches and old buildings reveal a history of trade and cultural life.

3. Kotor's heritage was restored after serious damage in the 1979 earthquake. Caring for old buildings involves using historical evidence alongside building skills.

Explorer words: Podgorica · Kotor · Adriatic Sea · Bay of Kotor · harbour town · city walls · historic churches · earthquake · heritage restoration · Kotor region

Postcard scene: Kotor region

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/me/
- https://whc.unesco.org/en/list/125/

## Morocco · MA

Capital / seat: Rabat

1. Morocco’s capital, Rabat, is a coastal city looking out to the Atlantic Ocean.

2. Morocco has the Atlas Mountains, the Sahara, and coasts on the Atlantic and Mediterranean.

3. Arabic and Amazigh are official languages of Morocco.

Explorer words: Rabat · Marrakech · Koutoubia Mosque · Atlas Mountains · Sahara Desert · Amazigh · Arabic · couscous · mint tea · zellij tilework

Postcard scene: Marrakech & Koutoubia Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Mozambique · MZ

Capital / seat: Maputo

1. Mozambique is in Africa. Its capital is Maputo.

2. The Island of Mozambique was an important port in Indian Ocean trade. Its buildings record encounters between people travelling by sea from different regions.

3. The island combines stone-and-lime buildings with homes using wood and plant materials. Local resources and ways of living help shape the appearance of houses.

Explorer words: Maputo · Island of Mozambique · Indian Ocean trade · historic port · stone buildings · lime · wood materials · macuti houses · cultural encounters · Maputo railway station

Postcard scene: Maputo railway station

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mz/
- https://whc.unesco.org/en/list/599/

## Myanmar · MM

Capital / seat: Naypyidaw

1. Myanmar is in Asia. Its capital is Naypyidaw.

2. Bagan is a historic city near the Ayeyarwady River. Its temples, stupas, murals and sculptures reveal the religious and artistic life of earlier communities.

3. Bagan was a major royal centre, especially in the eleventh to thirteenth centuries. Distinguishing it from today's capital, Naypyidaw, shows how a city's role changes over time.

Explorer words: Naypyidaw · Bagan · Ayeyarwady River · temples · stupas · murals · sculpture · 11th–13th centuries · historic kingdom · roles of cities

Postcard scene: Bagan

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mm/
- https://whc.unesco.org/en/list/1588/

## Namibia · NA

Capital / seat: Windhoek

1. Namibia is in Africa. Its capital is Windhoek.

2. The Namib Sand Sea is a landscape of dunes built by wind. Sand transported through rivers, the sea and wind helps form this desert landscape.

3. Fog is an important source of moisture in this coastal desert. Even where rain is scarce, plants and animals can adapt to obtain the water they need.

Explorer words: Windhoek · Namib Sand Sea · sand dunes · wind · fog · moisture · sand transport · coastal desert · adaptation · Sossusvlei

Postcard scene: Sossusvlei

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/na/
- https://whc.unesco.org/en/list/1430/

## Nauru · NR

Capital / seat: Yaren

Nauru has no official capital. The map shows Yaren, the district where government offices are located.

1. Nauru has no official capital. The map shows Yaren, the district where government offices are located.

2. Nauru is a small island country surrounded by coral reef. Compare the coastal strip where many people live with the land in the island's interior.

3. Phosphate mining has greatly changed the island's interior. It shows how extracting resources can reshape nature and raises questions about caring for the land.

Explorer words: Yaren · coral reef · coastal strip · island interior · phosphate · resource extraction · landscape change · environmental care · Pacific Ocean · Buada Lagoon

Postcard scene: Buada Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thecommonwealth.org/our-member-countries/nauru
- https://thecommonwealth.org/our-member-countries/naeoro

## Nepal · NP

Capital / seat: Kathmandu

1. Nepal is in Asia. Its capital is Kathmandu.

2. The Kathmandu Valley includes historic palace squares in Kathmandu, Patan and Bhaktapur. Buildings and sculptures reveal the art and history developed in these towns.

3. The valley contains Buddhist stupas at Swayambhu and Boudhanath and a Hindu temple at Pashupati. One region can teach us to recognise and respect different religious traditions.

Explorer words: Kathmandu · Kathmandu Valley · Patan · Bhaktapur · palace squares · Swayambhu · Boudhanath · Pashupati · Buddhism · Hinduism

Postcard scene: Swayambhunath

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/np/
- https://whc.unesco.org/en/list/121/

## Netherlands · NL

Capital / seat: Amsterdam

Amsterdam is the capital, while the government and parliament are in The Hague.

1. Amsterdam is the capital of the Netherlands. The government and parliament are based in The Hague.

2. Kinderdijk’s windmills and channels helped drain low-lying land. The windmills are part of a water-management system.

3. Amsterdam has a ring of canals lined with historic houses and streets.

Explorer words: Amsterdam · The Hague · Kinderdijk · windmills · canals · dykes · polders · water management · bicycles · Dutch

Postcard scene: Amsterdam canals

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/nl/
- https://whc.unesco.org/en/list/818/
- https://whc.unesco.org/en/list/1349/
- https://www.holland.com/de/tourist/lass-dich-inspirieren

## New Zealand · NZ

Capital / seat: Wellington

1. New Zealand’s capital, Wellington, sits at the southern tip of the North Island by the sea.

2. Māori is one of New Zealand’s official languages.

3. The kiwi is a flightless bird native to New Zealand that is mostly active at night.

Explorer words: Wellington · Milford Sound · Southern Alps · kiwi · Māori · Māori language · hāngī · silver fern · Fiordland · Wellington Cable Car

Postcard scene: Milford Sound

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Nicaragua · NI

Capital / seat: Managua

1. Nicaragua is in Americas. Its capital is Managua.

2. León Cathedral was built during a transition from Baroque to Neoclassical architecture. A single building can contain features associated with more than one period.

3. The cathedral's interior has abundant natural light and restrained decoration. Compare the lighting with the decorated sanctuary ceiling to explore how architects shape a space.

Explorer words: Managua · León Cathedral · Baroque · Neoclassicism · natural light · ceiling decoration · architectural styles · interior space · light in buildings · Ometepe Island

Postcard scene: Ometepe Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ni/
- https://whc.unesco.org/en/list/1236/

## Niger · NE

Capital / seat: Niamey

1. Niger is in Africa. Its capital is Niamey.

2. The Aïr and Ténéré reserves combine Saharan desert landscapes with volcanic-rock mountains. A desert is not just one endless sandy plain; it contains different landforms.

3. The Aïr mountains have climate and wildlife distinct from the surrounding desert. Comparing mountains and plains reveals how conditions for living things can differ.

Explorer words: Niamey · Aïr mountains · Ténéré desert · Sahara · volcanic rock · sandy landforms · mountain climate · desert wildlife · comparing landforms · Aïr and Ténéré desert

Postcard scene: Aïr and Ténéré desert

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ne/
- https://whc.unesco.org/en/list/573/

## Nigeria · NG

Capital / seat: Abuja

1. Nigeria’s capital, Abuja, sits near Aso Rock, a huge granite outcrop.

2. The Niger and Benue rivers meet near Lokoja before the Niger flows south to the sea.

3. Nigeria is home to many languages, kinds of music and films. English is the official language.

Explorer words: Abuja · Aso Rock · Niger River · Benue River · Yoruba · Hausa · jollof rice · Nollywood · talking drum · cocoa

Postcard scene: Aso Rock

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## North Korea · KP

Capital / seat: Pyongyang

1. North Korea is in Asia. Its capital is Pyongyang.

2. Heaven Lake on Mount Paektu fills a large depression formed by volcanic activity. Such a depression is called a caldera, recording volcanic history in rock and water.

3. The Mount Paektu area contains hot springs, lava features and landforms shaped by glaciers. One mountain shows how heat inside Earth and moving ice can reshape landscapes.

Explorer words: Pyongyang · Mount Paektu · Heaven Lake · caldera · volcanic activity · hot springs · lava · glaciers · geothermal heat · Earth processes

Postcard scene: Mount Paektu and Heaven Lake

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kp/
- https://www.unesco.org/en/iggp/mt-paektu-unesco-global-geopark

## North Macedonia · MK

Capital / seat: Skopje

1. North Macedonia is in Europe. Its capital is Skopje.

2. Lake Ohrid shelters many aquatic species that occur naturally only in this region. Protecting this ancient lake's habitats helps conserve its distinctive wildlife.

3. The lakeside town of Ohrid preserves historic monasteries and religious paintings. The area's natural and cultural value lets us study the lake alongside the town.

Explorer words: Skopje · Lake Ohrid · endemic species · aquatic wildlife · lake conservation · Ohrid · monasteries · religious paintings · nature and culture · Stone Bridge, Skopje

Postcard scene: Stone Bridge, Skopje

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mk/
- https://whc.unesco.org/en/list/99/

## Norway · NO

Capital / seat: Oslo

1. Norway’s capital, Oslo, sits by the sea near forests and fjords.

2. A fjord is a long sea inlet formed when glaciers cut deep valleys that later filled with seawater.

3. In northern Norway, people can sometimes see the northern lights dancing across the night sky.

Explorer words: Oslo · Geirangerfjord · northern lights · Svalbard · Scandinavian Mountains · Sámi people · salmon · brown cheese · Norwegian · reindeer

Postcard scene: Geirangerfjord

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Oman · OM

Capital / seat: Muscat

1. Oman is in Asia. Its capital is Muscat.

2. Oman's aflaj are historic channels that carry spring or underground water to homes and fields. They use gravity to move water from higher to lower ground.

3. Sharing this water depended on cooperation within communities. The channels teach us about farming technology and agreements for fairly using a valuable resource.

Explorer words: Muscat · aflaj · water channels · springs · groundwater · gravity · farming · water sharing · community cooperation · Sultan Qaboos Grand Mosque

Postcard scene: Sultan Qaboos Grand Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/om/
- https://whc.unesco.org/en/list/1207/

## Pakistan · PK

Capital / seat: Islamabad

1. Pakistan’s capital, Islamabad, is a planned city below the Margalla Hills.

2. Faisal Mosque is known for its four tall minarets set against the hills.

3. The Indus River flows through Pakistan toward the Arabian Sea.

Explorer words: Islamabad · Faisal Mosque · Margalla Hills · Indus River · K2 · truck art · Urdu · mango · biryani · markhor

Postcard scene: Faisal Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Palau · PW

Capital / seat: Ngerulmud

1. Palau is in Oceania. Its capital is Ngerulmud.

2. Palau's Rock Islands include mushroom-shaped limestone islands and coral reefs. Different habitats among the islands and reefs provide homes for varied marine life.

3. Some islands contain marine lakes separated from the ocean by land. Comparing isolated habitats helps us explore how living things adapt to different conditions.

Explorer words: Ngerulmud · Rock Islands · limestone islands · coral reefs · lagoon · marine lakes · marine life · habitats · isolated environments · adaptation

Postcard scene: Rock Islands Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pw/
- https://whc.unesco.org/en/list/1386/

## Palestine · PS

Capital / seat: Ramallah

Palestine claims East Jerusalem as its capital; Ramallah is its administrative centre.

1. Palestine claims East Jerusalem as its capital; Ramallah is its administrative centre.

2. Tell es-Sultan at ancient Jericho is a mound of layered remains left by people. Its wall and tower preserve evidence of an early settled community.

3. The spring of 'Ain es-Sultan lies beside the site. Connecting a reliable water source with a lasting settlement helps us explore the history of people settling in one place.

Explorer words: Ramallah · Ancient Jericho · Tell es-Sultan · archaeological layers · 'Ain es-Sultan spring · ancient wall · stone tower · settled life · community · archaeology

Postcard scene: Ancient Jericho / Tell es-Sultan

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ps/
- https://whc.unesco.org/en/list/1687/

## Panama · PA

Capital / seat: Panama City

1. Panama is in Americas. Its capital is Panama City.

2. The Panama Canal links the Atlantic and Pacific oceans. Ships use locks, chambers with changing water levels, to travel between an elevated lake and sea level.

3. Filling a lock raises a floating ship with the water; emptying it lowers the ship. The canal is an engineering system that uses buoyancy and gravity.

Explorer words: Panama City · Panama Canal · locks · Atlantic Ocean · Pacific Ocean · Gatun Lake · water level · buoyancy · gravity · engineering

Postcard scene: Panama Canal locks

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pa/
- https://pancanal.com/en/design-of-the-locks/

## Papua New Guinea · PG

Capital / seat: Port Moresby

1. Papua New Guinea is in Oceania. Its capital is Port Moresby.

2. The Kuk site in New Guinea's highlands preserves evidence of early farming. Archaeologists have found raised cultivation areas and ditches dug to drain wet ground.

3. Kuk helps researchers study the development from gathering or using plants to farming. Ditches and changes in soil can reveal how people transformed their way of life.

Explorer words: Port Moresby · Kuk Early Agricultural Site · New Guinea highlands · early farming · raised cultivation areas · drainage ditches · wetlands · soil evidence · archaeology · Parliament Haus, Port Moresby

Postcard scene: Parliament Haus, Port Moresby

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pg/
- https://whc.unesco.org/en/list/887/

## Paraguay · PY

Capital / seat: Asunción

1. Paraguay is in Americas. Its capital is Asunción.

2. Trinidad and Jesús de Tavarangue preserve seventeenth- and eighteenth-century mission settlements. Homes, schools and workshops, as well as churches, reveal community life.

3. The sites' architecture and art combine Indigenous elements with European styles. Studying these cultural encounters also means learning about the experiences of Indigenous people.

Explorer words: Asunción · Trinidad mission ruins · Jesús de Tavarangue · 17th–18th centuries · historic schools · workshops · Indigenous culture · cultural encounters · architectural styles · Itaipu Dam

Postcard scene: Itaipu Dam

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/py/
- https://whc.unesco.org/en/list/648/

## Peru · PE

Capital / seat: Lima

1. Peru’s capital, Lima, is on the Pacific coast; the Andes and Amazon rainforest also reach across Peru.

2. Machu Picchu is an old city built high in the Andes by the Inca people.

3. Potatoes were cultivated in the Andes long ago, and Peru grows many different kinds.

Explorer words: Lima · Machu Picchu · Andes Mountains · Amazon River · alpaca · potato · ceviche · Quechua · Nazca Lines · quinoa

Postcard scene: Machu Picchu

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Philippines · PH

Capital / seat: Manila

1. The Philippines’ capital, Manila, sits beside Manila Bay on the island of Luzon.

2. The Banaue Rice Terraces follow mountain slopes and show generations of Ifugao farming knowledge.

3. The Philippines is a country of thousands of islands in the western Pacific.

Explorer words: Manila · Banaue Rice Terraces · Ifugao people · Luzon · jeepney · mango · adobo · tarsier · Filipino · Pacific Ocean

Postcard scene: Banaue Rice Terraces

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Poland · PL

Capital / seat: Warsaw

1. Poland’s capital, Warsaw, stretches along both sides of the Vistula River.

2. Much of Warsaw’s Old Town was rebuilt after World War II.

3. European bison live in Poland’s Białowieża Forest.

Explorer words: Warsaw · Warsaw Old Town · Royal Castle · Vistula River · Białowieża Forest · European bison · pierogi · Chopin · Polish · Baltic Sea

Postcard scene: Warsaw Old Town & Royal Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Portugal · PT

Capital / seat: Lisbon

1. Portugal’s capital, Lisbon, stands on hills near the mouth of the Tagus River.

2. Belém Tower was built in the early 1500s to help guard Lisbon’s riverfront.

3. Portugal makes cork, used for bottle stoppers, from the bark of cork oak trees.

Explorer words: Lisbon · Belém Tower · Tagus River · azulejo tiles · yellow tram · cork oak · pastel de nata · Atlantic Ocean · Portuguese · Madeira

Postcard scene: Belém Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Qatar · QA

Capital / seat: Doha

1. Qatar is in Asia. Its capital is Doha.

2. Al Zubarah was a coastal town known for pearling and trade. Its harbour and residential remains reveal connections made between regions through the sea.

3. Wind-blown desert sand covered and protected remains of streets and buildings. Archaeologists study homes and channels beneath the sand to understand the past town.

Explorer words: Doha · Al Zubarah · pearling · coastal trade · historic harbour · desert sand · house remains · historic canal · excavation · maritime connections

Postcard scene: Al Zubarah Archaeological Site

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/qa/
- https://whc.unesco.org/en/list/1402/

## Republic of Korea · KR

Capital / seat: Seoul

1. South Korea is in East Asia, on the southern part of the Korean Peninsula. Seoul is its capital.

2. Hangul was developed under King Sejong and introduced in 1446.

3. In Seoul, you can see the tiled roofs of Bukchon Hanok Village and N Seoul Tower together.

Explorer words: Seoul · N Seoul Tower · Bukchon Hanok Village · Jeju Island · Hallasan · kimchi · bibimbap · Hangul · hanbok · taekwondo

Postcard scene: N Seoul Tower & Bukchon Hanok Village

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Republic of the Congo · CG

Capital / seat: Brazzaville

1. Republic of the Congo is in Africa. Its capital is Brazzaville.

2. Odzala-Kokoua brings together forests, savannas and other ecosystems. Comparing grassland and forest reveals different habitats for living things.

3. The area is important for forest elephants and diverse primates in Central Africa. It also records how forests spread and change, helping researchers study natural history.

Explorer words: Brazzaville · Odzala-Kokoua · forest elephants · primates · savanna · tropical forest · ecosystems · forest succession · habitats · Sangha forest landscape in the Republic of the Congo

Postcard scene: Sangha forest landscape in the Republic of the Congo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cg/
- https://whc.unesco.org/en/list/692/

## Romania · RO

Capital / seat: Bucharest

1. Romania is in Europe. Its capital is Bucharest.

2. The Danube reaches the Black Sea through a delta of channels and wetlands. Sediment carried by a river can build up and reshape the land at its mouth.

3. Lakes and marshes in the Danube Delta shelter many birds and freshwater fish. Protecting this connected landscape helps conserve life between river and sea.

Explorer words: Bucharest · Danube Delta · Danube River · Black Sea · delta · sediment · river mouth · wetlands · freshwater fish · Bran Castle

Postcard scene: Bran Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ro/
- https://whc.unesco.org/en/list/588/

## Russia · RU

Capital / seat: Moscow

1. Moscow is Russia’s capital. Russia is a very large country that spans Europe and Asia.

2. Lake Baikal in Siberia is the world’s deepest lake and holds a great deal of fresh water.

3. The Trans-Siberian Railway travels a very long distance from Moscow toward eastern Russia.

Explorer words: Moscow · Saint Basil’s Cathedral · Red Square · Lake Baikal · Siberia · taiga · matryoshka doll · Russian · ballet · Trans-Siberian Railway

Postcard scene: Saint Basil’s Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Rwanda · RW

Capital / seat: Kigali

1. Rwanda is in Africa. Its capital is Kigali.

2. Nyungwe National Park contains rainforest, peat bogs and grassland. Its varied environments support trees, ferns and wildlife living together.

3. Nyungwe is important for chimpanzees and many birds. Losing forest changes food supplies and homes, so protecting animals also means caring for their habitats.

Explorer words: Kigali · Nyungwe National Park · rainforest · peat bogs · grasslands · ferns · chimpanzees · birds · biodiversity · Volcanoes National Park and mountain gorillas

Postcard scene: Volcanoes National Park and mountain gorillas

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rw/
- https://whc.unesco.org/en/list/1697/

## Saint Kitts and Nevis · KN

Capital / seat: Basseterre

1. Saint Kitts and Nevis is in Americas. Its capital is Basseterre.

2. Brimstone Hill Fortress records seventeenth- and eighteenth-century Caribbean defensive architecture. Its hilltop setting shows how high ground helped people observe the surroundings.

3. The fortress was designed by the British and built by enslaved Africans. Studying the building also means remembering the lives and dignity of the people who worked there.

Explorer words: Basseterre · Brimstone Hill Fortress · Caribbean Sea · hill · defensive architecture · 17th–18th centuries · colonial period · construction labour · human dignity · remembering history

Postcard scene: Brimstone Hill Fortress National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kn/
- https://whc.unesco.org/en/list/910/

## Saint Lucia · LC

Capital / seat: Castries

1. Saint Lucia is in Americas. Its capital is Castries.

2. Saint Lucia's Pitons are two volcanic peaks rising side by side near the sea. Nearby hot springs and geothermal features show how underground heat affects landscapes.

3. Forests and coral reefs occur around the Pitons. Studying mountain plants alongside marine life reveals that one region can contain several different ecosystems.

Explorer words: Castries · Pitons · Gros Piton · Petit Piton · volcanic peaks · hot springs · geothermal heat · coral reefs · forests · Pitons Management Area

Postcard scene: Pitons Management Area

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lc/
- https://whc.unesco.org/en/list/1161/

## Saint Vincent and the Grenadines · VC

Capital / seat: Kingstown

1. Saint Vincent and the Grenadines is in Americas. Its capital is Kingstown.

2. The botanical gardens near Kingstown feature the St Vincent parrot. This national bird lives naturally in forests on the island of St Vincent.

3. Dark View Falls has two waterfalls descending from cliffs in a forested setting. Studying water, plants and birds together reveals connections within the natural environment.

Explorer words: Kingstown · St Vincent parrot · botanical gardens · national bird · Dark View Falls · rainforest · cliffs · waterfalls · bird observation · Kingstown and its surroundings

Postcard scene: Kingstown and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://discoversvg.com/what-to-do/eco-adventures/

## Samoa · WS

Capital / seat: Apia

1. Samoa is in Oceania. Its capital is Apia.

2. To Sua Ocean Trench on Upolu is a deep natural pool below ground level. Its water and surrounding landforms reveal an unusual space in the island's landscape.

3. Traditional Samoan fale can have open sides. Looking at their design helps us think about how climate and ways of living influence architecture.

Explorer words: Apia · To Sua Ocean Trench · Upolu · natural pool · island landforms · fale · open-sided houses · traditional architecture · climate and housing · Samoan ways of life

Postcard scene: To Sua Ocean Trench

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.samoa.travel/pagepreview/must-dos-in-samoa

## San Marino · SM

Capital / seat: City of San Marino

1. San Marino is in Europe. Its capital is City of San Marino.

2. San Marino's historic centre on Mount Titano contains defensive towers, walls and gates. This hilltop town shows the relationship between terrain and architecture.

3. The historic centre records a republican tradition extending from the Middle Ages. Civic institutions still use the town, showing how heritage can remain part of everyday life.

Explorer words: City of San Marino · Mount Titano · San Marino historic centre · defensive towers · city walls · city gates · Middle Ages · republic · civic institutions · living heritage

Postcard scene: San Marino Historic Centre and Mount Titano

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sm/
- https://whc.unesco.org/en/list/1245/

## São Tomé and Príncipe · ST

Capital / seat: São Tomé

1. São Tomé and Príncipe is in Africa. Its capital is São Tomé.

2. Príncipe is a volcanic island in the Gulf of Guinea. Its landscape helps us explore how volcanic activity can create land rising from the sea.

3. Príncipe's biosphere reserve includes land, surrounding sea and smaller islands. It shows why conservation needs to consider forests, coasts and marine areas together.

Explorer words: São Tomé · Príncipe · Gulf of Guinea · volcanic island · island formation · biosphere reserve · land and sea · islets · coast · Pico Cão Grande and São Tomé rainforest

Postcard scene: Pico Cão Grande and São Tomé rainforest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.unesco.org/en/mab/island-principe

## Saudi Arabia · SA

Capital / seat: Riyadh

1. Riyadh is Saudi Arabia’s capital. Saudi Arabia covers a large part of the Arabian Peninsula.

2. At Hegra, the Nabataeans carved tombs into rock about 2,000 years ago.

3. Saudi Arabia has coastlines on both the Red Sea and the Persian Gulf.

Explorer words: Riyadh · Hegra · AlUla · Arabian Desert · Red Sea · camel · dates · kabsa · Arabic · Nabataean heritage

Postcard scene: Hegra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Senegal · SN

Capital / seat: Dakar

1. Senegal is in Africa. Its capital is Dakar.

2. Djoudj National Bird Sanctuary includes lakes and wetlands in the Senegal River delta. Pelicans, herons and many other birds use its waters to feed and rest.

3. Connected lakes, streams and ponds provide different places for birds. Studying a wetland means considering the whole network of water, rather than just one pond.

Explorer words: Dakar · Djoudj National Bird Sanctuary · Senegal River · delta · pelicans · herons · lakes · ponds · wetlands · Lake Retba

Postcard scene: Lake Retba

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sn/
- https://whc.unesco.org/en/list/25/

## Serbia · RS

Capital / seat: Belgrade

1. Serbia is in Europe. Its capital is Belgrade.

2. Studenica Monastery was founded in the late twelfth century. Its two main churches, built with white marble, offer a way to study historic building materials and forms.

3. The churches preserve thirteenth- and fourteenth-century Byzantine paintings. Studying buildings and pictures together reveals how art expressed religious life and ideas.

Explorer words: Belgrade · Studenica Monastery · white marble · 12th century · Byzantine painting · historic churches · building materials · medieval art · religion and art · Kalemegdan Fortress, Belgrade

Postcard scene: Kalemegdan Fortress, Belgrade

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rs/
- https://whc.unesco.org/en/list/389/

## Seychelles · SC

Capital / seat: Victoria

1. Seychelles is in Africa. Its capital is Victoria.

2. Vallée de Mai on Praslin preserves a largely natural palm forest. The coco de mer palm is known for its exceptionally large seed.

3. Seeds are a starting point for new plants. Comparing palms and their seeds at Vallée de Mai helps us explore different ways that plants reproduce and grow.

Explorer words: Victoria · Vallée de Mai · Praslin · coco de mer · palm forest · seeds · plant reproduction · tree growth · natural forest · forest conservation

Postcard scene: Vallée de Mai palm forest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sc/
- https://whc.unesco.org/en/list/261/

## Sierra Leone · SL

Capital / seat: Freetown

1. Sierra Leone is in Africa. Its capital is Freetown.

2. The Gola-Tiwai area combines rainforest with an island in the Moa River. Protecting forest and river together helps wildlife that depends on different habitats.

3. The area shelters animals needing protection, including pygmy hippopotamuses and chimpanzees. Go beyond learning their names to ask why they need forests and water.

Explorer words: Freetown · Gola-Tiwai · Moa River · river island · rainforest · pygmy hippopotamus · chimpanzee · habitat connections · wildlife conservation · Tacugama chimpanzees

Postcard scene: Tacugama chimpanzees

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sl/
- https://whc.unesco.org/en/list/1746/

## Singapore · SG

Capital / seat: Singapore

1. Singapore is a city-state whose capital shares its name. The Merlion combines a lion’s head with a fish’s body.

2. Singapore Botanic Gardens is a UNESCO World Heritage site where many plants and orchids grow.

3. Hawker centres bring many food stalls together. Dishes such as chicken rice reflect Singapore’s different cultures.

Explorer words: Singapore · Merlion · Marina Bay · Singapore River · Singapore Botanic Gardens · orchids · Gardens by the Bay · hawker centres · chicken rice · Little India

Postcard scene: Supertrees, Gardens by the Bay

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sg/
- https://www.visitsingapore.com/see-do-singapore/recreation-leisure/viewpoints/merlion-park/
- https://www.visitsingapore.com/things-to-do/top-things-to-do/city-in-nature/
- https://www.visitsingapore.com/content/visitsingapore/en/travel-tips/travelling-to-singapore/itineraries/singapore-city-tour-guide/

## Slovakia · SK

Capital / seat: Bratislava

1. Slovakia is in Europe. Its capital is Bratislava.

2. The Spiš Castle area preserves medieval defensive and religious buildings. Comparing Romanesque and Gothic styles reveals changes in European architecture.

3. Nearby Levoča contains a walled historic town and the church of St James. Its painted sculptures show that a building can bring together several forms of art.

Explorer words: Bratislava · Spiš Castle · Levoča · church of St James · Romanesque · Gothic · Middle Ages · defences · painted sculpture · walled town

Postcard scene: Spiš Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sk/
- https://whc.unesco.org/en/list/620/

## Slovenia · SI

Capital / seat: Ljubljana

1. Slovenia is in Europe. Its capital is Ljubljana.

2. Škocjan Caves contain long passages and underground waterfalls within limestone. They reveal karst processes, in which water dissolves and wears away rock.

3. When a cave roof collapses, it can leave a depression at the surface. Studying both above and below ground reveals connected spaces beneath our feet.

Explorer words: Ljubljana · Škocjan Caves · limestone · karst · underground passages · underground waterfalls · rock dissolution · erosion · collapse depressions · underground spaces

Postcard scene: Škocjan Caves

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/si/
- https://whc.unesco.org/en/list/390/

## Solomon Islands · SB

Capital / seat: Honiara

1. Solomon Islands is in Oceania. Its capital is Honiara.

2. Lake Tegano on Rennell Island was once an atoll lagoon. Landscapes can change as coral-built land rises above the sea.

3. The lake contains brackish water, limestone islets and distinctive wildlife. Studying the island's forest and lake together connects geological history with ecosystems.

Explorer words: Honiara · Rennell Island · Lake Tegano · former lagoon · raised coral atoll · brackish water · limestone islets · island forest · endemic species · Marovo Lagoon

Postcard scene: Marovo Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sb/
- https://whc.unesco.org/en/list/854/

## Somalia · SO

Capital / seat: Mogadishu

1. Somalia is in Africa. Its capital is Mogadishu.

2. Mogadishu is a coastal city historically connected to other regions through Indian Ocean trade. Its historic buildings record encounters between travelling people and cultures.

3. Mogadishu's Secondo-Lido Lighthouse helped ships navigate along the coast. A lighthouse shows how architecture can combine a distinctive appearance with a practical purpose.

Explorer words: Mogadishu · Indian Ocean trade · coastal city · Secondo-Lido Lighthouse · navigation · historic port · cultural encounters · urban buildings · sea routes · Mogadishu historic coast

Postcard scene: Mogadishu historic coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/tentativelists/6754/

## South Africa · ZA

Capital / seat: Pretoria

Pretoria is the administrative capital, Cape Town the legislative capital, and Bloemfontein the judicial capital.

1. South Africa shares capital-city roles: Pretoria is administrative, Cape Town is legislative, and Bloemfontein is judicial.

2. Table Mountain, with its flat top, rises beside Cape Town.

3. Nelson Mandela worked for democracy against racial discrimination and became South Africa’s first Black president in 1994.

Explorer words: Pretoria · Cape Town · Table Mountain · Kruger National Park · Robben Island · African penguin · springbok · Nelson Mandela · rooibos tea · South African Sign Language

Postcard scene: Table Mountain & Cape Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## South Sudan · SS

Capital / seat: Juba

1. South Sudan is in Africa. Its capital is Juba.

2. The Sudd wetlands stretch along the White Nile in South Sudan, with broad landscapes of water and vegetation.

3. Papyrus and reeds grow in the Sudd. Open water and richly vegetated wetland areas lie together.

Explorer words: Juba · Africa · Sudd wetlands · White Nile · Papyrus · Reeds · wetland ecosystem · aquatic plants · habitats · water and plants

Postcard scene: Sudd wetlands on the White Nile

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ss/
- https://whc.unesco.org/en/tentativelists/6276/

## Spain · ES

Capital / seat: Madrid

1. Madrid is Spain’s capital. The Sagrada Família is a church in Barcelona designed by Antoni Gaudí.

2. Columns inside the Sagrada Família branch like tree trunks. Gaudí studied natural forms to design structures that support the building’s weight.

3. Along with Spanish, Catalan, Basque and Galician are spoken in different parts of Spain.

Explorer words: Madrid · Sagrada Família · Barcelona · Pyrenees · Mediterranean Sea · flamenco · paella · olives · Catalan · Galician

Postcard scene: Sagrada Família

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://blog.sagradafamilia.org/en/columns-sagrada-familia-geometry-mechanics-materials-stone-forest/

## Sri Lanka · LK

Capital / seat: Sri Jayewardenepura Kotte

Sri Jayewardenepura Kotte is the legislative capital; many government offices are in Colombo.

1. Sri Jayewardenepura Kotte is the legislative capital; many government offices are in Colombo.

2. Sigiriya preserves a historic city built on and around a granite rock about 180 metres high. It shows how builders used a dramatic elevated landform.

3. The approach includes stairs and remains of a large lion-shaped structure. Rock, brick and plaster together reveal the meeting of a natural landscape with architecture.

Explorer words: Sri Jayewardenepura Kotte · Sigiriya · granite · Lion Rock · historic city · high ground · staircases · bricks · plaster · nature and architecture

Postcard scene: Sigiriya

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lk/
- https://www.gov.lk/sri-lanka/country-overview
- https://whc.unesco.org/en/list/202/

## Sudan · SD

Capital / seat: Khartoum

1. Sudan is in Africa. Its capital is Khartoum.

2. Meroe was a centre of the Kingdom of Kush. Its pyramids, temples and residential remains show that the Nile region held civilisations beyond ancient Egypt.

3. The surrounding archaeological sites also preserve water-management structures. Collecting and using water was important to the growth of towns in this dry region.

Explorer words: Khartoum · Meroe · Kingdom of Kush · pyramids · Nile River · Atbara River · historic temples · residential remains · water management · dry region

Postcard scene: Meroë pyramids

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sd/
- https://whc.unesco.org/en/list/1336/

## Suriname · SR

Capital / seat: Paramaribo

1. Suriname is in Americas. Its capital is Paramaribo.

2. Paramaribo's historic centre combines Dutch architectural influences with local materials and techniques. A style can take different forms through local conditions and craftsmanship.

3. Paramaribo preserves a street layout inherited from its seventeenth- and eighteenth-century town. Streets and a whole town, as well as individual buildings, can be historical evidence.

Explorer words: Paramaribo · historic Paramaribo · local materials · building techniques · Dutch architecture · craftspeople · street layout · 17th–18th centuries · urban history · cultural encounters

Postcard scene: Paramaribo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sr/
- https://whc.unesco.org/en/list/940/

## Sweden · SE

Capital / seat: Stockholm

1. Sweden’s capital, Stockholm, spreads across many islands connected by bridges.

2. In northern Sweden, summer nights are very bright, and the northern lights can appear in winter.

3. Stockholm’s Vasa Museum displays a huge ship built in the 1600s.

Explorer words: Stockholm · Gamla Stan · Vasa ship · northern lights · forests · moose · cinnamon bun · meatballs · Swedish · Dala horse

Postcard scene: Gamla Stan, Stockholm

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Switzerland · CH

Capital / seat: Bern

Bern is Switzerland’s federal city and the seat of its federal government.

1. Bern is Switzerland’s federal city and seat of government. It is commonly described as the capital, while its official title is federal city.

2. Switzerland has the Alps, the Jura Mountains and a plateau between them. Mountain railways reach high into the Alps.

3. Switzerland has four national languages: German, French, Italian and Romansh. Language use varies by region.

Explorer words: Bern · federal city · Alps · Jura Mountains · Swiss Plateau · mountain railways · German · French · Italian · Romansh

Postcard scene: Zytglogge, Bern

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ch/
- https://www.aboutswitzerland.eda.admin.ch/en/political-system
- https://www.aboutswitzerland.eda.admin.ch/en/geography
- https://www.aboutswitzerland.eda.admin.ch/en/languages-and-dialects

## Syria · SY

Capital / seat: Damascus

1. Syria is in Asia. Its capital is Damascus.

2. Bosra preserves a large Roman theatre from the second century. Its curved rows of seats help us imagine a space where people gathered to watch performances.

3. Bosra was an important stop on historic caravan routes towards Mecca. Its theatre and religious buildings record people and cultures passing through across different periods.

Explorer words: Damascus · Bosra · Roman theatre · 2nd century · curved seating · performances · caravan trade · Mecca · religious architecture · Ancient City of Bosra

Postcard scene: Ancient City of Bosra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sy/
- https://whc.unesco.org/en/list/22/

## Taiwan · TW

Capital / seat: Taipei

1. Taiwan is in Asia. Its capital is Taipei.

2. Taipei 101 contains a large suspended mass that reduces movement caused by wind. This tuned mass damper helps make a tall building more comfortable to use.

3. The observatory looks across Taipei's rivers, basin and surrounding mountains. A high viewpoint helps us explore the relationship between a city's buildings, water and terrain.

Explorer words: Taipei · Taipei 101 · tuned mass damper · reducing sway · wind · tall buildings · observatory · Taipei basin · urban rivers · surrounding mountains

Postcard scene: Taipei 101 and Taipei basin

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.taipei-101.com.tw/en/observatory/feature
- https://www.taipei-101.com.tw/en/observatory/feature/damper

## Tajikistan · TJ

Capital / seat: Dushanbe

1. Tajikistan is in Asia. Its capital is Dushanbe.

2. Tajik National Park in the Pamirs contains high peaks, plateaux and many glaciers. Its environment reveals how mountain height and seasons influence temperature.

3. The park brings together glaciers, rivers and lakes. Following the connection from snow and ice to flowing water helps us explore the relationship between mountains and water.

Explorer words: Dushanbe · Pamirs · Tajik National Park · plateaux · glaciers · high peaks · seasonal temperature · rivers · mountain lakes · Iskanderkul

Postcard scene: Iskanderkul

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tj/
- https://whc.unesco.org/en/list/1252/

## Tanzania · TZ

Capital / seat: Dodoma

1. Tanzania’s capital, Dodoma, is near the center of the country.

2. Mount Kilimanjaro is the highest mountain in Africa.

3. Many animals travel across the grasslands of northern Tanzania’s Serengeti.

Explorer words: Dodoma · Mount Kilimanjaro · Serengeti · savanna · baobab tree · elephant · Swahili · Zanzibar · ugali · coffee

Postcard scene: Mount Kilimanjaro

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Thailand · TH

Capital / seat: Bangkok

1. Thailand’s capital, Bangkok, is home to a grand palace and the Chao Phraya River.

2. Thailand’s landscapes range from northern mountains and forests to warm southern seas.

3. Songkran is a festival when families and neighbors celebrate the Thai New Year together.

Explorer words: Bangkok · Grand Palace · Chao Phraya River · Chiang Mai · Asian elephant · pad thai · mango sticky rice · tuk-tuk · Thai · Songkran

Postcard scene: Grand Palace

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Timor-Leste · TL

Capital / seat: Dili

1. Timor-Leste is in Asia. Its capital is Dili.

2. Timor-Leste's tais is a traditional handwoven textile. Preparing cotton, dyeing it with plants and weaving it require time and skill.

3. Tais colours and motifs vary between communities, and the cloth is used in clothing, ceremonies and festivals. Its patterns reveal culture expressed through everyday objects.

Explorer words: Dili · tais · handweaving · cotton · plant dyes · textile motifs · colours · traditional clothing · festivals · Dili and Cristo Rei hill

Postcard scene: Dili and Cristo Rei hill

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/USL/tais-traditional-textile-01688

## Togo · TG

Capital / seat: Lomé

1. Togo is in Africa. Its capital is Lomé.

2. The Batammariba of Koutammakou build tower-like earth houses called takienta. Their design reveals both building knowledge and the community's ways of living.

3. Villages here include fields, forests, springs and ceremonial spaces. Studying homes together with their surroundings helps us understand a cultural landscape.

Explorer words: Lomé · Koutammakou · Batammariba · takienta · earth houses · tower-houses · fields · springs · ceremonial spaces · cultural landscape

Postcard scene: Koutammakou and Batammariba earth houses

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tg/
- https://whc.unesco.org/en/list/1140/

## Tonga · TO

Capital / seat: Nuku'alofa

1. Tonga is in Oceania. Its capital is Nuku'alofa.

2. Haʻamonga ʻa Maui on Tongatapu is a historic gateway made from three large stones. Two uprights support a crosspiece, inviting us to explore structure and balance.

3. Tongan culture includes traditional dance and a long royal heritage. History survives not only in stone monuments but also in dances and performances passed between generations.

Explorer words: Nuku'alofa · Haʻamonga ʻa Maui · Tongatapu · stone gateway · three stones · uprights · crosspiece · balance · traditional dance · royal heritage

Postcard scene: Haʻamonga ʻa Maui

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thekingdomoftonga.com/true-culture/

## Trinidad and Tobago · TT

Capital / seat: Port of Spain

1. Trinidad and Tobago is in Americas. Its capital is Port of Spain.

2. The steelpan, developed in Trinidad and Tobago, is a metal percussion instrument. Striking different areas of its surface produces notes of different pitches.

3. The steelpan developed in the 1930s and 1940s and is the national instrument. Its history of transforming metal containers into instruments links music with creative making.

Explorer words: Port of Spain · steelpan · percussion instrument · metal · pitch · vibration · national instrument · 1930s–1940s · instrument making · Trinidad Carnival

Postcard scene: Trinidad Carnival

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://foreign.gov.tt/about/trinidad-tobago/national-symbols/national-instrument/

## Tunisia · TN

Capital / seat: Tunis

1. Tunisia is in Africa. Its capital is Tunis.

2. Carthage was founded on the Gulf of Tunis and grew into a Mediterranean trading centre. It shows how a harbour city connects distant regions through sea routes.

3. After the earlier Carthage was destroyed, a Roman city was built on the same site. Comparing remains from different periods reveals how a town can be rebuilt over time.

Explorer words: Tunis · Carthage · Gulf of Tunis · Mediterranean trade · harbour city · sea routes · Roman period · urban rebuilding · comparing remains · archaeology

Postcard scene: Carthage

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tn/
- https://whc.unesco.org/en/list/37/

## Türkiye · TR

Capital / seat: Ankara

1. Ankara is Türkiye’s capital. Istanbul stretches across Europe and Asia on the Bosphorus.

2. Istanbul’s Hagia Sophia is an old landmark that has been used in different eras.

3. Türkiye has coastlines, high mountains and the unusual rock landscapes of Cappadocia.

Explorer words: Ankara · Istanbul · Hagia Sophia · Bosphorus · Cappadocia · Turkish · simit · baklava · tea · Mediterranean Sea

Postcard scene: Hagia Sophia & Blue Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Turkmenistan · TM

Capital / seat: Ashgabat

1. Turkmenistan is in Asia. Its capital is Ashgabat.

2. Merv was an oasis city on the Central Asian Silk Roads. Where water and routes met in a dry region, people settled and exchanged goods.

3. Merv preserves traces of settlements across a long period. Walls and building locations reveal how urban life changed repeatedly around the same oasis.

Explorer words: Ashgabat · Merv · Silk Roads · oasis · Central Asia · dry region · historic walls · trade · settlement remains · Ancient Merv

Postcard scene: Ancient Merv

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tm/
- https://whc.unesco.org/en/list/886/

## Tuvalu · TV

Capital / seat: Funafuti

The capital Funafuti is an atoll made up of several islands. The pin marks Vaiaku on Fongafale, where government offices are located.

1. The capital Funafuti is an atoll made up of several islands. The pin marks Vaiaku on Fongafale, where government offices are located.

2. Tuvalu consists of nine low-lying coral islands in the Pacific. Several contain lagoons surrounded by reefs, revealing close connections between islands and sea.

3. A lagoon is a coastal body of water connected with the sea. Life on low islands invites us to consider reef and coastal care and cooperation on climate change.

Explorer words: Funafuti · coral islands · lagoons · coral reefs · Pacific Ocean · low-lying land · islands and sea · coastal care · climate change · Funafuti Conservation Area

Postcard scene: Funafuti Conservation Area

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://finance.gov.tv/contact-us/
- https://finance.gov.tv/wp-content/uploads/2023/11/181024-TvICT-ESMP-Rev-G-2.pdf
- https://thecommonwealth.org/our-member-countries/tuvalu

## Uganda · UG

Capital / seat: Kampala

1. Uganda is in Africa. Its capital is Kampala.

2. Bwindi National Park lies where lowland and mountain forests meet. Many trees, ferns, birds and butterflies live across its varied forest environments.

3. Bwindi is also habitat for endangered mountain gorillas. Protecting these animals requires caring for the forest that provides their food and homes.

Explorer words: Kampala · Bwindi National Park · mountain gorilla · lowland forest · mountain forest · ferns · butterflies · birds · endangerment · Bwindi Impenetrable National Park

Postcard scene: Bwindi Impenetrable National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ug/
- https://whc.unesco.org/en/list/682/

## Ukraine · UA

Capital / seat: Kyiv

1. Ukraine is in Europe. Its capital is Kyiv.

2. Kyiv's Saint-Sophia Cathedral records the city's eleventh-century history. Its connection with a cathedral in Constantinople reveals cultural links between distant cities.

3. Kyiv-Pechersk Lavra is a historic monastery with religious and intellectual influence. Comparing it with the cathedral reveals different roles for buildings within one city.

Explorer words: Kyiv · Saint-Sophia Cathedral · Kyiv-Pechersk Lavra · 11th century · Constantinople · cultural connections · monastery · religious architecture · history of learning · building functions

Postcard scene: Saint Sophia Cathedral, Kyiv

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ua/
- https://whc.unesco.org/en/list/527/

## United Arab Emirates · AE

Capital / seat: Abu Dhabi

1. The United Arab Emirates is a federation of seven emirates. Abu Dhabi is the capital; Dubai is a city in another emirate.

2. Abu Dhabi has the Sheikh Zayed Grand Mosque, while Dubai is home to the tall Burj Khalifa.

3. The UAE has both deserts and a coast. Al Ain has oases and historic cultural sites.

Explorer words: Abu Dhabi · Dubai · seven emirates · Sheikh Zayed Grand Mosque · Burj Khalifa · Al Ain Oasis · Arabian Peninsula · desert · coast · Arabic

Postcard scene: Al Ain Oasis and falaj irrigation

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ae/
- https://u.ae/en/about-the-uae/fact-sheet
- https://u.ae/en/about-the-uae/the-seven-emirates

## United Kingdom · GB

Capital / seat: London

1. London is the UK’s capital. Big Ben is the bell inside the Elizabeth Tower.

2. The United Kingdom is made up of England, Scotland, Wales and Northern Ireland.

3. The River Thames flows through London, where red double-decker buses are a familiar sight.

Explorer words: London · Big Ben · River Thames · England · Scotland · Wales · Northern Ireland · double-decker bus · English · fish and chips

Postcard scene: Elizabeth Tower & Parliament

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## United States · US

Capital / seat: Washington D.C.

1. Washington, D.C. is the U.S. capital, and the country has 50 states.

2. Mount Rushmore is a mountain carving of four U.S. presidents in South Dakota.

3. The U.S. has many landscapes, from the Grand Canyon and Mississippi River to the islands of Hawaii.

Explorer words: Washington, D.C. · Mount Rushmore · Grand Canyon · Mississippi River · Alaska · Hawaii · 50 states · jazz · baseball · hamburger

Postcard scene: Mount Rushmore

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Uruguay · UY

Capital / seat: Montevideo

1. Montevideo is Uruguay’s capital. The city stands beside the wide Río de la Plata estuary.

2. Montevideo’s Rambla follows the waterfront, offering places to walk, cycle and see the coast.

3. Candombe is drum music and dance rooted in communities of African descent. Several Montevideo neighbourhoods keep the tradition alive.

Explorer words: Montevideo · Río de la Plata · Rambla · candombe · drums · Sur district · Palermo district · Cordón district · estuary · Spanish

Postcard scene: Montevideo coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uy/
- https://montevideo.gub.uy/areas-tematicas/amiga-del-futbol/descubri-montevideo
- https://www.montevideo.gub.uy/areas-tematicas/cultura-y-tiempo-libre/parques/rambla
- https://ich.unesco.org/en/RL/candombe-and-its-socio-cultural-space-a-community-practice-00182

## Uzbekistan · UZ

Capital / seat: Tashkent

1. Tashkent is Uzbekistan’s capital. Samarkand and Bukhara were meeting places for cultures along the Silk Roads.

2. Samarkand has historic mosques and great squares, with blue tilework decorating its buildings.

3. Palov is a rice-based dish. Sharing it with guests and neighbours is an important living tradition.

Explorer words: Tashkent · Samarkand · Bukhara · Itchan Kala · Silk Roads · Registan Square · blue tilework · palov · oasis · Uzbek

Postcard scene: Registan, Samarkand

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uz/
- https://whc.unesco.org/en/list/603/
- https://ich.unesco.org/en/RL/palov-culture-and-tradition-01166

## Vanuatu · VU

Capital / seat: Port Vila

1. Vanuatu is in Oceania. Its capital is Port Vila.

2. Chief Roi Mata's heritage survives on Efate, Lelepa and Artok. His residence and related places record a history extending across several islands.

3. Roi Mata's history is studied through both oral tradition and archaeology. Comparing people's remembered stories with physical remains gives us different ways to learn about the past.

Explorer words: Port Vila · Chief Roi Mata · Efate · Lelepa · Artok · historic residence · oral tradition · archaeology · historical evidence · Mount Yasur

Postcard scene: Mount Yasur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/vu/
- https://whc.unesco.org/en/list/1280/

## Vatican City · VA

Capital / seat: Vatican City

1. Vatican City is in Europe. Its capital is Vatican City.

2. Vatican City brings together St Peter's Basilica, its square, palaces and gardens. A small state can contain a long history of architecture and art.

3. Artists including Michelangelo and Bernini contributed to the basilica and its surroundings. A major building can be the result of many people's designs and skills.

Explorer words: Vatican City · St Peter's Basilica · St Peter's Square · Michelangelo · Bernini · palaces · gardens · colonnades · architecture and art · artistic collaboration

Postcard scene: Vatican City

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/va/
- https://whc.unesco.org/en/list/286/

## Venezuela · VE

Capital / seat: Caracas

1. Caracas is Venezuela’s capital. Venezuela lies in northern South America and has a Caribbean coast.

2. Angel Falls is in Canaima National Park, where water drops a long distance from a high cliff.

3. Canaima has flat-topped mountains called tepuis. Its distinctive landforms and wildlife are protected as World Heritage.

Explorer words: Caracas · Canaima National Park · Angel Falls · tepuis · Auyán-tepui · highlands · waterfalls · cliffs · Caribbean Sea · Spanish

Postcard scene: Angel Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ve/
- https://whc.unesco.org/en/list/701/
- https://whc.unesco.org/document/218578

## Vietnam · VN

Capital / seat: Hanoi

1. Vietnam’s capital, Hanoi, is near the Red River, while Ho Chi Minh City is in the south.

2. Ha Long Bay has many limestone islands and rocks rising out of the sea.

3. Tết is Vietnam’s Lunar New Year festival, when families gather to welcome the new year.

Explorer words: Hanoi · Ha Long Bay · Red River · Mekong River · rice fields · phở · bánh mì · Vietnamese · Tết · water puppetry

Postcard scene: Ha Long Bay

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## Yemen · YE

Capital / seat: Sana'a

1. Yemen is in Asia. Its capital is Sana'a.

2. Sana'a's old city lies in a high mountain valley and has been inhabited for a long time. Its setting offers a comparison with the environment of coastal towns.

3. Sana'a contains multi-storey tower-houses built with rammed earth. Using locally available material for substantial buildings reveals the knowledge of earlier builders.

Explorer words: Sana'a · Old City of Sana'a · mountain valley · tower-houses · rammed earth · multiple storeys · local materials · historic architecture · urban setting · long-inhabited settlement

Postcard scene: Old City of Sana'a

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ye/
- https://whc.unesco.org/en/list/385/

## Zambia · ZM

Capital / seat: Lusaka

1. Zambia is in Africa. Its capital is Lusaka.

2. Victoria Falls is where the Zambezi River plunges into basalt gorges. Falling water and worn rock help us study how water reshapes a landscape.

3. Sunlight can create rainbows in the spray rising from the falls. This heritage shared by Zambia and Zimbabwe also teaches us about cooperation across borders.

Explorer words: Lusaka · Victoria Falls · Mosi-oa-Tunya · Zambezi River · basalt · gorges · water spray · rainbows · erosion · cross-border cooperation

Postcard scene: Victoria Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zm/
- https://whc.unesco.org/en/list/509/

## Zimbabwe · ZW

Capital / seat: Harare

1. Zimbabwe is in Africa. Its capital is Harare.

2. Great Zimbabwe preserves a historic city of the Shona civilisation. Remains of this eleventh- to fifteenth-century trading centre reveal part of Africa's urban history.

3. The site's large stone walls preserve historic building skills. Observing their stones and curves helps us explore how people created major spaces using local materials.

Explorer words: Harare · Great Zimbabwe · Shona civilisation · stone walls · 11th–15th centuries · trading centre · curved walls · building skills · local materials · African urban history

Postcard scene: Great Zimbabwe stone enclosure

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zw/
- https://whc.unesco.org/en/list/364/
