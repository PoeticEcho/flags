# 197개국 교육 콘텐츠

Edition: 2026-10-02-education

## 아프가니스탄 · AF

수도·정부 소재지: 카불

1. 아프가니스탄은 아시아에 있어요. 수도는 카불예요.

2. 잠의 미나레트는 약 65m 높이의 벽돌 탑이에요. 벽돌로 만든 반복 무늬와 푸른 타일 장식에 옛 건축가의 솜씨가 담겨 있어요.

3. 잠의 탑은 하리루드강과 잠강이 만나는 산골짜기에 서 있어요. 강이 만나는 곳을 합류점이라고 해요.

탐험 키워드: 카불 · 잠의 미나레트 · 하리루드강 · 잠강 · 벽돌 · 푸른 타일 · 반복 무늬 · 산골짜기 · 합류점 · 12세기 건축

엽서 장면: 잠의 미나레트와 고고 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/af/
- https://whc.unesco.org/en/list/211/

## 알바니아 · AL

수도·정부 소재지: 티라나

1. 알바니아는 유럽에 있어요. 수도는 티라나예요.

2. 부트린트에는 고대 그리스와 로마 시대의 극장과 건물 흔적이 남아 있어요. 같은 장소에서 여러 시대의 생활을 살펴볼 수 있어요.

3. 부트린트의 언덕은 호수와 비바리 물길에 둘러싸여 있어요. 유적의 모자이크는 작은 조각을 모아 만든 그림이에요.

탐험 키워드: 티라나 · 부트린트 · 부트린트호 · 비바리 물길 · 고대 극장 · 모자이크 · 고대 그리스 · 로마 시대 · 고고학 · 습지

엽서 장면: 부트린트 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/al/
- https://whc.unesco.org/en/list/570/

## 알제리 · DZ

수도·정부 소재지: 알제

1. 알제리는 아프리카에 있어요. 수도는 알제예요.

2. 수도 알제의 카스바는 지중해를 내려다보는 오래된 도시 구역이에요. 성채와 모스크, 궁전이 옛 거리의 모습을 들려줘요.

3. 카스바는 메디나라고 부르는 전통적인 도시의 한 예예요. 오래된 집과 길의 배치에서도 이웃들이 함께 살아온 역사를 읽을 수 있어요.

탐험 키워드: 알제 · 알제의 카스바 · 지중해 · 메디나 · 성채 · 모스크 · 궁전 · 옛 거리 · 해안 도시 · 공동체

엽서 장면: 알제의 카스바

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dz/
- https://whc.unesco.org/en/list/565/

## 안도라 · AD

수도·정부 소재지: 안도라라베야

1. 안도라는 유럽에 있어요. 수도는 안도라라베야예요.

2. 마드리우·페라피타·클라로 계곡은 피레네산맥에 있어요. 높은 목초지와 숲이 우거진 골짜기는 오래전 빙하가 만든 풍경을 보여줘요.

3. 계곡에는 돌길, 계단식 밭과 여름에 머물던 집들이 남아 있어요. 산에서 가축을 기르며 살아온 사람들의 지혜를 알려주는 흔적이에요.

탐험 키워드: 안도라라베야 · 마드리우 계곡 · 피레네산맥 · 목초지 · 빙하 · 돌길 · 계단식 밭 · 여름 집 · 가축 기르기 · 마드리우·페라피타·클라로 계곡

엽서 장면: 마드리우·페라피타·클라로 계곡

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ad/
- https://whc.unesco.org/en/list/1160/

## 앙골라 · AO

수도·정부 소재지: 루안다

1. 앙골라는 아프리카에 있어요. 수도는 루안다예요.

2. 음반자콩고는 옛 콩고 왕국의 수도였어요. 왕의 거처와 재판을 하던 장소가 모여, 나라를 다스리던 중심지의 모습을 보여줘요.

3. 이 도시는 높은 고원 위에 자리해요. 현지 재료로 만든 건물과 나중에 세운 돌 건물에는 여러 문화가 만난 역사가 담겨 있어요.

탐험 키워드: 루안다 · 음반자콩고 · 콩고 왕국 · 고원 · 왕의 거처 · 전통 재판소 · 돌 건물 · 현지 재료 · 문화 교류 · 고고 유적

엽서 장면: 음반자콩고

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ao/
- https://whc.unesco.org/en/list/1511/

## 앤티가 바부다 · AG

수도·정부 소재지: 세인트존스

1. 앤티가 바부다는 아메리카에 있어요. 수도는 세인트존스예요.

2. 앤티가의 잉글리시하버는 언덕이 둘러싼 좁고 깊은 만이에요. 이런 지형은 바람을 막아 배를 수리하는 항구를 만드는 데 도움이 되었어요.

3. 해군 조선소의 옛 건물에는 배와 항구의 역사가 남아 있어요. 건설에 강제로 동원된 아프리카 사람들의 노동도 함께 기억해야 해요.

탐험 키워드: 세인트존스 · 앤티가 · 바부다 · 잉글리시하버 · 앤티가 해군 조선소 · 만 · 항구 · 배 수리 · 옛 창고 · 노동의 역사

엽서 장면: 앤티가 해군 조선소

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ag/
- https://whc.unesco.org/en/list/1499/

## 아르헨티나 · AR

수도·정부 소재지: 부에노스아이레스

1. 아르헨티나의 수도는 부에노스아이레스예요. 도심의 오벨리스크는 넓은 7월 9일 대로에 서 있어요.

2. 안데스산맥이 아르헨티나 서쪽을 따라 이어지고, 아콩카과산은 아메리카에서 가장 높아요.

3. 탱고는 부에노스아이레스 주변의 리오데라플라타 지역에서 자라난 춤과 음악이에요.

탐험 키워드: 부에노스아이레스 · 오벨리스크 · 안데스산맥 · 아콩카과산 · 파타고니아 · 이구아수 폭포 · 탱고 · 마테차 · 스페인어 · 축구

엽서 장면: 부에노스아이레스 오벨리스크와 라 보카

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 아르메니아 · AM

수도·정부 소재지: 예레반

1. 아르메니아는 아시아에 있어요. 수도는 예레반예요.

2. 에치미아진의 성당과 교회에는 가운데 둥근 지붕인 돔을 둔 건축 방식이 이어져요. 건물의 모양을 비교하면 아르메니아 건축의 변화를 찾을 수 있어요.

3. 즈바르트노츠에는 옛 성당의 기둥과 터가 남아 있어요. 남은 조각을 살펴보는 고고학은 사라진 건물의 모습을 알아내는 데 도움을 줘요.

탐험 키워드: 예레반 · 에치미아진 · 즈바르트노츠 · 성당 · 돔 · 기둥 · 건물 터 · 아르메니아 건축 · 교회 · 고고학

엽서 장면: 에치미아진 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/am/
- https://whc.unesco.org/en/list/1011/

## 호주 · AU

수도·정부 소재지: 캔버라

1. 호주의 수도는 캔버라예요. 시드니 오페라하우스의 지붕은 돛이나 조개껍데기를 닮았어요.

2. 호주 북동쪽 바다에는 산호와 여러 바다 생물이 사는 거대한 산호초 지대가 있어요.

3. 호주에는 원주민과 토레스 해협 섬 주민들의 오래되고 다양한 문화가 이어져요.

탐험 키워드: 캔버라 · 시드니 · 오페라하우스 · 대보초 · 울루루 · 캥거루 · 코알라 · 바비큐 파이 · 원주민 문화 · 크리켓

엽서 장면: 시드니 오페라하우스와 하버 브리지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 오스트리아 · AT

수도·정부 소재지: 빈

1. 오스트리아는 유럽에 있어요. 수도는 빈예요.

2. 빈은 오랫동안 음악가와 연주자들이 활동한 도시예요. 음악회뿐 아니라 오래된 건물에서도 도시의 문화 역사를 만날 수 있어요.

3. 빈의 링슈트라세는 큰 건물과 공원이 이어지는 길이에요. 역사 지구에는 궁전과 정원 등 서로 다른 시대의 건축물이 함께 있어요.

탐험 키워드: 빈 · 빈 역사 지구 · 링슈트라세 · 슈테판 대성당 · 음악 · 작곡가 · 궁전 · 정원 · 바로크 건축 · 도시 공원

엽서 장면: 빈 역사 지구 — 슈테판 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/at/
- https://whc.unesco.org/en/list/1033/

## 아제르바이잔 · AZ

수도·정부 소재지: 바쿠

1. 아제르바이잔은 아시아에 있어요. 수도는 바쿠예요.

2. 바쿠의 성곽 도시에는 메이든 타워와 시르반샤 궁전이 있어요. 높은 돌탑과 궁전은 도시가 여러 시대를 거쳐 자란 흔적이에요.

3. 이체리셰헤르라고 부르는 구시가지에는 오래된 방어 성벽이 남아 있어요. 성벽은 도시를 지키고 사람들이 드나드는 길을 정하는 역할을 했어요.

탐험 키워드: 바쿠 · 바쿠 성곽 도시 · 메이든 타워 · 시르반샤 궁전 · 이체리셰헤르 · 성벽 · 돌탑 · 구시가지 · 방어 건축 · 문화의 만남

엽서 장면: 바쿠 성곽 도시 — 메이든 타워

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/az/
- https://whc.unesco.org/en/list/958/

## 바하마 · BS

수도·정부 소재지: 나소

1. 바하마는 아메리카에 있어요. 수도는 나소예요.

2. 바하마의 롱아일랜드에는 딘스 블루홀이 있어요. 바닷가의 깊은 물이 짙은 푸른색으로 보여요.

3. 딘스 블루홀 주변에는 낮은 암벽과 모래 해변이 있어요. 가까운 얕은 물은 청록색으로 보여요.

탐험 키워드: 나소 · 롱아일랜드 · 딘스 블루홀 · 석회암 해안 · 모래 해변 · 청록색 바다 · 수심 · 블루홀 · 색의 차이 · 해안 지형

엽서 장면: 롱아일랜드의 딘스 블루홀

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bahamas.com/natural-wonders/deans-blue-hole

## 바레인 · BH

수도·정부 소재지: 마나마

1. 바레인은 아시아에 있어요. 수도는 마나마예요.

2. 바레인 요새 아래에는 여러 시대 사람들이 살며 쌓인 층이 있어요. 이런 언덕 모양 유적을 텔이라고 하며, 층마다 다른 생활 흔적을 찾을 수 있어요.

3. 요새 주변은 옛 딜문 문명의 중심지이자 무역항이었어요. 집과 시장, 종교 건물의 흔적은 사람들이 물건을 교환하고 함께 살던 모습을 알려줘요.

탐험 키워드: 마나마 · 바레인 요새 · 딜문 문명 · 텔 · 유적의 층 · 무역항 · 발굴 · 옛 집터 · 시장 · 물건 교환

엽서 장면: 바레인 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bh/
- https://whc.unesco.org/en/list/1192/

## 방글라데시 · BD

수도·정부 소재지: 다카

1. 방글라데시의 수도 다카는 부리강가강 가까이에 있어요.

2. 방글라데시는 갠지스강과 브라마푸트라강 물길이 만드는 넓은 삼각주에 자리해요.

3. 순다르반스 맹그로브 숲에는 벵골호랑이를 비롯한 많은 동식물이 살아요.

탐험 키워드: 다카 · 랄바그 요새 · 부리강가강 · 순다르반스 · 벵골호랑이 · 릭샤 예술 · 벵골어 · 힐사 생선 · 잠다니 직물 · 파드마 다리

엽서 장면: 랄바그 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 바베이도스 · BB

수도·정부 소재지: 브리지타운

1. 바베이도스는 아메리카에 있어요. 수도는 브리지타운예요.

2. 브리지타운의 오래된 거리에는 17~19세기에 세운 건물들이 남아 있어요. 집과 공공건물은 대서양을 오가던 무역과 식민지 시대를 보여줘요.

3. 브리지타운의 옛 길은 바둑판처럼 반듯하기보다 굽이굽이 이어져요. 거리 모양을 살피면 도시를 세우는 방식도 서로 다르다는 걸 알 수 있어요.

탐험 키워드: 브리지타운 · 브리지타운 역사 지구 · 주둔지 유적 · 대서양 · 굽은 거리 · 도시 계획 · 공공건물 · 옛 집 · 무역 · 식민지 시대

엽서 장면: 브리지타운 역사 지구

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bb/
- https://whc.unesco.org/en/list/1376/

## 벨라루스 · BY

수도·정부 소재지: 민스크

1. 벨라루스는 유럽에 있어요. 수도는 민스크예요.

2. 미르성은 고딕·르네상스·바로크 양식이 여러 차례 더해진 성이에요. 한 건물에서도 시대마다 달라진 창과 벽의 모습을 찾아볼 수 있어요.

3. 전쟁과 훼손을 겪은 미르성은 나중에 복원되었어요. 주변 공원과 함께 보존하며 오래된 건축과 역사를 다음 세대에 전해요.

탐험 키워드: 민스크 · 미르성 · 고딕 양식 · 르네상스 · 바로크 양식 · 성탑 · 벽돌 건축 · 복원 · 공원 · 문화유산 보존

엽서 장면: 미르성

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/by/
- https://whc.unesco.org/en/list/625/

## 벨기에 · BE

수도·정부 소재지: 브뤼셀

1. 벨기에는 유럽에 있어요. 수도는 브뤼셀예요.

2. 브뤼셀의 그랑플라스는 오래된 건물들이 둘러싼 광장이에요. 공공건물과 상인들의 건물이 함께 있어 옛 도시의 생활을 보여줘요.

3. 광장 주변 건물은 주로 17세기 말의 모습을 간직하고 있어요. 지붕과 벽 장식을 비교하며 같은 광장에 모인 서로 다른 건물을 구별해 보아요.

탐험 키워드: 브뤼셀 · 그랑플라스 · 광장 · 시청 · 상인의 집 · 공공건물 · 건물 앞면 · 지붕 장식 · 17세기 · 도시 생활

엽서 장면: 브뤼셀의 그랑플라스

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/be/
- https://whc.unesco.org/en/list/857/

## 벨리즈 · BZ

수도·정부 소재지: 벨모판

1. 벨리즈는 아메리카에 있어요. 수도는 벨모판예요.

2. 벨리즈의 산호초 보호 구역에는 산호초, 모래섬과 맹그로브 숲이 이어져요. 맹그로브는 바닷가의 얕은 물가에서 자라는 나무예요.

3. 이곳은 바다거북과 매너티가 살아가는 중요한 서식지예요. 산호초와 물가의 숲을 함께 지켜야 여러 바다 생물이 살아갈 수 있어요.

탐험 키워드: 벨모판 · 벨리즈 산호초 · 산호 · 모래섬 · 맹그로브 · 석호 · 바다거북 · 매너티 · 서식지 · 바다 생태계

엽서 장면: 벨리즈 산호초 보호 구역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bz/
- https://whc.unesco.org/en/list/764/

## 베냉 · BJ

수도·정부 소재지: 포르토노보

포르토노보가 공식 수도이고, 많은 정부 기관은 코토누에 있어요.

1. 포르토노보가 공식 수도이고, 많은 정부 기관은 코토누에 있어요.

2. 아보메 왕궁은 옛 왕국의 왕들이 여러 세대에 걸쳐 만든 궁궐이에요. 각 왕의 궁전이 같은 담장 안에서 이어져 왕국의 역사를 보여줘요.

3. 아보메의 궁전은 흙을 다져 만든 벽과 현지 재료를 이용했어요. 주변에서 얻는 재료로 큰 건물을 만드는 방법도 건축의 중요한 지혜예요.

탐험 키워드: 포르토노보 · 아보메 왕궁 · 옛 왕국 · 흙벽 · 현지 재료 · 궁전 · 담장 · 건축 재료 · 왕실 역사 · 문화유산

엽서 장면: 아보메 왕궁

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bj/
- https://whc.unesco.org/en/list/323/

## 부탄 · BT

수도·정부 소재지: 팀푸

1. 부탄은 아시아에 있어요. 수도는 팀푸예요.

2. 팀푸의 타시초종은 왕추강 서쪽 강가에 자리한 건물이에요. 부탄에서는 종이라고 부르는 요새형 건물이 행정과 종교의 중심 역할을 해요.

3. 타시초종에는 하얀 벽과 장식한 나무 창이 있어요. 팀푸 체추 축제에서는 가면춤과 전통 공연으로 이야기를 전해요.

탐험 키워드: 팀푸 · 타시초종 · 왕추강 · 종 · 하얀 벽 · 나무 창 · 팀푸 체추 · 가면춤 · 요새 건축 · 팀푸의 계곡

엽서 장면: 팀푸의 계곡

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thimphu.gov.bt/tashichho-dzong/

## 볼리비아 · BO

수도·정부 소재지: 수크레

헌법상 수도는 수크레이고, 정부와 의회는 라파스에 있어요.

1. 볼리비아의 헌법상 수도는 수크레예요. 정부와 의회는 라파스에 있어서 두 도시의 역할을 나누어 알아두어요.

2. 수크레 역사 지구에는 흰 벽의 건물과 오래된 광장·교회가 남아 있어요. 이곳은 유네스코 세계유산이에요.

3. 티와나쿠 유적은 안데스 지역에서 번성했던 옛 문명의 흔적이에요. 돌로 만든 건축물과 조각을 볼 수 있어요.

탐험 키워드: 수크레 · 라파스 · 헌법상 수도 · 수크레 역사 지구 · 티와나쿠 · 안데스산맥 · 티티카카호 · 돌 건축물 · 석조 조각 · 고대 문명

엽서 장면: 포토시 광산 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bo/
- https://whc.unesco.org/en/list/566/
- https://whc.unesco.org/en/list/567/

## 보스니아 헤르체고비나 · BA

수도·정부 소재지: 사라예보

1. 보스니아 헤르체고비나는 유럽에 있어요. 수도는 사라예보예요.

2. 모스타르의 옛 다리는 네레트바강 양쪽을 이어요. 강과 깊은 골짜기를 건너는 다리는 사람과 마을을 연결하는 중요한 길이에요.

3. 이 다리는 전쟁 때 무너졌다가 여러 나라의 도움으로 다시 세워졌어요. 복원한 다리는 서로 다른 문화가 함께 살아가는 뜻도 전해요.

탐험 키워드: 사라예보 · 모스타르 · 스타리모스트 · 네레트바강 · 돌다리 · 아치 · 골짜기 · 복원 · 옛집 · 모스타르의 옛 다리 지역

엽서 장면: 모스타르의 옛 다리 지역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ba/
- https://whc.unesco.org/en/list/946/

## 보츠와나 · BW

수도·정부 소재지: 가보로네

1. 보츠와나의 수도는 가보로네예요. 바다와 직접 닿지 않는 남부 아프리카의 내륙 나라예요.

2. 오카방고 삼각주는 강물이 바다까지 가지 않고 내륙에 펼쳐지는 습지예요. 건기에도 물이 들어와 많은 동물이 모여요.

3. 초딜로 언덕에는 오래된 바위 그림이 남아 있어요. 그림과 유적은 이 지역 사람들의 오랜 역사를 보여줘요.

탐험 키워드: 가보로네 · 오카방고 삼각주 · 오카방고강 · 습지 · 내륙 삼각주 · 초딜로 · 바위 그림 · 칼라하리 · 코끼리 · 사자

엽서 장면: 오카방고 델타

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bw/
- https://whc.unesco.org/en/list/1432/
- https://whc.unesco.org/en/list/1021/

## 브라질 · BR

수도·정부 소재지: 브라질리아

1. 브라질은 남아메리카에서 가장 큰 나라이고 수도는 브라질리아예요.

2. 아마존 열대우림에는 아주 많은 식물과 동물이 살고 있어요.

3. 브라질에서는 포르투갈어를 쓰고, 리우데자네이루의 해안과 산도 유명해요.

탐험 키워드: 브라질리아 · 아마존 · 리우데자네이루 · 구세주 그리스도상 · 대서양 · 재규어 · 포르투갈어 · 삼바 · 커피 · 축구

엽서 장면: 구세주 그리스도상

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 브루나이 · BN

수도·정부 소재지: 반다르스리브가완

1. 브루나이는 아시아에 있어요. 수도는 반다르스리브가완예요.

2. 수도 근처의 캄퐁아예르는 브루나이강 위에 집을 세운 수상 마을이에요. 집들은 물속 기둥 위에 서 있고 나무 길과 다리로 연결되어 있어요.

3. 캄퐁아예르에서는 배도 중요한 이동 수단이에요. 문화관에서는 강과 함께 살아온 주민들의 생활과 마을 역사를 소개해요.

탐험 키워드: 반다르스리브가완 · 캄퐁아예르 · 브루나이강 · 수상 마을 · 기둥 위의 집 · 나무 다리 · 배 · 강변 생활 · 문화관 · 반다르스리브가완의 강변

엽서 장면: 반다르스리브가완의 강변

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bruneitourism.com/places/kampong-ayer/

## 불가리아 · BG

수도·정부 소재지: 소피아

1. 불가리아는 유럽에 있어요. 수도는 소피아예요.

2. 릴라 수도원은 10세기에 시작된 오래된 수도원이에요. 불에 크게 훼손된 뒤 19세기에 다시 지어, 옛 전통을 이어왔어요.

3. 수도원의 건물은 불가리아의 문화가 다시 활발해진 시대를 보여줘요. 오래된 장소를 고쳐 지키는 일도 역사를 전하는 방법이에요.

탐험 키워드: 소피아 · 릴라 수도원 · 성 요한 · 수도원 · 10세기 · 19세기 · 재건 · 불가리아 문화 · 종교 건축 · 문화 보존

엽서 장면: 릴라 수도원

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bg/
- https://whc.unesco.org/en/list/216/

## 부르키나파소 · BF

수도·정부 소재지: 와가두구

1. 부르키나파소는 아프리카에 있어요. 수도는 와가두구예요.

2. 티에벨레 왕실 마을에는 흙으로 만든 집과 좁은 길이 이어져요. 카세나 사람들의 집 배치에는 함께 살아가는 방식이 담겨 있어요.

3. 마을의 여성들은 집 벽에 뜻이 담긴 무늬를 그리고 그 기술을 전해요. 집을 꾸미는 일은 아름다움뿐 아니라 살아 있는 전통을 지키는 일이에요.

탐험 키워드: 와가두구 · 티에벨레 · 카세나 사람들 · 흙집 · 벽 무늬 · 전통 기술 · 골목 · 마당 · 상징 · 살아 있는 전통

엽서 장면: 티에벨레 왕실 마을

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bf/
- https://whc.unesco.org/en/list/1713/

## 부룬디 · BI

수도·정부 소재지: 기테가

1. 부룬디는 아프리카에 있어요. 수도는 기테가예요.

2. 부룬디의 왕실 북 공연은 여러 사람이 박자를 맞춰 북을 치며 춤추는 전통이에요. 노래와 시도 함께 어우러져 공동체의 이야기를 전해요.

3. 북 공연은 소리뿐 아니라 몸의 움직임도 중요한 예술이에요. 같은 박자를 함께 맞추려면 서로의 소리를 듣고 움직임을 살펴야 해요.

탐험 키워드: 기테가 · 왕실 북 · 북 연주 · 박자 · 춤 · 노래 · 시 · 공동체 · 전통 공연 · 기테가와 주변 풍경

엽서 장면: 기테가와 주변 풍경

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/decisions/9.COM/10.10

## 캄보디아 · KH

수도·정부 소재지: 프놈펜

1. 캄보디아는 아시아에 있어요. 수도는 프놈펜예요.

2. 앙코르에는 옛 크메르 제국의 여러 수도 유적이 모여 있어요. 앙코르와트와 바이욘 사원은 서로 다른 시대의 건축과 조각을 보여줘요.

3. 앙코르 유적 주변에는 숲도 함께 있어요. 옛 건물과 자연을 함께 지켜야 돌에 새긴 무늬와 유적의 주변 풍경을 오래 보존할 수 있어요.

탐험 키워드: 프놈펜 · 앙코르 · 앙코르와트 · 바이욘 · 크메르 제국 · 사원 · 돌 조각 · 옛 수도 · 숲 · 유적 보호

엽서 장면: 앙코르 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kh/
- https://whc.unesco.org/en/list/668/

## 카메룬 · CM

수도·정부 소재지: 야운데

1. 카메룬은 아프리카에 있어요. 수도는 야운데예요.

2. 자 동물 보호 구역은 자강이 거의 둘러싼 열대우림이에요. 강은 숲의 경계를 만들고 여러 생물에게 물과 생활 공간을 제공해요.

3. 자 보호 구역에는 여러 종류의 영장류와 포유류가 살아요. 생물다양성은 한곳에 서로 다른 생물들이 얼마나 풍부하게 사는지를 뜻해요.

탐험 키워드: 야운데 · 자 동물 보호 구역 · 자강 · 열대우림 · 영장류 · 포유류 · 생물다양성 · 서식지 · 강의 경계 · 자연 보호

엽서 장면: 자 동물 보호 구역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cm/
- https://whc.unesco.org/en/list/407/

## 캐나다 · CA

수도·정부 소재지: 오타와

1. 캐나다의 수도는 오타와예요. 나이아가라 폭포는 캐나다와 미국의 국경에 걸쳐 있어요.

2. 캐나다는 태평양, 대서양, 북극해와 모두 맞닿아 있어요.

3. 캐나다에는 퍼스트 네이션스, 이누이트, 메티스 공동체와 여러 문화와 언어가 있어요.

탐험 키워드: 오타와 · 나이아가라 폭포 · 단풍잎 · 로키산맥 · 북극해 · 비버 · 아이스하키 · 푸틴 감자튀김 · 프랑스어 · 이누이트

엽서 장면: 나이아가라 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 카보베르데 · CV

수도·정부 소재지: 프라이아

1. 카보베르데는 아프리카에 있어요. 수도는 프라이아예요.

2. 산티아구섬의 시다드벨랴에는 옛 거리와 교회, 왕실 요새가 남아 있어요. 지금의 수도 프라이아와는 다른 역사 도시예요.

3. 이 항구 도시는 대서양을 오가던 무역과 식민지 시대의 흔적을 간직해요. 건물뿐 아니라 그곳에서 살아온 사람들의 역사도 함께 배워요.

탐험 키워드: 프라이아 · 산티아구섬 · 시다드벨랴 · 히베이라그란드 · 대서양 · 왕실 요새 · 항구 도시 · 옛 거리 · 교회 · 식민지 시대

엽서 장면: 시다드벨랴의 옛 도시 중심지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cv/
- https://whc.unesco.org/en/list/1310/

## 중앙아프리카 공화국 · CF

수도·정부 소재지: 방기

1. 중앙아프리카 공화국은 아프리카에 있어요. 수도는 방기예요.

2. 상가강의 삼국 보호 구역은 중앙아프리카공화국·카메룬·콩고가 함께 지키는 숲이에요. 국경을 넘어 이어진 국립공원들이 동물의 생활 공간을 보호해요.

3. 숲의 빈터에는 풀이 자라고 숲코끼리와 고릴라가 살아가요. 짙은 숲과 열린 공간이 함께 있어 서로 다른 생물들이 살 수 있어요.

탐험 키워드: 방기 · 상가강 · 삼국 보호 구역 · 숲코끼리 · 서부로랜드고릴라 · 열대 숲 · 숲의 빈터 · 국립공원 · 국경 · 서식지 연결

엽서 장면: 상가강의 삼국 국립공원 지역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cf/
- https://whc.unesco.org/en/list/1380/

## 차드 · TD

수도·정부 소재지: 은자메나

1. 차드는 아프리카에 있어요. 수도는 은자메나예요.

2. 엔네디의 사암은 오랫동안 물과 바람에 깎여 절벽과 바위 아치를 만들었어요. 이렇게 바위나 흙이 깎여 나가는 일을 침식이라고 해요.

3. 엔네디의 동굴과 바위에는 옛사람들이 그리거나 새긴 그림이 남아 있어요. 마른 사하라에서도 골짜기의 물은 사람과 동물에게 소중해요.

탐험 키워드: 은자메나 · 엔네디 · 사하라 · 사암 · 바위 아치 · 침식 · 절벽 · 바위 그림 · 동굴 · 엔네디의 자연과 문화 경관

엽서 장면: 엔네디의 자연과 문화 경관

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/td/
- https://whc.unesco.org/en/list/1475/

## 칠레 · CL

수도·정부 소재지: 산티아고

1. 칠레의 수도 산티아고는 안데스산맥을 바라보는 넓은 계곡에 있어요.

2. 태평양의 라파누이섬에는 라파누이 사람들이 만든 모아이 석상이 서 있어요.

3. 칠레는 태평양 해안을 따라 남북으로 길게 이어지는 나라예요.

탐험 키워드: 산티아고 · 라파누이섬 · 모아이 · 태평양 · 안데스산맥 · 아타카마 사막 · 구리 · 엠파나다 · 스페인어 · 안데스콘도르

엽서 장면: 라파누이 모아이

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 중국 · CN

수도·정부 소재지: 베이징

1. 중국의 수도는 베이징이에요. 중국은 여러 기후와 풍경을 가진 아주 큰 나라예요.

2. 만리장성은 산등성이를 따라 길게 이어지는 오래된 성벽이에요.

3. 판다는 중국의 산 대나무 숲에 사는 동물이에요.

탐험 키워드: 베이징 · 만리장성 · 판다 · 양쯔강 · 황허 · 만두 · 북경오리 · 중국어 · 춘절 · 종이 자르기

엽서 장면: 만리장성

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 콜롬비아 · CO

수도·정부 소재지: 보고타

1. 콜롬비아의 수도 보고타는 안데스산맥의 높은 고원에 있어요.

2. 카르타헤나의 성벽으로 둘러싸인 구시가지는 카리브해 연안에 있어요.

3. 콜롬비아에서는 산에서 자라는 향기로운 커피가 많이 나요.

탐험 키워드: 보고타 · 카르타헤나 · 성벽 도시 · 카리브해 · 안데스산맥 · 커피 · 아레파 · 스페인어 · 에메랄드 · 안데스콘도르

엽서 장면: 카르타헤나 성벽 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 코모로 · KM

수도·정부 소재지: 모로니

1. 코모로는 아프리카에 있어요. 수도는 모로니예요.

2. 코모로의 역사적인 술탄 도시들은 인도양의 교역과 사람들의 이동 속에서 자랐어요. 섬의 건물과 거리에는 여러 문화가 만난 흔적이 있어요.

3. 이 도시들은 여러 섬에 흩어져 있으며 오래된 사회 관습도 이어져요. 한 나라 안에서도 섬마다 다른 마을의 역사와 생활을 만날 수 있어요.

탐험 키워드: 모로니 · 술탄 도시 · 메디나 · 인도양 · 섬마을 · 해상 교역 · 사람들의 이동 · 도시국가 · 전통 관습 · 문화 교류

엽서 장면: 코모로의 역사적인 술탄 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/km/
- https://whc.unesco.org/en/list/1768/

## 코스타리카 · CR

수도·정부 소재지: 산호세

1. 코스타리카의 수도는 산호세예요. 코스타리카는 중앙아메리카에 있으며 북아메리카에 속해요.

2. 열대 숲과 국립공원에는 나무늘보·원숭이·여러 새처럼 다양한 동물이 살아요. 자연을 지키는 보호 구역도 있어요.

3. 디키스 지역에는 옛사람들이 돌을 깎아 만든 커다란 구체가 있어요. 돌 구체가 있는 유적은 세계유산으로 보호해요.

탐험 키워드: 산호세 · 중앙아메리카 · 열대 숲 · 나무늘보 · 원숭이 · 국립공원 · 태평양 · 카리브해 · 디키스 · 돌 구체

엽서 장면: 아레날 화산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cr/
- https://www.visitcostarica.com/where-to-go/central-pacific
- https://whc.unesco.org/en/list/1453/

## 크로아티아 · HR

수도·정부 소재지: 자그레브

1. 크로아티아는 유럽에 있어요. 수도는 자그레브예요.

2. 플리트비체의 호수와 폭포는 물속의 광물이 쌓여 생긴 자연 둑으로 이어져요. 물이 땅의 모습을 바꾸는 과정은 지금도 계속돼요.

3. 호수 주변 숲에는 곰과 늑대, 여러 새가 살아요. 호수만큼 주변 숲도 지켜야 동물들의 생활 공간이 이어질 수 있어요.

탐험 키워드: 자그레브 · 플리트비체 호수 · 폭포 · 석회암 · 천연 둑 · 광물 · 곰 · 늑대 · 숲 · 두브로브니크

엽서 장면: 두브로브니크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hr/
- https://whc.unesco.org/en/list/98/

## 쿠바 · CU

수도·정부 소재지: 아바나

1. 쿠바의 수도는 아바나예요. 올드 아바나에는 오래된 광장과 요새, 여러 시대의 건물이 남아 있어요.

2. 비냘레스 계곡에는 모고테라고 부르는 둥근 석회암 봉우리들이 솟아 있어요. 산 사이에는 농촌 마을과 들판이 있어요.

3. 쿠바는 카리브해 지역의 섬나라예요. 아바나 구시가지와 비냘레스 계곡은 유네스코 세계유산이에요.

탐험 키워드: 아바나 · 올드 아바나 · 비냘레스 계곡 · 모고테 · 석회암 · 카리브해 · 섬나라 · 요새 · 광장 · 스페인어

엽서 장면: 아바나 구시가지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cu/
- https://whc.unesco.org/en/list/204/
- https://whc.unesco.org/en/list/840/

## 키프로스 · CY

수도·정부 소재지: 니코시아

1. 키프로스는 유럽에 있어요. 수도는 니코시아예요.

2. 키로키티아는 아주 오래전 사람들이 살던 신석기시대 마을 유적이에요. 집터와 발굴품을 통해 글로 기록하기 전의 생활을 배울 수 있어요.

3. 유적은 모두 파헤치는 대신 일부를 남겨 미래의 연구도 준비해요. 땅속의 작은 물건 하나도 옛 생활을 알려주는 중요한 단서예요.

탐험 키워드: 니코시아 · 키로키티아 · 신석기시대 · 집터 · 발굴품 · 선사시대 · 고고학 · 마을 · 지중해 · 파포스 모자이크

엽서 장면: 파포스 모자이크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cy/
- https://whc.unesco.org/en/list/848/

## 체코 · CZ

수도·정부 소재지: 프라하

1. 체코의 수도는 프라하예요. 블타바강이 도시를 지나고, 강 양쪽에 오래된 건물이 자리해요.

2. 카를교는 블타바강을 건너는 오래된 돌다리예요. 다리에서 프라하성과 도시의 탑들을 바라볼 수 있어요.

3. 프라하 역사 지구에는 고딕·르네상스·바로크 시대의 건물이 함께 남아 있어요. 이곳은 유네스코 세계유산이에요.

탐험 키워드: 프라하 · 카를교 · 블타바강 · 프라하성 · 성 비투스 대성당 · 구시가지 · 고딕 건축 · 르네상스 · 바로크 · 체코어

엽서 장면: 프라하 카를교

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cz/
- https://whc.unesco.org/en/list/616/
- https://prague.eu/en/objevujte/charles-bridge-karluv-most/

## 덴마크 · DK

수도·정부 소재지: 코펜하겐

1. 덴마크의 수도는 코펜하겐이에요. 뉘하운 항구에는 여러 색의 집들과 배가 나란히 있어요.

2. 안데르센은 덴마크의 동화 작가예요. 코펜하겐의 인어공주 동상은 그의 동화에서 영감을 받았어요.

3. 코펜하겐에서는 자전거로 학교나 일터에 가는 사람들이 많아요. 도시에는 자전거를 위한 길이 잘 이어져 있어요.

탐험 키워드: 코펜하겐 · 뉘하운 · 인어공주 동상 · 안데르센 · 동화 · 자전거 · 항구 · 운하 · 배 · 덴마크어

엽서 장면: 코펜하겐 뉘하운

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dk/
- https://www.visitdenmark.com/denmark/plan-your-trip/nyhavn-harbour-gdk426287
- https://www.visitdenmark.com/denmark/plan-your-trip/the-little-mermaid-gdk586951
- https://www.visitcopenhagen.com/

## 지부티 · DJ

수도·정부 소재지: 지부티

1. 지부티는 아프리카에 있어요. 수도는 지부티예요.

2. 아살 호수는 바다 수면보다 낮은 땅에 자리해요. 바닷가의 높이를 기준으로 땅이 위에 있는지 아래에 있는지 비교할 수 있어요.

3. 지부티에는 노래와 시, 춤으로 이야기를 전하는 전통이 있어요. 여러 공동체의 오랜 생활 방식이 서로 만나 다양한 문화를 이루어요.

탐험 키워드: 지부티 · 아살 호수 · 해수면 · 낮은 땅 · 호수 · 노래 · 시 · 춤 · 유목 전통 · 문화의 만남

엽서 장면: 아살 호수

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guide.visitdjibouti.dj/

## 도미니카 연방 · DM

수도·정부 소재지: 로조

1. 도미니카 연방은 아메리카에 있어요. 수도는 로조예요.

2. 모른트루아피통 국립공원에는 열대 숲과 화산 지형이 함께 있어요. 가파른 골짜기와 호수는 화산섬의 다양한 풍경을 보여줘요.

3. 공원의 보일링 호수와 온천은 땅속 열이 물에 영향을 주는 곳이에요. 도미니카 연방은 이름이 비슷한 도미니카공화국과 다른 나라예요.

탐험 키워드: 로조 · 모른트루아피통 · 보일링 호수 · 화산 · 온천 · 땅속 열 · 열대 숲 · 골짜기 · 화산섬 · 담수호

엽서 장면: 보일링 호수

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dm/
- https://whc.unesco.org/en/list/814/

## 도미니카 공화국 · DO

수도·정부 소재지: 산토도밍고

1. 도미니카공화국의 수도는 산토도밍고예요. 오사마강 하구에 오래된 도시 중심지가 자리해요.

2. 도미니카공화국은 카리브해의 이스파니올라섬을 아이티와 나누고 있어요. 도미니카 연방과는 다른 나라예요.

3. 메렝게는 도미니카공화국의 음악과 춤이에요. 축제와 모임에서 함께 즐기며 전통을 이어가요.

탐험 키워드: 산토도밍고 · 산토도밍고 역사 지구 · 이스파니올라섬 · 오사마강 · 카리브해 · 메렝게 · 춤 · 축제 · 아이티 · 스페인어

엽서 장면: 산토도밍고 식민 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/do/
- https://whc.unesco.org/en/list/526/
- https://ich.unesco.org/en/RL/music-and-dance-of-the-merengue-in-the-dominican-republic-01162

## 콩고 민주 공화국 · CD

수도·정부 소재지: 킨샤사

1. 콩고 민주 공화국은 아프리카에 있어요. 수도는 킨샤사예요.

2. 비룽가 국립공원에는 화산 주변 초원과 습지, 높은 산의 눈밭이 있어요. 높이와 지형이 달라지면 동물의 생활 공간도 달라져요.

3. 비룽가는 마운틴고릴라가 살아가는 곳이에요. 먼 곳에서 겨울을 보내러 오는 새도 있어, 동물을 지키는 일은 여러 지역을 연결해요.

탐험 키워드: 킨샤사 · 비룽가 · 마운틴고릴라 · 화산 · 습지 · 르웬조리산맥 · 초원 · 하마 · 철새 · 서식지

엽서 장면: 비룽가의 화산과 마운틴고릴라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cd/
- https://whc.unesco.org/en/list/63/

## 에콰도르 · EC

수도·정부 소재지: 키토

1. 에콰도르는 아메리카에 있어요. 수도는 키토예요.

2. 갈라파고스제도에는 큰 육지거북과 여러 종류의 핀치가 살아요. 오래 떨어져 있던 섬에서는 다른 곳과 구별되는 생물이 나타날 수 있어요.

3. 여러 해류가 갈라파고스 주변에서 만나고 화산 활동은 섬의 지형을 만들었어요. 이곳의 동물 관찰은 다윈이 진화를 연구하는 데 도움을 주었어요.

탐험 키워드: 키토 · 갈라파고스제도 · 육지거북 · 핀치 · 이구아나 · 해류 · 화산 · 다윈 · 진화 · 키토 국립 서원 대성당

엽서 장면: 키토 국립 서원 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ec/
- https://whc.unesco.org/en/list/1/

## 이집트 · EG

수도·정부 소재지: 카이로

1. 이집트의 수도는 카이로예요. 나일강은 사막을 지나 지중해로 흘러가요.

2. 기자의 피라미드는 고대 이집트 사람들이 돌을 쌓아 만든 거대한 무덤이에요.

3. 오늘날에도 많은 사람들이 나일강 주변의 도시와 농장에서 생활해요.

탐험 키워드: 카이로 · 기자의 피라미드 · 나일강 · 사하라 사막 · 스핑크스 · 상형문자 · 아랍어 · 대추야자 · 홍해 · 파라오

엽서 장면: 기자의 피라미드

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 엘살바도르 · SV

수도·정부 소재지: 산살바도르

1. 엘살바도르는 아메리카에 있어요. 수도는 산살바도르예요.

2. 호야 데 세렌은 화산 분출로 묻힌 옛 농촌 마을이에요. 재 아래 보존된 흔적은 그때 사람들이 어떻게 살았는지 알려줘요.

3. 왕궁이나 큰 사원과 달리, 이 유적은 평범한 농부들의 생활을 보여줘요. 옛 집과 농사 흔적도 역사에서 중요한 자료가 될 수 있어요.

탐험 키워드: 산살바도르 · 호야 데 세렌 · 화산재 · 라구나칼데라 화산 · 농촌 마을 · 옛 집 · 농사 · 발굴 · 일상생활 · 고고학

엽서 장면: 호야 데 세렌

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sv/
- https://whc.unesco.org/en/list/675/

## 적도 기니 · GQ

수도·정부 소재지: 시우다드데라파스

2026년 1월에 수도가 말라보에서 시우다드데라파스로 바뀌었어요.

1. 2026년 1월에 수도가 말라보에서 시우다드데라파스로 바뀌었어요.

2. 적도기니의 비오코섬에는 높은 피코바실레 산이 있어요. 그림 속 산은 본토에 있는 수도와 다른 곳이에요.

3. 비오코섬의 숲은 높이에 따라 모습이 달라져요. 열대 숲과 산지의 자연을 함께 만날 수 있어요.

탐험 키워드: 시우다드데라파스 · 아프리카 · 프랑스어 · 포르투갈어 · 비오코섬 · 피코바실레 · 산지 숲 · 스페인어 · 해발 고도 · 서식 환경

엽서 장면: 비오코섬의 피코바실레산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.guineaecuatorialpress.com/noticias/decreto_ley_por_el_que_se_declara_la_ciudad_de_la_paz_djibloho_capital_de_la_republica_de_guinea_ecuatorial
- https://minturismo.gob.gq/lugares-turisticos/
- https://www.unesco.org/en/mab/isla-de-bioko

## 에리트레아 · ER

수도·정부 소재지: 아스마라

1. 에리트레아는 아프리카에 있어요. 수도는 아스마라예요.

2. 아스마라는 해발 2,000m가 넘는 높은 곳에 자리한 도시예요. 바다 가까운 낮은 땅과 높은 도시의 위치를 지도에서 비교해 보아요.

3. 아스마라에는 20세기 초의 근대 건축물이 모여 있어요. 영화관과 상점, 종교 건물의 다양한 모양은 도시를 새롭게 설계하던 시대를 보여줘요.

탐험 키워드: 아스마라 · 아스마라 근대 건축 · 피아트 탈리에로 · 해발 높이 · 고원 도시 · 도시 계획 · 영화관 · 상점 · 근대 건축 · 20세기

엽서 장면: 아스마라의 근대 건축과 피아트 탈리에로

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/er/
- https://whc.unesco.org/en/list/1550/

## 에스토니아 · EE

수도·정부 소재지: 탈린

1. 에스토니아는 유럽에 있어요. 수도는 탈린예요.

2. 탈린은 옛 한자 동맹의 중요한 무역 도시였어요. 물건을 사고팔던 상인들의 집과 큰 공공건물에 그 역사가 남아 있어요.

3. 탈린 구시가지에는 중세 시대의 거리와 건물이 남아 있어요. 오랜 건물을 보존하면 사람들은 도시가 자라온 모습을 함께 배울 수 있어요.

탐험 키워드: 탈린 · 탈린 구시가지 · 한자 동맹 · 무역 · 상인의 집 · 중세 거리 · 교회 · 성 · 공공건물 · 도시 보존

엽서 장면: 탈린 구시가지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ee/
- https://whc.unesco.org/en/list/822/

## 에스와티니 · SZ

수도·정부 소재지: 음바바네

음바바네는 행정 수도이고, 로밤바에는 왕실과 의회가 있어요.

1. 음바바네는 행정 수도이고, 로밤바에는 왕실과 의회가 있어요.

2. 음바바네 북쪽의 시베베는 커다란 둥근 바위산이에요. 바위의 모양과 주위 골짜기를 살펴보면 산의 모습도 서로 다르다는 걸 알 수 있어요.

3. 에스와티니의 움흘랑가 갈대춤은 여러 사람이 함께 참여하는 전통 행사예요. 노래와 춤, 갈대를 모으는 활동으로 공동체의 문화를 이어가요.

탐험 키워드: 음바바네 · 시베베 바위 · 만텡가 폭포 · 로밤바 · 움흘랑가 · 갈대 · 갈대춤 · 바위산 · 골짜기 · 공동체 행사

엽서 장면: 만텡가 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.thekingdomofeswatini.com/central-eswatini/sibebe-rock/
- https://www.thekingdomofeswatini.com/news-blogs/backpacker-tours-visitor-guide-to-the-2026-umhlanga-reed-dance/

## 에티오피아 · ET

수도·정부 소재지: 아디스아바바

1. 에티오피아의 수도는 아디스아바바예요. 에티오피아에는 높은 고원과 오래된 문화 유적이 있어요.

2. 랄리벨라의 교회들은 큰 바위를 깎아 만들었어요. 건물과 통로를 바위 속에서 파낸 독특한 유적이에요.

3. 야유 생물권보전지역에는 야생 아라비카 커피가 자라는 산지 숲이 있어요. 커피와 여러 생물의 터전을 함께 지켜요.

탐험 키워드: 아디스아바바 · 랄리벨라 · 암굴 교회 · 바위 조각 · 야유 · 커피 숲 · 아라비카 커피 · 에티오피아 고원 · 생물 다양성 · 암하라어

엽서 장면: 랄리벨라 암굴 교회

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/et/
- https://whc.unesco.org/en/list/18/
- https://www.unesco.org/en/mab/yayu?hub=66369

## 피지 · FJ

수도·정부 소재지: 수바

1. 피지는 오세아니아에 있어요. 수도는 수바예요.

2. 레부카는 피지의 옛 항구 도시예요. 해변을 따라 낮은 건물과 코코넛·망고나무가 이어져 바다와 함께 자란 도시의 모습을 보여줘요.

3. 레부카에는 현지 주민과 바다를 건너온 사람들의 생활 흔적이 함께 남아 있어요. 창고와 학교, 상점은 항구가 물건뿐 아니라 지식도 잇는 곳임을 알려줘요.

탐험 키워드: 수바 · 레부카 · 부마 폭포 · 항구 도시 · 코코넛나무 · 망고나무 · 해변 · 창고 · 상점 · 문화 교류

엽서 장면: 부마 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fj/
- https://whc.unesco.org/en/list/1399/

## 핀란드 · FI

수도·정부 소재지: 헬싱키

1. 핀란드의 수도 헬싱키에는 하얀 돔의 헬싱키 대성당이 있어요.

2. 핀란드에는 숲과 호수가 많아 사람들이 자연에서 시간을 보내곤 해요.

3. 핀란드어와 스웨덴어는 핀란드의 공용어예요.

탐험 키워드: 헬싱키 · 헬싱키 대성당 · 원로원 광장 · 발트해 · 핀란드어 · 사우나 · 순록 · 블루베리 · 호밀빵 · 북극광

엽서 장면: 헬싱키 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 프랑스 · FR

수도·정부 소재지: 파리

1. 프랑스의 수도는 파리이고, 에펠탑은 1889년 파리 만국박람회를 위해 세워졌어요.

2. 프랑스에는 높은 알프스산맥과 대서양, 지중해 해안이 있어요.

3. 루브르 박물관에는 세계적으로 유명한 예술 작품들이 전시되어 있어요.

탐험 키워드: 파리 · 에펠탑 · 루브르 · 센강 · 알프스 · 바게트 · 크루아상 · 프랑스어 · 라벤더 · 치즈

엽서 장면: 에펠탑

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 가봉 · GA

수도·정부 소재지: 리브르빌

1. 가봉은 아프리카에 있어요. 수도는 리브르빌예요.

2. 로페·오칸다에는 빽빽한 열대우림과 탁 트인 사바나가 함께 있어요. 숲과 초원이 만나는 곳에서는 서로 다른 생활 공간을 가진 생물이 살아가요.

3. 이곳에는 옛 집터와 철을 다루던 흔적, 바위에 새긴 그림도 남아 있어요. 자연 보호 구역에서도 사람들의 오랜 역사를 함께 배울 수 있어요.

탐험 키워드: 리브르빌 · 로페·오칸다 · 열대우림 · 사바나 · 맨드릴 · 생태계 · 바위 그림 · 철 다루기 · 집터 · 서식지

엽서 장면: 로페·오칸다 풍경과 맨드릴

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ga/
- https://whc.unesco.org/en/list/1147/

## 감비아 · GM

수도·정부 소재지: 반줄

1. 감비아는 아프리카에 있어요. 수도는 반줄예요.

2. 감비아강의 쿤타킨테 섬 유적에는 아프리카와 유럽이 만난 역사가 담겨 있어요. 이곳에서는 사람을 강제로 사고팔던 노예무역과 그 폐지의 역사를 배워요.

3. 유적을 지키는 일은 건물을 남기는 것만이 아니에요. 자유를 빼앗겼던 사람들의 이야기를 기억하고 모든 사람의 존엄을 생각하는 일이기도 해요.

탐험 키워드: 반줄 · 감비아강 · 쿤타킨테 섬 · 세네감비아 환상 열석 · 역사 유적 · 노예무역 · 폐지 · 자유 · 존엄 · 역사 기억

엽서 장면: 세네감비아 환상 열석

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gm/
- https://whc.unesco.org/en/list/761/

## 조지아 · GE

수도·정부 소재지: 트빌리시

1. 조지아는 아시아에 있어요. 수도는 트빌리시예요.

2. 겔라티 수도원은 중세 조지아의 건축과 예술을 보여주는 곳이에요. 매끈하게 다듬은 큰 돌과 아치 장식에는 옛 장인의 기술이 담겨 있어요.

3. 겔라티에는 과학과 교육을 연구하던 아카데미도 있었어요. 오래된 종교 건물이 배움과 문화의 중심지가 되기도 했다는 것을 알려줘요.

탐험 키워드: 트빌리시 · 겔라티 수도원 · 나리칼라 요새 · 아카데미 · 돌 건축 · 아치 · 중세 조지아 · 과학 · 교육 · 장인의 기술

엽서 장면: 트빌리시와 나리칼라 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ge/
- https://whc.unesco.org/en/list/710/

## 독일 · DE

수도·정부 소재지: 베를린

1. 독일의 수도는 베를린이고, 브란덴부르크문은 베를린의 대표적인 옛 문이에요.

2. 독일은 북쪽의 북해와 발트해부터 남쪽의 알프스산맥까지 풍경이 달라져요.

3. 베를린 장벽은 도시를 나누었지만 1989년에 문이 열리며 많은 사람이 다시 오갈 수 있었어요.

탐험 키워드: 베를린 · 브란덴부르크문 · 베를린 장벽 · 라인강 · 검은숲 · 알프스 · 프레첼 · 빵 · 독일어 · 축구

엽서 장면: 브란덴부르크 문

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 가나 · GH

수도·정부 소재지: 아크라

1. 가나의 수도는 아크라예요. 아크라는 대서양과 만나는 해안에 있는 도시예요.

2. 켄테는 좁고 긴 천 조각을 짜서 이어 만드는 직물이에요. 색과 무늬에는 공동체의 이야기와 뜻이 담겨 있어요.

3. 해안의 성과 요새에는 무역과 노예무역의 아픈 역사가 남아 있어요. 그 역사를 기억하며 사람의 권리도 배워요.

탐험 키워드: 아크라 · 켄테 · 직조 · 천 조각 · 베틀 · 면 · 대서양 · 엘미나성 · 케이프코스트성 · 제임스타운

엽서 장면: 아크라 블랙 스타 광장

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gh/
- https://ich.unesco.org/en/RL/craftsmanship-of-traditional-woven-textile-kente-02130
- https://whc.unesco.org/en/list/34/

## 그리스 · GR

수도·정부 소재지: 아테네

1. 그리스의 수도 아테네에는 언덕 위에 파르테논 신전이 있는 아크로폴리스가 있어요.

2. 그리스에는 산과 바다, 크고 작은 섬들이 있어요.

3. 고대 올림픽 경기는 그리스의 올림피아에서 열렸어요.

탐험 키워드: 아테네 · 파르테논 · 아크로폴리스 · 올림피아 · 에게해 · 올림포스산 · 올리브 · 페타 치즈 · 그리스어 · 그리스 섬

엽서 장면: 아크로폴리스와 파르테논

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 그레나다 · GD

수도·정부 소재지: 세인트조지스

1. 그레나다는 아메리카에 있어요. 수도는 세인트조지스예요.

2. 그레나다의 향신료 정원에서는 육두구와 여러 향기로운 식물을 키워요. 향신료는 음식에 냄새와 맛을 더하는 식물 재료예요.

3. 육두구 같은 향신료는 시럽과 잼, 소스에도 쓰여요. 같은 식물 재료가 여러 음식으로 바뀌는 과정을 살펴볼 수 있어요.

탐험 키워드: 세인트조지스 · 육두구 · 향신료 · 허브 · 향신료 정원 · 시럽 · 잼 · 소스 · 식물의 향 · 카리나주 항구

엽서 장면: 세인트조지스 카리나주 항구

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.puregrenada.com/de-la-grenade-nutmeg-garden/

## 과테말라 · GT

수도·정부 소재지: 과테말라시티

1. 과테말라는 아메리카에 있어요. 수도는 과테말라시티예요.

2. 티칼은 열대 숲 속에 자리한 옛 마야 도시예요. 높은 사원과 궁전, 넓은 광장은 마야 사람들의 건축 솜씨를 보여줘요.

3. 큰 건물 주변에는 평범한 사람들이 살던 집터도 흩어져 있어요. 도시를 이해하려면 특별한 건물과 일상의 생활 공간을 함께 살펴야 해요.

탐험 키워드: 과테말라시티 · 티칼 · 마야 문명 · 열대 숲 · 사원 · 궁전 · 광장 · 집터 · 도시 유적 · 발굴

엽서 장면: 티칼 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gt/
- https://whc.unesco.org/en/list/64/

## 기니 · GN

수도·정부 소재지: 코나크리

1. 기니는 아프리카에 있어요. 수도는 코나크리예요.

2. 님바산에는 숲이 우거진 비탈과 풀로 덮인 높은 땅이 함께 있어요. 산 아래와 위에서 서로 다른 식물과 동물의 생활 공간을 만날 수 있어요.

3. 님바산의 침팬지 중에는 돌을 도구로 쓰는 무리가 있어요. 동물의 행동을 관찰하면 같은 종도 여러 방식으로 살아간다는 걸 배울 수 있어요.

탐험 키워드: 코나크리 · 님바산 · 침팬지 · 돌 도구 · 산지 숲 · 초지 · 비탈 · 고유종 · 동물 행동 · 자연 보호 구역

엽서 장면: 님바산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gn/
- https://whc.unesco.org/en/list/155/

## 기니비사우 · GW

수도·정부 소재지: 비사우

1. 기니비사우는 아프리카에 있어요. 수도는 비사우예요.

2. 비자고스제도에는 맹그로브 숲과 갯벌, 얕은 바다가 이어져요. 밀물과 썰물에 따라 물이 덮는 곳이 달라져 여러 생물의 생활 공간이 생겨요.

3. 바다거북과 매너티, 멀리 이동하는 물새들이 이곳을 이용해요. 바다와 섬의 해안을 함께 보호하면 여러 동물이 머물 곳을 지킬 수 있어요.

탐험 키워드: 비사우 · 비자고스제도 · 맹그로브 · 갯벌 · 밀물 · 썰물 · 바다거북 · 매너티 · 물새 · 해안 생태계

엽서 장면: 비자고스 제도의 해안과 바다 생태계

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gw/
- https://whc.unesco.org/en/list/1431/

## 가이아나 · GY

수도·정부 소재지: 조지타운

1. 가이아나는 아메리카에 있어요. 수도는 조지타운예요.

2. 카이에투르 폭포에서는 포타로강이 열대우림을 지나 높은 바위 아래로 떨어져요. 큰 폭포의 물보라는 물이 작은 방울로 흩어지며 생겨요.

3. 폭포 주변 숲에는 다양한 새와 식물이 살아가요. 폭포만 따로 보기보다 강과 숲이 이어진 전체 자연을 함께 살펴보아요.

탐험 키워드: 조지타운 · 카이에투르 폭포 · 포타로강 · 열대우림 · 물보라 · 절벽 · 국립공원 · 숲의 새 · 강물 · 자연의 연결

엽서 장면: 카이에투르 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guyanatourism.com/kaieteur-falls/

## 아이티 · HT

수도·정부 소재지: 포르토프랭스

1. 아이티는 아메리카에 있어요. 수도는 포르토프랭스예요.

2. 라페리에르 요새와 상수시 궁전은 아이티가 독립한 뒤 세운 역사 유적이에요. 자유를 얻은 사람들이 새로운 나라를 만들던 시대를 보여줘요.

3. 아이티의 역사 공원은 건물과 함께 자유의 의미를 전해요. 유적을 보며 사람들에게 독립과 존엄이 왜 중요한지 생각해 볼 수 있어요.

탐험 키워드: 포르토프랭스 · 라페리에르 요새 · 상수시 궁전 · 라미에 · 독립 · 자유 · 존엄 · 역사 공원 · 요새 · 19세기

엽서 장면: 라페리에르 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ht/
- https://whc.unesco.org/en/list/180/

## 온두라스 · HN

수도·정부 소재지: 테구시갈파

1. 온두라스는 아메리카에 있어요. 수도는 테구시갈파예요.

2. 코판은 옛 마야 문명의 도시 유적이에요. 큰 광장과 건물 터는 도시가 여러 시기에 걸쳐 달라진 모습을 보여줘요.

3. 고고학자들은 오래된 유적을 발굴하고 남은 흔적을 비교해요. 코판처럼 사람이 떠난 도시에서도 당시의 생활과 건축을 배울 수 있어요.

탐험 키워드: 테구시갈파 · 코판 · 마야 문명 · 광장 · 도시 유적 · 건물 터 · 발굴 · 고고학자 · 옛 도시 · 도시의 변화

엽서 장면: 코판 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hn/
- https://whc.unesco.org/en/list/129/

## 헝가리 · HU

수도·정부 소재지: 부다페스트

1. 헝가리는 유럽에 있어요. 수도는 부다페스트예요.

2. 다뉴브강 양쪽으로 펼쳐진 부다페스트에는 부다성 지구와 오래된 건물들이 있어요. 강은 도시의 풍경과 사람들의 이동에 큰 영향을 주어요.

3. 부다페스트의 로마 유적과 여러 시대 건축을 비교해 보아요. 오래된 건물이 함께 남아 있으면 한 도시에서 긴 역사의 변화를 볼 수 있어요.

탐험 키워드: 부다페스트 · 다뉴브강 · 부다성 · 안드라시 거리 · 아퀸쿰 · 로마 유적 · 강변 · 고딕 건축 · 도시 풍경 · 헝가리 국회의사당

엽서 장면: 부다페스트 국회의사당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hu/
- https://whc.unesco.org/en/list/400/

## 아이슬란드 · IS

수도·정부 소재지: 레이캬비크

1. 아이슬란드는 유럽에 있어요. 수도는 레이캬비크예요.

2. 싱벨리르에서는 930년에 야외 의회인 알팅이 시작되었어요. 사람들이 모여 법을 정하고 다툼을 풀던 장소가 역사 유적으로 남아 있어요.

3. 싱벨리르에는 흙과 돌로 만든 옛 임시 거처의 흔적도 있어요. 큰 궁전 없이도 사람들이 만나는 장소가 중요한 문화유산이 될 수 있어요.

탐험 키워드: 레이캬비크 · 싱벨리르 · 알팅 · 야외 의회 · 법 · 모임 · 흙과 돌 · 옛 거처 · 농경 흔적 · 레이캬비크와 오로라

엽서 장면: 레이캬비크와 오로라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/is/
- https://whc.unesco.org/en/list/1152/

## 인도 · IN

수도·정부 소재지: 뉴델리

1. 인도는 남아시아에 있고 수도는 뉴델리예요.

2. 북쪽에는 히말라야산맥이 있고, 남쪽으로 가면 인도양과 만나요.

3. 타지마할은 아그라에 있는 대리석 기념 건축물이에요.

탐험 키워드: 뉴델리 · 타지마할 · 히말라야 · 갠지스강 · 벵골호랑이 · 망고 · 사모사 · 힌디어 · 디왈리 · 요가

엽서 장면: 타지마할

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 인도네시아 · ID

수도·정부 소재지: 자카르타

1. 자카르타는 인도네시아의 수도예요. 보르네오섬에는 미래 수도로 계획된 누산타라가 건설되고 있어요.

2. 인도네시아는 인도양과 태평양 사이의 아주 많은 섬들에 걸쳐 있어요.

3. 자바섬의 보로부두르에는 돌로 만든 탑과 이야기 조각이 많은 오래된 불교 사원이 있어요.

탐험 키워드: 자카르타 · 누산타라 · 자바섬 · 보로부두르 · 코모도왕도마뱀 · 화산 · 나시고렝 · 사테 · 인도네시아어 · 바틱

엽서 장면: 보로부두르

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 이란 · IR

수도·정부 소재지: 테헤란

1. 이란은 아시아에 있어요. 수도는 테헤란예요.

2. 페르세폴리스는 옛 아케메네스 왕조의 수도였어요. 높은 단 위에 큰 궁전들을 세워 당시 건축가들의 솜씨를 보여주었어요.

3. 궁전 터를 받치는 단에는 자연 지형과 사람이 만든 부분이 함께 있어요. 옛 건축가들은 땅의 모습을 이용하면서 건물을 세웠어요.

탐험 키워드: 테헤란 · 페르세폴리스 · 아케메네스 왕조 · 다리우스 1세 · 궁전 · 높은 단 · 고대 건축 · 유적 · 지형 · 건축가

엽서 장면: 페르세폴리스

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ir/
- https://whc.unesco.org/en/list/114/

## 이라크 · IQ

수도·정부 소재지: 바그다드

1. 이라크는 아시아에 있어요. 수도는 바그다드예요.

2. 바빌론은 옛 메소포타미아의 중요한 도시였어요. 성벽과 문, 궁전과 사원 흔적은 당시 큰 도시의 구조를 알려줘요.

3. 바빌론 주변에는 농촌과 농사짓던 땅의 흔적도 있어요. 옛 도시가 살아가려면 도시 안의 건물뿐 아니라 주변 농경지도 필요했어요.

탐험 키워드: 바그다드 · 바빌론 · 메소포타미아 · 성벽 · 성문 · 궁전 · 사원 · 농경지 · 고대 도시 · 우르의 지구라트

엽서 장면: 우르의 지구라트

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/iq/
- https://whc.unesco.org/en/list/278/

## 아일랜드 · IE

수도·정부 소재지: 더블린

1. 아일랜드는 유럽에 있어요. 수도는 더블린예요.

2. 보인강 주변의 브루나보너에는 뉴그레인지와 노스, 다우스 같은 선사시대 유적이 있어요. 큰 돌을 이용한 건축과 미술을 보여주는 곳이에요.

3. 이 유적들은 장례와 종교뿐 아니라 당시 사회의 생활도 알려줘요. 글로 된 기록이 없어도 건축과 물건을 통해 사람들의 이야기를 찾을 수 있어요.

탐험 키워드: 더블린 · 브루나보너 · 보인강 · 뉴그레인지 · 노스 · 다우스 · 선사시대 · 큰 돌 건축 · 고고학 · 모허 절벽

엽서 장면: 모허 절벽

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ie/
- https://whc.unesco.org/en/list/659/

## 이스라엘 · IL

수도·정부 소재지: 예루살렘

이스라엘 정부는 예루살렘을 수도로 두고 있어요. 도시의 국제적 지위는 분쟁 중이에요.

1. 이스라엘 정부는 예루살렘을 수도로 두고 있어요. 도시의 국제적 지위는 분쟁 중이에요.

2. 하이파의 바하이 성지에는 성소와 그 주변 정원이 있어요. 종교 건축과 정원을 함께 가꾸며 소중한 장소를 지켜왔어요.

3. 바하이 성지들은 하이파와 갈릴리 서부 여러 곳에 나뉘어 있어요. 순례는 사람들이 자신에게 뜻깊은 장소를 찾아가는 문화예요.

탐험 키워드: 예루살렘 · 하이파 · 바하이 정원 · 바브 성소 · 아크레 · 갈릴리 서부 · 정원 · 성소 · 순례 · 종교 건축

엽서 장면: 하이파의 바하이 정원과 성지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/il/
- https://whc.unesco.org/en/list/1220/

## 이탈리아 · IT

수도·정부 소재지: 로마

1. 이탈리아의 수도는 로마예요. 로마에는 아주 오래된 건축물이 많이 남아 있어요.

2. 콜로세움은 고대 로마 시대에 사람들이 모여 행사를 보던 큰 경기장이에요.

3. 이탈리아는 지중해로 뻗은 장화 모양의 반도와 여러 섬으로 이루어져 있어요.

탐험 키워드: 로마 · 콜로세움 · 피사의 사탑 · 베네치아 · 지중해 · 피자 · 파스타 · 젤라토 · 이탈리아어 · 알프스

엽서 장면: 콜로세움

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 코트디부아르 · CI

수도·정부 소재지: 야무수크로

1. 코트디부아르는 아프리카에 있어요. 수도는 야무수크로예요.

2. 타이 국립공원은 서아프리카의 오래된 열대 숲을 지키는 곳이에요. 빽빽한 숲에는 여러 식물과 동물이 서로 연결되어 살아가요.

3. 타이 숲에는 피그미하마와 여러 종류의 원숭이가 살아요. 작은 서식지가 사라져도 그곳을 의지하던 동물에게는 큰 변화가 될 수 있어요.

탐험 키워드: 야무수크로 · 타이 국립공원 · 피그미하마 · 원숭이 · 열대 숲 · 서아프리카 · 식물 · 생물다양성 · 서식지 보호 · 평화의 성모 대성당

엽서 장면: 야무수크로 평화의 성모 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ci/
- https://whc.unesco.org/en/list/195/

## 자메이카 · JM

수도·정부 소재지: 킹스턴

1. 자메이카는 아메리카에 있어요. 수도는 킹스턴예요.

2. 블루 마운틴과 존크로산맥에는 숲으로 덮인 가파른 산지가 있어요. 산속의 길과 마을에는 마룬 공동체의 생활 흔적이 남아 있어요.

3. 마룬 사람들은 노예 상태에서 벗어나 산속에 공동체를 만들었어요. 숲은 생활 재료를 제공했고 노래와 춤 같은 문화도 이어졌어요.

탐험 키워드: 킹스턴 · 블루 마운틴 · 존크로산맥 · 마룬 공동체 · 산지 숲 · 나니타운 유산길 · 산길 · 자유 · 전통춤 · 숲의 자원

엽서 장면: 블루 마운틴과 킹스턴 해안

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jm/
- https://whc.unesco.org/en/list/1356/

## 일본 · JP

수도·정부 소재지: 도쿄

1. 일본은 동아시아의 섬나라이고 수도는 도쿄예요.

2. 후지산은 일본에서 가장 높은 산이에요.

3. 일본에는 빠른 신칸센 열차와 여러 섬이 있어요.

탐험 키워드: 도쿄 · 후지산 · 오중탑 · 벚꽃 · 홋카이도 · 초밥 · 라멘 · 일본어 · 신칸센 · 종이접기

엽서 장면: 후지산과 오중탑

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 요르단 · JO

수도·정부 소재지: 암만

1. 요르단은 아시아에 있어요. 수도는 암만예요.

2. 페트라는 바위를 깎아 건물을 만든 옛 도시예요. 산과 좁은 골짜기 사이에서 돌로 쌓은 부분과 바위에 새긴 부분이 함께 이어져요.

3. 페트라는 여러 지역을 오가는 대상 무역의 길목이었어요. 물건을 나르던 사람들이 모이면서 서로 다른 문화와 건축 방식도 만났어요.

탐험 키워드: 암만 · 페트라 · 나바테아 사람들 · 바위 건축 · 골짜기 · 대상 무역 · 길목 · 홍해 · 사해 · 문화 교류

엽서 장면: 페트라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jo/
- https://whc.unesco.org/en/list/326/

## 카자흐스탄 · KZ

수도·정부 소재지: 아스타나

1. 카자흐스탄은 아시아에 있어요. 수도는 아스타나예요.

2. 사르아르카의 초원과 호수는 멀리 이동하는 물새들의 쉼터예요. 철새는 먹이와 번식 장소를 찾아 계절에 따라 여러 지역을 오가요.

3. 투르키스탄의 호자 아흐메드 야사위 영묘는 티무르 시대의 큰 건물이에요. 여기서 시도한 건축 기술은 다른 도시를 짓는 데도 이어졌어요.

탐험 키워드: 아스타나 · 사르아르카 · 초원 · 호수 · 철새 · 습지 · 투르키스탄 · 야사위 영묘 · 티무르 시대 · 바이테레크 타워

엽서 장면: 아스타나 바이테레크 타워

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kz/
- https://whc.unesco.org/en/list/1102/
- https://whc.unesco.org/en/list/1103/

## 케냐 · KE

수도·정부 소재지: 나이로비

1. 케냐의 수도는 나이로비예요. 케냐에는 초원과 산, 큰 호수와 대지구대가 있어요.

2. 마사이 마라 초원에는 얼룩말과 누 같은 동물들이 계절에 따라 이동해요.

3. 케냐의 공용어는 스와힐리어와 영어이고, 여러 공동체가 다양한 언어를 써요.

탐험 키워드: 나이로비 · 마사이 마라 · 케냐산 · 대지구대 · 누 · 기린 · 스와힐리어 · 우갈리 · 육상 · 빅토리아호

엽서 장면: 마사이 마라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 키리바시 · KI

수도·정부 소재지: 남타라와

1. 키리바시는 오세아니아에 있어요. 수도는 남타라와예요.

2. 피닉스 제도 보호 구역은 산호섬과 그 주변 바다를 함께 지켜요. 바다 아래에는 해저산과 깊은 물속 생활 공간도 있어요.

3. 산호와 물고기, 바닷새는 같은 바다를 서로 다른 방식으로 이용해요. 섬뿐 아니라 넓은 바다를 보호하는 이유를 생각해 보아요.

탐험 키워드: 남타라와 · 피닉스 제도 · 산호섬 · 해저산 · 산호 · 물고기 · 바닷새 · 깊은 바다 · 해양 보호 구역 · 마네아바 공동 회관

엽서 장면: 마네아바 공동 회관

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ki/
- https://whc.unesco.org/en/list/1325/

## 코소보 · XK

수도·정부 소재지: 프리슈티나

1. 코소보는 유럽에 있어요. 수도는 프리슈티나예요.

2. 프리슈티나의 국립도서관은 책과 신문, 사진 같은 자료를 모으는 곳이에요. 서로 다른 기록을 보존하면 지난 생활과 문화를 함께 배울 수 있어요.

3. 도서관은 오래된 자료를 디지털 기록으로도 소개해요. 종이로 남긴 이야기와 디지털 자료는 모두 지식을 다음 사람에게 전하는 방법이에요.

탐험 키워드: 프리슈티나 · 프리슈티나 국립도서관 · 책 · 신문 · 사진 · 디지털 자료 · 문화 기록 · 도서관 · 자료 보존 · 프리슈티나와 주변 풍경

엽서 장면: 프리슈티나와 주변 풍경

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://bkk-pjeterbogdani.rks-gov.net/en/

## 쿠웨이트 · KW

수도·정부 소재지: 쿠웨이트시티

1. 쿠웨이트는 아시아에 있어요. 수도는 쿠웨이트시티예요.

2. 쿠웨이트 타워의 둥근 부분에는 물을 저장하는 시설이 있어요. 멋진 건축물 안에 도시의 생활을 돕는 기능이 숨어 있답니다.

3. 물을 높은 곳에 저장하면 아래쪽으로 보내는 데 중력을 이용할 수 있어요. 물 저장탑을 보며 구와 기둥 같은 입체 모양도 찾아보세요.

탐험 키워드: 쿠웨이트시티 · 쿠웨이트 타워 · 물 저장 · 저수조 · 중력 · 구 모양 · 기둥 · 도시 생활 · 생활 속 건축 · 물 이용

엽서 장면: 쿠웨이트시티 해안과 쿠웨이트 타워

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.archnet.org/sites/135

## 키르기스스탄 · KG

수도·정부 소재지: 비슈케크

1. 키르기스스탄은 아시아에 있어요. 수도는 비슈케크예요.

2. 오시의 술라이만산은 실크로드 길목에 서 있는 산이에요. 오래전 여행자들은 도시 뒤로 솟은 산을 중요한 길잡이로 삼았어요.

3. 산에는 동굴과 바위 그림, 오래된 예배 장소가 있어요. 사람과 동물, 기하학 무늬를 새긴 흔적은 산과 함께한 오랜 문화를 보여줘요.

탐험 키워드: 비슈케크 · 오시 · 술라이만산 · 실크로드 · 페르가나 계곡 · 동굴 · 바위 그림 · 기하학 무늬 · 길잡이 산 · 예배 장소

엽서 장면: 오시의 술라이만 성산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kg/
- https://whc.unesco.org/en/list/1230/

## 라오스 · LA

수도·정부 소재지: 비엔티안

1. 라오스는 아시아에 있어요. 수도는 비엔티안예요.

2. 루앙프라방은 라오스 전통 건축과 유럽 식민지 시대 건물이 함께 남은 도시예요. 지붕과 거리의 모습을 비교하면 여러 문화가 만난 흔적을 찾을 수 있어요.

3. 오래된 도시를 지킬 때는 한 건물만이 아니라 거리와 이웃 건물도 함께 살펴요. 이런 연결이 루앙프라방 특유의 도시 풍경을 만들어요.

탐험 키워드: 비엔티안 · 루앙프라방 · 라오스 전통 건축 · 도시 풍경 · 거리 · 지붕 · 문화 교류 · 식민지 시대 · 건축 보존 · 파 탓 루앙

엽서 장면: 파 탓 루앙

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/la/
- https://whc.unesco.org/en/list/479/

## 라트비아 · LV

수도·정부 소재지: 리가

1. 라트비아는 유럽에 있어요. 수도는 리가예요.

2. 리가는 한자 동맹의 무역 도시로 성장했어요. 옛 중심지와 나중에 세운 목조 건물은 도시가 넓어져 온 역사를 보여줘요.

3. 리가에는 아르누보 양식의 건물이 많이 남아 있어요. 건물 앞면의 곡선과 장식을 살피면 건축도 예술이 될 수 있다는 걸 알 수 있어요.

탐험 키워드: 리가 · 리가 역사 지구 · 아르누보 · 한자 동맹 · 목조 건물 · 구시가지 · 건물 앞면 · 무역 · 곡선 장식 · 리가 아르누보 건축

엽서 장면: 리가 아르누보 건축

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lv/
- https://whc.unesco.org/en/list/852/

## 레바논 · LB

수도·정부 소재지: 베이루트

1. 레바논은 아시아에 있어요. 수도는 베이루트예요.

2. 바알베크에는 로마 시대에 세운 커다란 신전들이 남아 있어요. 높은 돌기둥과 건물의 크기를 살피면 옛 건축 기술을 상상할 수 있어요.

3. 바알베크는 페니키아 시대부터 이어져 온 도시이며, 옛날에는 헬리오폴리스라고도 불렸어요. 한 도시의 이름과 건물에도 여러 시대의 역사가 담겨 있어요.

탐험 키워드: 베이루트 · 바알베크 · 로마 신전 · 돌기둥 · 페니키아 · 헬리오폴리스 · 건축 기술 · 유적 · 도시의 이름 · 시대의 변화

엽서 장면: 바알베크의 로마 신전 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lb/
- https://whc.unesco.org/en/list/294/

## 레소토 · LS

수도·정부 소재지: 마세루

1. 레소토는 아프리카에 있어요. 수도는 마세루예요.

2. 레소토의 셀라바테베와 남아프리카공화국의 공원이 함께 말로티·드라켄즈버그 공원을 이루어요. 자연을 지키는 일은 국경을 넘어 함께할 수 있어요.

3. 공원에는 사암 절벽과 동굴, 바위 웅덩이가 있어요. 서로 다른 서식 환경은 식물과 물고기, 수염수리 같은 새들이 살아갈 자리를 만들어 줘요.

탐험 키워드: 마세루 · 셀라바테베 · 말로티·드라켄즈버그 · 사암 절벽 · 동굴 · 바위 웅덩이 · 서식 환경 · 수염수리 · 국경을 넘는 협력 · 말레추냐네 폭포

엽서 장면: 말레추냐네 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ls/
- https://whc.unesco.org/en/list/985/

## 라이베리아 · LR

수도·정부 소재지: 몬로비아

1. 라이베리아는 아프리카에 있어요. 수도는 몬로비아예요.

2. 사포 국립공원은 라이베리아의 열대림을 지키는 곳이에요. 작은 피그미하마와 침팬지, 숲코끼리 같은 동물이 이 숲에 살아요.

3. 숲을 지키려면 동물뿐 아니라 주변 사람들의 생활도 살펴야 해요. 사포에서는 지역 주민과 산림 기관, 보호 단체가 함께 공원을 돌보고 있어요.

탐험 키워드: 몬로비아 · 사포 국립공원 · 열대림 · 피그미하마 · 침팬지 · 숲코끼리 · 지역 주민 · 산림 보호 · 야생동물 · 함께 돌보기

엽서 장면: 사포 국립공원

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.fauna-flora.org/projects/implementing-effective-management-sapo-national-park/

## 리비아 · LY

수도·정부 소재지: 트리폴리

1. 리비아는 아프리카에 있어요. 수도는 트리폴리예요.

2. 렙티스 마그나는 로마 시대에 번성했던 도시예요. 항구와 시장, 창고와 집터가 남아 있어 사람들이 일하고 살던 모습을 알려줘요.

3. 이 도시에서 태어난 셉티미우스 세베루스는 나중에 로마 황제가 되었어요. 그의 시대에 커진 도시를 통해 한 사람의 역사와 도시의 변화를 연결해 볼 수 있어요.

탐험 키워드: 트리폴리 · 렙티스 마그나 · 로마 시대 · 옛 항구 · 시장 · 창고 · 집터 · 셉티미우스 세베루스 · 도시의 성장 · 고고학

엽서 장면: 렙티스마그나 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ly/
- https://whc.unesco.org/en/list/183/

## 리히텐슈타인 · LI

수도·정부 소재지: 파두츠

1. 리히텐슈타인은 유럽에 있어요. 수도는 파두츠예요.

2. 파두츠성은 수도를 내려다보는 언덕 위에 있어요. 높은 곳에 세운 성은 주변 길과 마을을 멀리 살펴볼 수 있는 자리였어요.

3. 성 주변에서는 라인강 계곡의 풍경을 볼 수 있어요. 높은 언덕과 낮은 계곡을 비교하면 지형에 따라 건물의 자리를 고르는 방법을 생각해 볼 수 있어요.

탐험 키워드: 파두츠 · 파두츠성 · 라인강 계곡 · 언덕 · 성 · 높은 지대 · 계곡 · 지형 관찰 · 마을 풍경 · 건물의 위치

엽서 장면: 파두츠성과 알프스 라인 계곡

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://tourismus.li/en/activities/popular-sights-the-countryside/sights/?pn=6&sortBy=0

## 리투아니아 · LT

수도·정부 소재지: 빌뉴스

1. 리투아니아는 유럽에 있어요. 수도는 빌뉴스예요.

2. 빌뉴스의 역사 지구에는 고딕, 르네상스, 바로크 등 여러 양식의 건물이 있어요. 창문과 지붕, 장식을 비교하면 시대마다 달랐던 취향을 찾아볼 수 있어요.

3. 빌뉴스에는 중세에 만들어진 길의 배치가 남아 있어요. 오래된 거리와 건물은 도시가 오랫동안 문화의 중심지였다는 사실을 알려줘요.

탐험 키워드: 빌뉴스 · 빌뉴스 역사 지구 · 고딕 양식 · 르네상스 · 바로크 · 중세 거리 · 창문 · 지붕 · 건물 장식 · 빌뉴스 구시가지

엽서 장면: 빌뉴스 구시가지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lt/
- https://whc.unesco.org/en/list/541/

## 룩셈부르크 · LU

수도·정부 소재지: 룩셈부르크

1. 룩셈부르크는 유럽에 있어요. 수도는 룩셈부르크예요.

2. 룩셈부르크시에는 여러 시대에 덧붙인 성벽과 요새의 흔적이 있어요. 도시의 위치가 중요해서, 서로 다른 통치자들이 방어 시설을 고쳐 썼어요.

3. 1867년부터 요새 일부가 철거되었지만 옛 방어 시설의 모습은 남아 있어요. 남은 성벽과 구시가지를 비교하면 도시의 쓰임이 어떻게 바뀌었는지 배울 수 있어요.

탐험 키워드: 룩셈부르크 · 룩셈부르크 구시가지 · 요새 · 성벽 · 방어 시설 · 도시의 위치 · 1867년 · 옛 건축 · 통치의 변화 · 도시의 변화

엽서 장면: 룩셈부르크 구시가지와 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lu/
- https://whc.unesco.org/en/list/699/

## 마다가스카르 · MG

수도·정부 소재지: 안타나나리보

1. 마다가스카르는 아프리카에 있어요. 수도는 안타나나리보예요.

2. 마다가스카르의 칭기는 석회암이 뾰족하게 솟은 지형이에요. 물이 오랫동안 돌을 녹이고 깎으면서 독특한 바위 숲을 만들었어요.

3. 안드레파나의 건조림에는 여우원숭이와 여러 새가 살아요. 숲과 습지, 맹그로브처럼 다양한 환경을 지키면 그곳에 사는 생물도 함께 보호할 수 있어요.

탐험 키워드: 안타나나리보 · 칭기 · 석회암 · 바위 숲 · 안드레파나 건조림 · 여우원숭이 · 맹그로브 · 습지 · 침식 · 바오바브 풍경

엽서 장면: 바오바브 풍경

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mg/
- https://whc.unesco.org/en/list/494/

## 말라위 · MW

수도·정부 소재지: 릴롱궤

1. 말라위는 아프리카에 있어요. 수도는 릴롱궤예요.

2. 말라위호에는 시클리드라는 무리의 물고기가 다양하게 살아요. 같은 호수에서도 먹이나 살 곳이 달라지면 서로 다른 특징을 가진 물고기를 만날 수 있어요.

3. 말라위호의 많은 물고기는 이 호수에서만 자연적으로 살아요. 특정 지역에서만 발견되는 생물을 고유종이라고 하며, 그 서식지를 지키는 일이 중요해요.

탐험 키워드: 릴롱궤 · 말라위호 · 시클리드 · 민물고기 · 고유종 · 서식지 · 물고기의 먹이 · 호수 생태계 · 다양한 생물 · 서식지 보호

엽서 장면: 말라위 호수

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mw/
- https://whc.unesco.org/en/list/289/

## 말레이시아 · MY

수도·정부 소재지: 쿠알라룸푸르

수도는 쿠알라룸푸르이고 행정 중심지는 푸트라자야예요.

1. 수도는 쿠알라룸푸르이고 행정 중심지는 푸트라자야예요.

2. 보르네오섬의 키나발루산 주변에는 낮은 열대림부터 높은 산의 식물까지 다양한 생물이 있어요. 산을 오르면 높이에 따라 기후와 식물이 달라지는 걸 배울 수 있어요.

3. 키나발루 공원에는 동남아시아와 히말라야 등 여러 지역과 관련된 식물들이 함께 있어요. 한 산의 자연을 살피는 일은 생물이 퍼져 온 역사를 찾는 일이기도 해요.

탐험 키워드: 쿠알라룸푸르 · 키나발루산 · 보르네오섬 · 열대림 · 고도 · 산의 기후 · 식물 · 히말라야 · 생물의 분포 · 페트로나스 트윈 타워

엽서 장면: 페트로나스 트윈 타워

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/my/
- https://whc.unesco.org/en/list/1012/

## 몰디브 · MV

수도·정부 소재지: 말레

1. 몰디브는 아시아에 있어요. 수도는 말레예요.

2. 말레의 후쿠루 미스키는 산호석으로 지은 오래된 모스크예요. 돌을 다듬어 새긴 무늬는 바다의 섬에서 발달한 장인들의 솜씨를 보여줘요.

3. 몰디브의 전통 모스크에는 나무 기둥과 지붕, 칠 공예 장식도 쓰였어요. 서로 다른 재료를 어떻게 함께 사용했는지 살피면 건축과 공예를 연결할 수 있어요.

탐험 키워드: 말레 · 후쿠루 미스키 · 산호석 · 돌 조각 무늬 · 나무 기둥 · 지붕 · 칠 공예 · 전통 모스크 · 장인 · 몰디브 환초

엽서 장면: 몰디브 환초

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://visitmaldives.com/en/experience/mosques-in-maldives-a-standing-testament-to-the-local-craftsmanship
- https://whc.unesco.org/en/tentativelists/5812/

## 말리 · ML

수도·정부 소재지: 바마코

1. 말리는 아프리카에 있어요. 수도는 바마코예요.

2. 팀북투는 오랫동안 배움의 중심지였어요. 상코레와 오래된 모스크들은 사람들이 지식을 배우고 나누었던 도시의 역사를 보여줘요.

3. 팀북투의 유산은 사막의 환경과 함께 보아야 해요. 유네스코는 사막화가 이 유산에 주는 위험을 설명하며, 자연환경과 문화유산을 함께 돌볼 필요성을 알려줘요.

탐험 키워드: 바마코 · 팀북투 · 상코레 · 배움의 중심지 · 지식 나누기 · 옛 모스크 · 사막 · 사막화 · 문화유산 보호 · 젠네 대모스크

엽서 장면: 젠네 대모스크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ml/
- https://whc.unesco.org/en/list/119/

## 몰타 · MT

수도·정부 소재지: 발레타

1. 몰타는 유럽에 있어요. 수도는 발레타예요.

2. 발레타는 성벽과 요새, 궁전과 교회가 모여 있는 도시예요. 오래된 건축물들이 가까이 모여 있어 작은 지역에서도 여러 시대의 역사를 읽을 수 있어요.

3. 발레타의 역사에는 성 요한 기사단이 중요한 역할을 했어요. 도시를 둘러싼 방어 시설은 항구와 도시를 지키기 위해 건축을 활용한 예예요.

탐험 키워드: 발레타 · 성벽 · 요새 · 궁전 · 교회 · 성 요한 기사단 · 항구 · 방어 건축 · 도시 역사 · 발레타 그랜드 하버

엽서 장면: 발레타 그랜드 하버

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mt/
- https://whc.unesco.org/en/list/131/

## 마셜 제도 · MH

수도·정부 소재지: 마주로

1. 마셜 제도는 오세아니아에 있어요. 수도는 마주로예요.

2. 마셜 제도의 항해자들은 파도와 바람을 관찰하며 섬 사이를 오갔어요. 야자 줄기와 조개로 만든 항해 도표는 바다의 움직임을 배우는 도구였어요.

3. 이 도표는 종이 지도처럼 정확한 거리 비율을 나타내지 않았어요. 항해자들은 육지에서 내용을 익힌 뒤, 바다에서는 경험과 관찰을 바탕으로 길을 찾았어요.

탐험 키워드: 마주로 · 항해 도표 · 야자 줄기 · 조개 · 파도 · 바람 · 항해자 · 카누 · 축척 · 마주로 환초

엽서 장면: 마주로 환초

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mh/
- https://ocean.si.edu/human-connections/history-cultures/navigating-waters-micronesian-stick-charts

## 모리타니 · MR

수도·정부 소재지: 누악쇼트

1. 모리타니는 아프리카에 있어요. 수도는 누악쇼트예요.

2. 방다르갱 국립공원에는 모래언덕과 얕은 바다, 해안 습지가 함께 있어요. 많은 철새가 먹이를 찾거나 쉬어 가는 곳이에요.

3. 철새는 계절에 따라 먼 지역을 오가요. 이동 중에 쉴 수 있는 습지를 보호하는 일은 한 나라를 넘어 이어지는 새들의 여행을 돕는 일이에요.

탐험 키워드: 누악쇼트 · 방다르갱 · 철새 · 해안 습지 · 얕은 바다 · 모래언덕 · 계절 이동 · 새의 먹이 · 휴식 장소 · 습지 보호

엽서 장면: 방다르갱

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mr/
- https://whc.unesco.org/en/list/506/

## 모리셔스 · MU

수도·정부 소재지: 포트루이스

1. 모리셔스는 아프리카에 있어요. 수도는 포트루이스예요.

2. 르몬은 바다를 내려다보는 바위산이에요. 과거 노예로 붙잡혔던 사람들이 탈출해 몸을 피했던 장소로, 자유를 향한 역사를 기억하게 해요.

3. 르몬과 관련된 이야기는 사람들의 기억과 전승으로도 이어져 왔어요. 역사 공부에서는 건물뿐 아니라 전해지는 이야기와 사람의 존엄도 함께 살펴요.

탐험 키워드: 포트루이스 · 르몬 · 바위산 · 인도양 · 피난처 · 자유 · 구전 전통 · 기억 · 인간의 존엄 · 역사 배우기

엽서 장면: 르몬브라방산과 해안 경관

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mu/
- https://whc.unesco.org/en/list/1259/

## 멕시코 · MX

수도·정부 소재지: 멕시코시티

1. 멕시코의 수도 멕시코시티는 산으로 둘러싸인 높은 분지에 있어요.

2. 치첸이트사는 고대 마야 문명의 도시였고, 엘 카스티요라는 큰 석조 피라미드가 있어요.

3. 옥수수는 멕시코 음식에 널리 쓰이고, 여러 원주민 언어와 문화도 이어지고 있어요.

탐험 키워드: 멕시코시티 · 치첸이트사 · 유카탄반도 · 구리 협곡 · 왕나비 · 옥수수 · 타코 · 스페인어 · 나와틀어 · 마리아치

엽서 장면: 치첸이트사

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 미크로네시아 · FM

수도·정부 소재지: 팔리키르

1. 미크로네시아는 오세아니아에 있어요. 수도는 팔리키르예요.

2. 폰페이섬의 난마돌은 작은 인공 섬들이 모인 옛 유적이에요. 현무암과 산호 재료로 만든 섬 사이에 물길이 이어져 있어요.

3. 난마돌에는 옛 지도자들이 사용하던 궁전과 의식을 치르던 장소의 흔적이 남아 있어요. 섬들의 배치를 보면 바다와 함께 도시를 만들었던 방법을 배울 수 있어요.

탐험 키워드: 팔리키르 · 난마돌 · 폰페이섬 · 인공 섬 · 현무암 · 산호 재료 · 물길 · 옛 궁전 · 의식 장소 · 섬의 배치

엽서 장면: 난 마돌 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fm/
- https://whc.unesco.org/en/list/1503/

## 몰도바 · MD

수도·정부 소재지: 키시너우

1. 몰도바는 유럽에 있어요. 수도는 키시너우예요.

2. 몰도바에는 스트루베 측지 아크의 관측 지점이 있어요. 여러 나라의 지점을 삼각형으로 연결해 측정하며 지구의 크기와 모양을 연구했어요.

3. 이 측량은 19세기에 여러 나라가 협력한 과학 활동이에요. 정확한 측정이 지도 제작에 어떻게 도움을 주는지, 삼각형과 함께 생각해 볼 수 있어요.

탐험 키워드: 키시너우 · 스트루베 측지 아크 · 측량 · 삼각형 · 관측 지점 · 지구의 크기 · 지도 제작 · 19세기 · 과학 협력 · 오르헤이 베키

엽서 장면: 오르헤이 베키

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/md/
- https://whc.unesco.org/en/list/1187/

## 모나코 · MC

수도·정부 소재지: 모나코

1. 모나코는 유럽에 있어요. 수도는 모나코예요.

2. 모나코의 해양박물관은 바다 생물과 해양 연구를 소개하는 곳이에요. 수족관의 생물을 살펴보는 일은 바다 속 서식 환경에 관심을 갖는 출발점이 될 수 있어요.

3. 박물관은 바다의 자연과 보호 활동을 함께 알려줘요. 전시를 볼 때 생물의 이름뿐 아니라 어디에서 살고 무엇이 필요한지도 질문해 보세요.

탐험 키워드: 모나코 · 모나코 해양박물관 · 수족관 · 해양 연구 · 바다 생물 · 서식 환경 · 지중해 · 자연 보호 · 관찰 · 모나코 항구와 지중해 해안

엽서 장면: 모나코 항구와 지중해 해안

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://musee.oceano.org/en/

## 몽골 · MN

수도·정부 소재지: 울란바토르

1. 몽골의 수도는 울란바토르예요. 오르혼 계곡에는 유목 생활과 오랜 도시·사원의 역사가 함께 남아 있어요.

2. 나담 축제에서는 말타기 경주, 씨름, 활쏘기 같은 전통 경기를 즐겨요.

3. 모린후르는 머리 부분에 말 모양 장식이 있는 두 줄의 현악기예요. 활로 줄을 문질러 소리를 내요.

탐험 키워드: 울란바토르 · 오르혼 계곡 · 에르데네주 사원 · 초원 · 유목 생활 · 나담 · 말 경주 · 씨름 · 활쏘기 · 모린후르

엽서 장면: 고비 풍경과 게르

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mn/
- https://whc.unesco.org/en/list/1081/
- https://ich.unesco.org/en/RL/naadam-mongolian-traditional-festival-00395
- https://ich.unesco.org/en/RL/traditional-music-of-the-morin-khuur-00068

## 몬테네그로 · ME

수도·정부 소재지: 포드고리차

1. 몬테네그로는 유럽에 있어요. 수도는 포드고리차예요.

2. 코토르는 아드리아해 만에 자리한 오래된 항구 도시예요. 성벽과 교회, 오래된 건축물이 무역과 문화의 역사를 보여줘요.

3. 코토르의 유산은 1979년 지진으로 큰 피해를 입은 뒤 복원되었어요. 오래된 건물을 돌보는 일에는 역사 자료와 건축 기술을 함께 활용해야 해요.

탐험 키워드: 포드고리차 · 코토르 · 아드리아해 · 코토르만 · 항구 도시 · 성벽 · 옛 교회 · 지진 · 유산 복원 · 코토르 자연과 역사 지구

엽서 장면: 코토르 자연과 역사 지구

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/me/
- https://whc.unesco.org/en/list/125/

## 모로코 · MA

수도·정부 소재지: 라바트

1. 모로코의 수도 라바트는 대서양을 바라보는 해안 도시에요.

2. 모로코에는 아틀라스산맥과 사하라 사막, 대서양과 지중해 해안이 있어요.

3. 아랍어와 아마지그어는 모로코의 공식 언어예요.

탐험 키워드: 라바트 · 마라케시 · 쿠투비아 모스크 · 아틀라스산맥 · 사하라 사막 · 아마지그어 · 아랍어 · 쿠스쿠스 · 민트차 · 모자이크 타일

엽서 장면: 마라케시와 쿠투비아 모스크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 모잠비크 · MZ

수도·정부 소재지: 마푸투

1. 모잠비크는 아프리카에 있어요. 수도는 마푸투예요.

2. 모잠비크섬은 인도양 무역에 중요한 옛 항구였어요. 섬의 건물들에는 여러 지역의 사람들이 바다를 오가며 만난 역사가 담겨 있어요.

3. 섬에는 돌과 석회로 지은 건물, 나무와 식물 재료를 쓴 집들이 함께 있어요. 주변에서 구할 수 있는 재료와 생활 방식이 집의 모습을 바꾼다는 걸 배울 수 있어요.

탐험 키워드: 마푸투 · 모잠비크섬 · 인도양 무역 · 옛 항구 · 돌 건축 · 석회 · 나무 재료 · 마쿠티 집 · 문화의 만남 · 마푸투 기차역

엽서 장면: 마푸투 기차역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mz/
- https://whc.unesco.org/en/list/599/

## 미얀마 · MM

수도·정부 소재지: 네피도

1. 미얀마는 아시아에 있어요. 수도는 네피도예요.

2. 바간은 에야와디강 가까이에 있는 옛 도시의 유적이에요. 많은 사원과 탑, 벽화와 조각이 과거 사람들의 신앙과 예술을 보여줘요.

3. 바간은 주로 11~13세기에 번성한 왕국의 중심지였어요. 오늘날의 수도 네피도와 구별하며, 도시의 역할이 시대에 따라 달라진다는 걸 배워요.

탐험 키워드: 네피도 · 바간 · 에야와디강 · 사원 · 탑 · 벽화 · 조각 · 11~13세기 · 옛 왕국 · 도시의 역할

엽서 장면: 바간

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mm/
- https://whc.unesco.org/en/list/1588/

## 나미비아 · NA

수도·정부 소재지: 빈트후크

1. 나미비아는 아프리카에 있어요. 수도는 빈트후크예요.

2. 나미브 모래 바다는 바람이 쌓아 올린 모래언덕이 펼쳐진 곳이에요. 멀리에서 옮겨 온 모래가 강과 바다, 바람을 거쳐 사막의 풍경을 만들어요.

3. 이 해안 사막에서는 안개가 중요한 물 공급원이 돼요. 비가 적은 곳에서도 습기를 얻을 수 있어, 식물과 동물이 환경에 적응하며 살아가요.

탐험 키워드: 빈트후크 · 나미브 모래 바다 · 모래언덕 · 바람 · 안개 · 습기 · 모래의 이동 · 해안 사막 · 환경 적응 · 소수스블레이

엽서 장면: 소수스블레이

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/na/
- https://whc.unesco.org/en/list/1430/

## 나우루 · NR

수도·정부 소재지: 야렌

나우루에는 공식 수도가 없어요. 정부 기관이 있는 야렌 지구를 지도에 표시해요.

1. 나우루에는 공식 수도가 없어요. 정부 기관이 있는 야렌 지구를 지도에 표시해요.

2. 나우루는 산호초에 둘러싸인 작은 섬나라예요. 사람들이 많이 사는 해안의 띠 모양 땅과 섬 안쪽의 지형을 구별해 보세요.

3. 섬 안쪽에는 인산염을 캐면서 크게 달라진 땅이 있어요. 자원을 얻는 일이 자연을 바꿀 수 있다는 점과, 땅을 어떻게 돌볼지 함께 생각하게 해요.

탐험 키워드: 야렌 · 산호초 · 해안 지대 · 섬 안쪽 · 인산염 · 자원 채굴 · 땅의 변화 · 환경 돌보기 · 태평양 · 부아다 석호

엽서 장면: 부아다 석호

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thecommonwealth.org/our-member-countries/nauru
- https://thecommonwealth.org/our-member-countries/naeoro

## 네팔 · NP

수도·정부 소재지: 카트만두

1. 네팔은 아시아에 있어요. 수도는 카트만두예요.

2. 카트만두 계곡에는 카트만두, 파탄, 박타푸르의 옛 궁전 광장이 있어요. 광장 주변의 건물과 조각은 여러 도시가 키운 예술과 역사를 보여줘요.

3. 계곡에는 스와얌부와 보드나트의 불교 탑, 파슈파티의 힌두교 사원이 있어요. 같은 지역에서도 서로 다른 신앙과 문화의 모습을 존중하며 배울 수 있어요.

탐험 키워드: 카트만두 · 카트만두 계곡 · 파탄 · 박타푸르 · 궁전 광장 · 스와얌부 · 보드나트 · 파슈파티 · 불교 · 힌두교

엽서 장면: 스와얌부나트

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/np/
- https://whc.unesco.org/en/list/121/

## 네덜란드 · NL

수도·정부 소재지: 암스테르담

수도는 암스테르담이지만 정부와 의회는 헤이그에 있어요.

1. 네덜란드의 수도는 암스테르담이에요. 정부와 의회가 있는 도시는 헤이그예요.

2. 킨더데이크의 풍차와 수로는 낮은 땅에서 물을 빼내는 데 쓰였어요. 풍차는 물을 관리하는 기술의 일부예요.

3. 암스테르담에는 고리처럼 이어지는 운하가 있어요. 운하 옆으로 오래된 집들과 거리가 이어져요.

탐험 키워드: 암스테르담 · 헤이그 · 킨더데이크 · 풍차 · 운하 · 제방 · 간척지 · 물 관리 · 자전거 · 네덜란드어

엽서 장면: 암스테르담 운하

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/nl/
- https://whc.unesco.org/en/list/818/
- https://whc.unesco.org/en/list/1349/
- https://www.holland.com/de/tourist/lass-dich-inspirieren

## 뉴질랜드 · NZ

수도·정부 소재지: 웰링턴

1. 뉴질랜드의 수도 웰링턴은 북섬의 남쪽 끝, 바다가 만나는 곳에 있어요.

2. 마오리어는 뉴질랜드의 공식 언어 가운데 하나예요.

3. 키위는 뉴질랜드에 사는 날지 못하는 새로, 밤에 주로 활동해요.

탐험 키워드: 웰링턴 · 밀퍼드 사운드 · 남알프스산맥 · 키위새 · 마오리 · 마오리어 · 항이 · 은고사리 · 피오르드랜드 · 웰링턴 케이블카

엽서 장면: 밀퍼드 사운드

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 니카라과 · NI

수도·정부 소재지: 마나과

1. 니카라과는 아메리카에 있어요. 수도는 마나과예요.

2. 레온 대성당은 바로크에서 신고전주의로 건축 양식이 바뀌던 시기에 세워졌어요. 한 건물 안에서도 서로 다른 시대의 특징을 찾아볼 수 있어요.

3. 대성당의 안쪽은 자연광이 풍부하고 장식이 차분한 편이에요. 빛이 들어오는 방식과 천장의 장식을 비교하며, 건축가가 공간을 어떻게 만들었는지 생각해 보세요.

탐험 키워드: 마나과 · 레온 대성당 · 바로크 · 신고전주의 · 자연광 · 천장 장식 · 건축 양식 · 실내 공간 · 빛과 건물 · 오메테페섬

엽서 장면: 오메테페섬

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ni/
- https://whc.unesco.org/en/list/1236/

## 니제르 · NE

수도·정부 소재지: 니아메

1. 니제르는 아프리카에 있어요. 수도는 니아메예요.

2. 아이르·테네레 보호 구역에는 사하라 사막의 모래 지형과 화산암 산지가 함께 있어요. 사막은 모두 같은 모래밭이 아니라 여러 지형이 만나는 곳이에요.

3. 아이르 산지에는 주변 사막과 다른 기후와 생물이 나타나요. 산과 평지의 환경을 비교하면, 생물이 살 수 있는 조건이 어떻게 달라지는지 배울 수 있어요.

탐험 키워드: 니아메 · 아이르산지 · 테네레 사막 · 사하라 · 화산암 · 모래 지형 · 산지 기후 · 사막 생물 · 지형 비교 · 아이르·테네레 사막

엽서 장면: 아이르·테네레 사막

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ne/
- https://whc.unesco.org/en/list/573/

## 나이지리아 · NG

수도·정부 소재지: 아부자

1. 나이지리아의 수도 아부자는 거대한 화강암 바위 아소 록 가까이에 있어요.

2. 니제르강과 베누에강은 로코자 근처에서 만난 뒤 남쪽으로 흘러 바다에 닿아요.

3. 나이지리아에는 여러 언어와 음악, 영화가 있어요. 영어는 공식 언어예요.

탐험 키워드: 아부자 · 아소 록 · 니제르강 · 베누에강 · 요루바어 · 하우사어 · 졸로프 라이스 · 놀리우드 · 말하는 북 · 카카오

엽서 장면: 아소 록

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 북한 · KP

수도·정부 소재지: 평양

1. 북한은 아시아에 있어요. 수도는 평양예요.

2. 백두산의 천지는 화산 활동으로 생긴 큰 움푹한 지형에 물이 고인 호수예요. 이런 지형을 칼데라라고 하며, 바위와 호수에서 화산의 역사를 읽을 수 있어요.

3. 백두산 주변에는 온천과 용암 지형, 빙하가 깎아 만든 지형도 있어요. 한 산에서 지구 내부의 열과 얼음이 풍경을 바꾸는 서로 다른 작용을 배울 수 있어요.

탐험 키워드: 평양 · 백두산 · 천지 · 칼데라 · 화산 활동 · 온천 · 용암 · 빙하 · 지열 · 지구의 변화

엽서 장면: 백두산과 천지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kp/
- https://www.unesco.org/en/iggp/mt-paektu-unesco-global-geopark

## 북마케도니아 · MK

수도·정부 소재지: 스코페

1. 북마케도니아는 유럽에 있어요. 수도는 스코페예요.

2. 오흐리드호에는 이 지역에서만 자연적으로 사는 물속 생물이 많아요. 오래된 호수의 서식 환경을 보호하면 독특한 생물들의 삶도 지킬 수 있어요.

3. 호숫가의 오흐리드에는 오래된 수도원과 성화가 남아 있어요. 이 지역은 자연과 문화의 가치를 함께 지녀, 호수와 도시를 연결해 배울 수 있어요.

탐험 키워드: 스코페 · 오흐리드호 · 고유종 · 물속 생물 · 호수 보호 · 오흐리드 · 수도원 · 성화 · 자연과 문화 · 스코페 돌다리

엽서 장면: 스코페 돌다리

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mk/
- https://whc.unesco.org/en/list/99/

## 노르웨이 · NO

수도·정부 소재지: 오슬로

1. 노르웨이의 수도 오슬로는 숲과 피오르가 가까운 바닷가에 있어요.

2. 피오르는 빙하가 땅을 깊게 깎고 바닷물이 들어와 만들어진 긴 바다 물길이에요.

3. 노르웨이 북쪽에서는 밤하늘에 오로라가 춤추는 모습을 볼 수 있어요.

탐험 키워드: 오슬로 · 게이랑에르 피오르 · 북극광 · 스발바르 · 스칸디나비아산맥 · 사미 사람들 · 연어 · 브라운 치즈 · 노르웨이어 · 순록

엽서 장면: 게이랑에르 피오르

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 오만 · OM

수도·정부 소재지: 무스카트

1. 오만은 아시아에 있어요. 수도는 무스카트예요.

2. 오만의 아플라즈는 샘이나 땅속 물을 마을과 밭으로 보내는 옛 물길이에요. 높은 곳에서 낮은 곳으로 흐르는 물과 중력을 이용해요.

3. 물을 나누어 쓰는 일에는 마을 사람들의 협력이 중요했어요. 물길의 역사에서 농사 기술뿐 아니라, 소중한 자원을 공평하게 사용하는 약속도 배울 수 있어요.

탐험 키워드: 무스카트 · 아플라즈 · 물길 · 샘 · 지하수 · 중력 · 농사 · 물 나누기 · 공동체 협력 · 술탄 카부스 대모스크

엽서 장면: 술탄 카부스 대모스크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/om/
- https://whc.unesco.org/en/list/1207/

## 파키스탄 · PK

수도·정부 소재지: 이슬라마바드

1. 파키스탄의 수도 이슬라마바드는 마르갈라 언덕 아래에 계획해 세운 도시예요.

2. 파이살 모스크는 산을 배경으로 솟은 네 개의 높은 첨탑이 눈에 띄어요.

3. 인더스강은 파키스탄을 지나 아라비아해로 흘러가요.

탐험 키워드: 이슬라마바드 · 파이살 모스크 · 마르갈라 언덕 · 인더스강 · K2 · 트럭 예술 · 우르두어 · 망고 · 비리야니 · 마르코르

엽서 장면: 파이살 모스크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 팔라우 · PW

수도·정부 소재지: 응게룰무드

1. 팔라우는 오세아니아에 있어요. 수도는 응게룰무드예요.

2. 팔라우의 록 아일랜드에는 버섯처럼 생긴 석회암 섬들과 산호초가 있어요. 섬과 산호초 사이의 여러 서식 환경은 다양한 바다 생물의 보금자리예요.

3. 섬 안에는 육지로 바다와 분리된 해수 호수도 있어요. 떨어진 서식 환경을 비교하면 생물들이 서로 다른 조건에 적응하는 모습을 생각해 볼 수 있어요.

탐험 키워드: 응게룰무드 · 록 아일랜드 · 석회암 섬 · 산호초 · 석호 · 해수 호수 · 바다 생물 · 서식 환경 · 고립된 환경 · 환경 적응

엽서 장면: 록 아일랜드 석호

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pw/
- https://whc.unesco.org/en/list/1386/

## 팔레스타인 · PS

수도·정부 소재지: 라말라

팔레스타인은 동예루살렘을 수도로 주장하며, 라말라는 행정 중심지예요.

1. 팔레스타인은 동예루살렘을 수도로 주장하며, 라말라는 행정 중심지예요.

2. 고대 예리코의 텔에스술탄은 사람들이 살며 남긴 흔적이 층층이 쌓인 언덕이에요. 성벽과 탑의 유적은 오래전 공동체의 생활을 알려줘요.

3. 유적 가까이에는 아인에스술탄 샘이 있어요. 물을 얻을 수 있는 장소와 오래 머무는 마을의 관계를 살피며, 사람들이 정착해 살기 시작한 역사를 배워요.

탐험 키워드: 라말라 · 고대 예리코 · 텔에스술탄 · 유적의 층 · 아인에스술탄 샘 · 옛 성벽 · 돌탑 · 정착 생활 · 공동체 · 고고학

엽서 장면: 고대 예리코와 텔에스술탄

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ps/
- https://whc.unesco.org/en/list/1687/

## 파나마 · PA

수도·정부 소재지: 파나마시티

1. 파나마는 아메리카에 있어요. 수도는 파나마시티예요.

2. 파나마 운하는 대서양과 태평양을 이어 주는 배의 길이에요. 배는 갑문이라는 물방에서 수면 높이를 바꾸며 높은 호수와 낮은 바다 사이를 이동해요.

3. 갑문에 물을 넣으면 배도 수면과 함께 올라가고, 물을 빼면 내려가요. 운하는 물에 뜨는 힘과 중력을 이용한 큰 공학 시설이에요.

탐험 키워드: 파나마시티 · 파나마 운하 · 갑문 · 대서양 · 태평양 · 가툰호 · 수면 높이 · 부력 · 중력 · 공학

엽서 장면: 파나마 운하 갑문

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pa/
- https://pancanal.com/en/design-of-the-locks/

## 파푸아뉴기니 · PG

수도·정부 소재지: 포트모르즈비

1. 파푸아뉴기니는 오세아니아에 있어요. 수도는 포트모르즈비예요.

2. 뉴기니 고지대의 쿠크 유적에는 아주 오래전 농사를 지은 흔적이 있어요. 땅을 높여 밭을 만들거나 물을 빼는 도랑을 판 자리를 찾을 수 있어요.

3. 쿠크에서는 사람들이 식물을 얻던 방식이 농사로 발전한 과정을 연구해요. 작은 도랑과 흙의 변화도 사람들이 생활을 바꾼 역사를 알려주는 자료가 돼요.

탐험 키워드: 포트모르즈비 · 쿠크 농경 유적 · 뉴기니 고지대 · 농사의 시작 · 높인 밭 · 배수 도랑 · 습지 · 흙의 흔적 · 고고학 · 포트모르즈비 국회의사당

엽서 장면: 포트모르즈비 국회의사당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pg/
- https://whc.unesco.org/en/list/887/

## 파라과이 · PY

수도·정부 소재지: 아순시온

1. 파라과이는 아메리카에 있어요. 수도는 아순시온예요.

2. 트리니다드와 헤수스 데 타바랑게에는 17~18세기 선교 공동체의 유적이 있어요. 교회뿐 아니라 집과 학교, 작업장도 남아 당시의 마을 생활을 보여줘요.

3. 이 유적의 건축과 예술에는 원주민의 요소와 유럽에서 온 양식이 함께 있어요. 서로 다른 문화의 만남을 살피되, 당시 원주민들의 경험도 함께 배워야 해요.

탐험 키워드: 아순시온 · 트리니다드 선교 유적 · 헤수스 데 타바랑게 · 17~18세기 · 옛 학교 · 작업장 · 원주민 문화 · 문화의 만남 · 건축 양식 · 이타이푸 댐

엽서 장면: 이타이푸 댐

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/py/
- https://whc.unesco.org/en/list/648/

## 페루 · PE

수도·정부 소재지: 리마

1. 페루의 수도 리마는 태평양 해안에 있고, 안데스산맥과 아마존 열대우림도 페루에 걸쳐 있어요.

2. 마추픽추는 잉카 사람들이 안데스산맥 높은 곳에 세운 옛 도시예요.

3. 감자는 안데스 지역에서 오래전부터 길러졌고, 페루에는 여러 종류의 감자가 있어요.

탐험 키워드: 리마 · 마추픽추 · 안데스산맥 · 아마존강 · 알파카 · 감자 · 세비체 · 케추아어 · 나스카 선 · 퀴노아

엽서 장면: 마추픽추

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 필리핀 · PH

수도·정부 소재지: 마닐라

1. 필리핀의 수도 마닐라는 루손섬의 마닐라만을 따라 자리해요.

2. 바나우에 계단식 논은 산비탈을 따라 이어지며 이푸가오 사람들의 오랜 농사 지식을 보여줘요.

3. 필리핀은 태평양 서쪽에 있는 수천 개의 섬으로 이루어진 나라예요.

탐험 키워드: 마닐라 · 바나우에 계단식 논 · 이푸가오 사람들 · 루손섬 · 지프니 · 망고 · 아도보 · 안경원숭이 · 필리핀어 · 태평양

엽서 장면: 바나우에 계단식 논

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 폴란드 · PL

수도·정부 소재지: 바르샤바

1. 폴란드의 수도 바르샤바는 비스와강 양쪽으로 펼쳐져 있어요.

2. 바르샤바 구시가지는 제2차 세계대전 뒤 많은 건물을 다시 세워 되살렸어요.

3. 폴란드의 비아워비에자 숲에는 유럽들소가 살아요.

탐험 키워드: 바르샤바 · 바르샤바 구시가지 · 왕궁 · 비스와강 · 비아워비에자 숲 · 유럽들소 · 피에로기 · 쇼팽 · 폴란드어 · 발트해

엽서 장면: 바르샤바 구시가지와 왕궁

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 포르투갈 · PT

수도·정부 소재지: 리스본

1. 포르투갈의 수도 리스본은 타구스강 어귀 가까운 언덕 위에 있어요.

2. 벨렝탑은 1500년대 초에 리스본의 강가를 지키도록 세운 요새예요.

3. 포르투갈에서는 코르크참나무 껍질로 병마개에 쓰이는 코르크를 만들어요.

탐험 키워드: 리스본 · 벨렝탑 · 타구스강 · 아줄레주 타일 · 노란 트램 · 코르크참나무 · 나타 · 대서양 · 포르투갈어 · 마데이라섬

엽서 장면: 벨렝탑

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 카타르 · QA

수도·정부 소재지: 도하

1. 카타르는 아시아에 있어요. 수도는 도하예요.

2. 알주바라는 진주를 채취하고 물건을 거래하던 옛 해안 도시예요. 항구와 집터는 바다를 통해 여러 지역이 연결되었던 역사를 보여줘요.

3. 사막에서 날아온 모래가 옛 거리와 건물 흔적을 덮어 보호했어요. 고고학자들은 모래 아래의 집과 물길을 조사하며 과거 도시의 모습을 알아내요.

탐험 키워드: 도하 · 알주바라 · 진주 채취 · 해안 무역 · 옛 항구 · 사막 모래 · 집터 · 옛 물길 · 발굴 · 바다의 연결

엽서 장면: 알주바라 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/qa/
- https://whc.unesco.org/en/list/1402/

## 대한민국 · KR

수도·정부 소재지: 서울

1. 대한민국은 동아시아 한반도의 남쪽에 있고, 수도는 서울이에요.

2. 한글은 세종대왕과 학자들이 만들고 1446년에 널리 알렸어요.

3. 서울에서는 북촌 한옥마을의 기와지붕과 N서울타워를 함께 볼 수 있어요.

탐험 키워드: 서울 · N서울타워 · 북촌 한옥마을 · 제주도 · 한라산 · 김치 · 비빔밥 · 한글 · 한복 · 태권도

엽서 장면: N서울타워와 북촌 한옥마을

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 콩고 · CG

수도·정부 소재지: 브라자빌

1. 콩고는 아프리카에 있어요. 수도는 브라자빌예요.

2. 오잘라·코쿠아에는 숲과 사바나 등 여러 생태계가 만나는 지역이 있어요. 풀밭과 숲을 비교하면 환경마다 다른 생물의 보금자리를 찾을 수 있어요.

3. 이곳은 중앙아프리카의 숲코끼리와 다양한 영장류를 보호하는 중요한 곳이에요. 오랜 시간 숲이 퍼지고 변화한 흔적도 남아 자연의 역사를 연구하게 해요.

탐험 키워드: 브라자빌 · 오잘라·코쿠아 · 숲코끼리 · 영장류 · 사바나 · 열대림 · 생태계 · 숲의 변화 · 서식지 · 콩고공화국의 상가 열대우림

엽서 장면: 콩고공화국의 상가 열대우림

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cg/
- https://whc.unesco.org/en/list/692/

## 루마니아 · RO

수도·정부 소재지: 부쿠레슈티

1. 루마니아는 유럽에 있어요. 수도는 부쿠레슈티예요.

2. 다뉴브강은 흑해로 흘러들며 여러 물길과 습지가 펼쳐진 삼각주를 만들어요. 강이 운반한 흙과 모래가 쌓이면 강 어귀의 땅도 달라져요.

3. 다뉴브 삼각주의 호수와 습지는 여러 새와 민물고기의 서식지예요. 물길이 이어진 환경을 보호하는 일은 강과 바다 사이의 생물을 지키는 일이에요.

탐험 키워드: 부쿠레슈티 · 다뉴브 삼각주 · 다뉴브강 · 흑해 · 삼각주 · 퇴적물 · 강 어귀 · 습지 · 민물고기 · 브란성

엽서 장면: 브란성

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ro/
- https://whc.unesco.org/en/list/588/

## 러시아 · RU

수도·정부 소재지: 모스크바

1. 러시아의 수도는 모스크바예요. 러시아는 유럽과 아시아에 걸쳐 있는 넓은 나라예요.

2. 시베리아의 바이칼호는 세계에서 가장 깊은 호수이며 담수가 아주 많아요.

3. 시베리아 횡단 철도는 모스크바에서 러시아 동쪽까지 아주 먼 거리를 달려요.

탐험 키워드: 모스크바 · 성 바실리 대성당 · 붉은 광장 · 바이칼호 · 시베리아 · 타이가 · 마트료시카 · 러시아어 · 발레 · 시베리아 횡단 철도

엽서 장면: 성 바실리 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 르완다 · RW

수도·정부 소재지: 키갈리

1. 르완다는 아프리카에 있어요. 수도는 키갈리예요.

2. 늉웨 국립공원에는 열대림뿐 아니라 이탄 습지와 풀밭도 있어요. 나무와 양치식물, 동물들이 함께 살아가는 다양한 환경을 살펴볼 수 있어요.

3. 늉웨는 침팬지와 많은 새를 보호하는 중요한 곳이에요. 숲이 줄어들면 먹이와 보금자리도 달라지므로, 생물을 지키려면 서식지까지 함께 돌봐야 해요.

탐험 키워드: 키갈리 · 늉웨 국립공원 · 열대림 · 이탄 습지 · 풀밭 · 양치식물 · 침팬지 · 새 · 생물 다양성 · 화산 국립공원과 마운틴고릴라

엽서 장면: 화산 국립공원과 마운틴고릴라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rw/
- https://whc.unesco.org/en/list/1697/

## 세인트키츠 네비스 · KN

수도·정부 소재지: 바스테르

1. 세인트키츠 네비스는 아메리카에 있어요. 수도는 바스테르예요.

2. 브림스톤힐 요새는 17~18세기 카리브해의 방어 건축을 보여줘요. 언덕의 요새를 보면 높은 지형이 주변을 살피는 데 어떻게 쓰였는지 생각할 수 있어요.

3. 이 요새는 영국인이 설계하고 노예로 붙잡힌 아프리카인들이 지었어요. 멋진 건물의 역사뿐 아니라, 그곳에서 일한 사람들의 삶과 존엄도 기억해야 해요.

탐험 키워드: 바스테르 · 브림스톤힐 요새 · 카리브해 · 언덕 · 방어 건축 · 17~18세기 · 식민지 시대 · 건설 노동 · 인간의 존엄 · 역사 기억하기

엽서 장면: 브림스톤힐 요새 국립공원

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kn/
- https://whc.unesco.org/en/list/910/

## 세인트루시아 · LC

수도·정부 소재지: 캐스트리스

1. 세인트루시아는 아메리카에 있어요. 수도는 캐스트리스예요.

2. 세인트루시아의 피통은 바다 가까이 나란히 솟은 두 화산 봉우리예요. 주변의 온천과 지열 현상도 땅속 열이 지형에 영향을 준다는 걸 보여줘요.

3. 피통 주변에는 숲과 산호초가 함께 있어요. 산 위의 식물과 바닷속 생물을 연결해 살피면, 한 지역 안에도 여러 생태계가 있다는 걸 배울 수 있어요.

탐험 키워드: 캐스트리스 · 피통 · 그로피통 · 프티피통 · 화산 봉우리 · 온천 · 지열 · 산호초 · 숲 · 피통 자연 경관

엽서 장면: 피통 자연 경관

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lc/
- https://whc.unesco.org/en/list/1161/

## 세인트빈센트 그레나딘 · VC

수도·정부 소재지: 킹스타운

1. 세인트빈센트 그레나딘은 아메리카에 있어요. 수도는 킹스타운예요.

2. 킹스타운 근처의 식물원에서는 세인트빈센트앵무를 만날 수 있어요. 이 나라의 국조이며, 자연에서는 세인트빈센트섬의 숲을 보금자리로 삼아요.

3. 다크뷰 폭포는 숲 속 절벽에서 두 줄기의 물이 떨어지는 곳이에요. 폭포와 숲을 함께 관찰하면 물과 식물, 새가 이어진 자연환경을 배울 수 있어요.

탐험 키워드: 킹스타운 · 세인트빈센트앵무 · 식물원 · 국조 · 다크뷰 폭포 · 열대림 · 절벽 · 폭포 · 새 관찰 · 킹스타운과 주변 풍경

엽서 장면: 킹스타운과 주변 풍경

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://discoversvg.com/what-to-do/eco-adventures/

## 사모아 · WS

수도·정부 소재지: 아피아

1. 사모아는 오세아니아에 있어요. 수도는 아피아예요.

2. 우폴루섬의 토 수아 오션 트렌치는 땅 아래로 깊게 내려간 물웅덩이예요. 주변 지형과 물을 함께 살피면 섬의 자연이 만든 독특한 공간을 배울 수 있어요.

3. 사모아의 전통 집인 팔레에는 옆면이 열린 형태가 있어요. 집의 모양을 살피며 기후와 생활 방식이 건축에 어떤 영향을 주는지 생각해 보세요.

탐험 키워드: 아피아 · 토 수아 오션 트렌치 · 우폴루섬 · 자연 물웅덩이 · 섬의 지형 · 팔레 · 열린 집 · 전통 건축 · 기후와 집 · 사모아의 생활 문화

엽서 장면: 토 수아 오션 트렌치

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.samoa.travel/pagepreview/must-dos-in-samoa

## 산마리노 · SM

수도·정부 소재지: 산마리노

1. 산마리노는 유럽에 있어요. 수도는 산마리노예요.

2. 티타노산 위의 산마리노 구시가지에는 방어탑과 성벽, 성문이 있어요. 산 위에 자리한 도시에서 지형과 건축이 만나는 모습을 배울 수 있어요.

3. 산마리노의 역사 지구는 중세부터 이어진 공화국의 전통을 보여줘요. 옛 건물에 지금도 도시의 기관이 있어, 유산이 생활 속에서 이어질 수 있음을 알려줘요.

탐험 키워드: 산마리노 · 티타노산 · 산마리노 구시가지 · 방어탑 · 성벽 · 성문 · 중세 · 공화국 · 도시 기관 · 살아 있는 유산

엽서 장면: 산마리노 구시가지와 티타노산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sm/
- https://whc.unesco.org/en/list/1245/

## 상투메 프린시페 · ST

수도·정부 소재지: 상투메

1. 상투메 프린시페는 아프리카에 있어요. 수도는 상투메예요.

2. 프린시페섬은 기니만에 있는 화산섬이에요. 바다에서 솟아난 섬의 지형을 보며, 화산 활동이 새로운 땅을 만드는 과정을 배울 수 있어요.

3. 프린시페 생물권보전지역에는 섬의 육지와 주변 바다, 작은 섬들이 포함돼요. 자연 보호를 생각할 때 숲과 해안, 바다를 이어서 살펴야 한다는 걸 알려줘요.

탐험 키워드: 상투메 · 프린시페섬 · 기니만 · 화산섬 · 섬의 형성 · 생물권보전지역 · 육지와 바다 · 작은 섬 · 해안 · 피코카우그란드와 상투메의 열대우림

엽서 장면: 피코카우그란드와 상투메의 열대우림

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.unesco.org/en/mab/island-principe

## 사우디아라비아 · SA

수도·정부 소재지: 리야드

1. 사우디아라비아의 수도는 리야드예요. 사우디아라비아는 아라비아반도의 넓은 지역을 차지해요.

2. 헤그라에는 나바테아 사람들이 약 2천 년 전에 바위를 깎아 만든 무덤들이 있어요.

3. 사우디아라비아는 홍해와 페르시아만에 모두 해안이 있어요.

탐험 키워드: 리야드 · 헤그라 · 알울라 · 아라비아 사막 · 홍해 · 낙타 · 대추야자 · 카부사 · 아랍어 · 나바테아 유적

엽서 장면: 헤그라

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 세네갈 · SN

수도·정부 소재지: 다카르

1. 세네갈은 아프리카에 있어요. 수도는 다카르예요.

2. 주지 조류 보호 구역은 세네갈강 삼각주의 호수와 습지로 이루어져 있어요. 펠리컨과 왜가리 등 많은 새가 물가에서 먹이를 찾고 쉬어요.

3. 큰 호수와 작은 물길, 연못이 이어지면 다양한 새가 살 곳을 얻어요. 습지를 살필 때는 한 연못뿐 아니라 서로 연결된 물길 전체를 생각해야 해요.

탐험 키워드: 다카르 · 주지 조류 보호 구역 · 세네갈강 · 삼각주 · 펠리컨 · 왜가리 · 호수 · 연못 · 습지 · 레트바 호수

엽서 장면: 레트바 호수

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sn/
- https://whc.unesco.org/en/list/25/

## 세르비아 · RS

수도·정부 소재지: 베오그라드

1. 세르비아는 유럽에 있어요. 수도는 베오그라드예요.

2. 스투데니차 수도원은 12세기 말에 세워졌어요. 흰 대리석으로 지은 두 주요 교회는 오래된 건축 재료와 모양을 배울 수 있는 유산이에요.

3. 교회 안에는 13~14세기의 비잔틴 회화가 남아 있어요. 건물과 그림을 함께 보면, 예술이 신앙과 당시 사람들의 생각을 어떻게 표현했는지 배울 수 있어요.

탐험 키워드: 베오그라드 · 스투데니차 수도원 · 흰 대리석 · 12세기 · 비잔틴 회화 · 옛 교회 · 건축 재료 · 중세 예술 · 신앙과 예술 · 베오그라드 칼레메그단 요새

엽서 장면: 베오그라드 칼레메그단 요새

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rs/
- https://whc.unesco.org/en/list/389/

## 세이셸 · SC

수도·정부 소재지: 빅토리아

1. 세이셸은 아프리카에 있어요. 수도는 빅토리아예요.

2. 프랄린섬의 발레드메에는 자연 상태를 잘 간직한 야자수 숲이 있어요. 코코드메르 야자나무는 식물의 세계에서 아주 큰 씨앗으로 알려져 있어요.

3. 씨앗은 새로운 식물이 자라는 출발점이에요. 발레드메의 야자수와 씨앗을 비교하며, 식물마다 번식하고 자라는 방식이 다르다는 걸 배울 수 있어요.

탐험 키워드: 빅토리아 · 발레드메 · 프랄린섬 · 코코드메르 · 야자수 숲 · 씨앗 · 식물의 번식 · 나무의 성장 · 자연림 · 숲 보호

엽서 장면: 발레드메 야자수 숲

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sc/
- https://whc.unesco.org/en/list/261/

## 시에라리온 · SL

수도·정부 소재지: 프리타운

1. 시에라리온은 아프리카에 있어요. 수도는 프리타운예요.

2. 골라·티와이 지역에는 열대림과 모아강의 섬이 함께 있어요. 숲과 강을 이어서 보호하면 서로 다른 서식지를 오가는 생물을 도울 수 있어요.

3. 이 지역에는 피그미하마와 침팬지 같은 보호가 필요한 동물이 살아요. 동물의 이름을 외우는 데서 나아가, 숲과 물이 왜 필요한지도 생각해 보세요.

탐험 키워드: 프리타운 · 골라·티와이 · 모아강 · 강의 섬 · 열대림 · 피그미하마 · 침팬지 · 서식지 연결 · 야생동물 보호 · 타쿠가마 침팬지

엽서 장면: 타쿠가마 침팬지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sl/
- https://whc.unesco.org/en/list/1746/

## 싱가포르 · SG

수도·정부 소재지: 싱가포르

1. 싱가포르는 나라 이름과 수도 이름이 같은 도시 국가예요. 머라이언은 사자 머리와 물고기 몸을 가진 상징이에요.

2. 싱가포르 식물원에는 다양한 식물과 난초가 자라요. 이 식물원은 유네스코 세계유산이에요.

3. 호커 센터는 여러 음식 가게가 모여 있는 곳이에요. 치킨라이스처럼 다양한 문화의 음식을 만날 수 있어요.

탐험 키워드: 싱가포르 · 머라이언 · 마리나 베이 · 싱가포르강 · 싱가포르 식물원 · 난초 · 가든스 바이 더 베이 · 호커 센터 · 치킨라이스 · 리틀 인디아

엽서 장면: 가든스 바이 더 베이 슈퍼트리

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sg/
- https://www.visitsingapore.com/see-do-singapore/recreation-leisure/viewpoints/merlion-park/
- https://www.visitsingapore.com/things-to-do/top-things-to-do/city-in-nature/
- https://www.visitsingapore.com/content/visitsingapore/en/travel-tips/travelling-to-singapore/itineraries/singapore-city-tour-guide/

## 슬로바키아 · SK

수도·정부 소재지: 브라티슬라바

1. 슬로바키아는 유럽에 있어요. 수도는 브라티슬라바예요.

2. 스피시성 주변에는 중세의 방어 시설과 종교 건축물이 남아 있어요. 로마네스크와 고딕 양식의 건물을 비교하며 유럽 건축의 변화를 배울 수 있어요.

3. 가까운 레보차에는 성벽으로 둘러싸인 옛 도시와 성 야고보 교회가 있어요. 교회의 색칠한 조각 작품은 건물 안에서도 여러 예술을 만날 수 있음을 보여줘요.

탐험 키워드: 브라티슬라바 · 스피시성 · 레보차 · 성 야고보 교회 · 로마네스크 · 고딕 · 중세 · 방어 시설 · 색칠한 조각 · 성벽 도시

엽서 장면: 스피시성

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sk/
- https://whc.unesco.org/en/list/620/

## 슬로베니아 · SI

수도·정부 소재지: 류블랴나

1. 슬로베니아는 유럽에 있어요. 수도는 류블랴나예요.

2. 슈코치안 동굴에는 석회암 속의 긴 통로와 지하 폭포가 있어요. 물이 돌을 녹이고 깎아 지형을 바꾸는 카르스트 현상을 배우는 곳이에요.

3. 동굴 지붕이 무너지면 땅 위에 움푹한 지형이 생길 수 있어요. 지상과 지하를 함께 살피면 우리가 딛는 땅 아래에도 이어진 공간이 있음을 알 수 있어요.

탐험 키워드: 류블랴나 · 슈코치안 동굴 · 석회암 · 카르스트 · 지하 통로 · 지하 폭포 · 돌의 용해 · 침식 · 함몰 지형 · 지하 공간

엽서 장면: 슈코치안 동굴

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/si/
- https://whc.unesco.org/en/list/390/

## 솔로몬 제도 · SB

수도·정부 소재지: 호니아라

1. 솔로몬 제도는 오세아니아에 있어요. 수도는 호니아라예요.

2. 렌넬섬의 테가노호는 옛 석호가 땅의 변화로 호수가 된 곳이에요. 산호로 만들어진 지형이 바다 위로 올라오며 풍경이 달라질 수 있어요.

3. 호수에는 짠물과 민물이 섞인 물, 석회암 섬과 독특한 생물이 있어요. 섬의 숲과 호수를 함께 살피면 땅의 역사와 생태계를 연결할 수 있어요.

탐험 키워드: 호니아라 · 렌넬섬 · 테가노호 · 옛 석호 · 융기한 환초 · 기수 · 석회암 섬 · 섬의 숲 · 고유종 · 마로보 석호

엽서 장면: 마로보 석호

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sb/
- https://whc.unesco.org/en/list/854/

## 소말리아 · SO

수도·정부 소재지: 모가디슈

1. 소말리아는 아프리카에 있어요. 수도는 모가디슈예요.

2. 모가디슈는 인도양 무역으로 여러 지역과 연결되었던 해안 도시예요. 오래된 도시의 건물은 바다를 오가던 사람들과 문화의 만남을 알려줘요.

3. 모가디슈의 세콘도리도 등대는 배가 해안을 살피도록 돕던 시설이에요. 등대를 통해 건축물이 아름다운 모습과 실용적인 역할을 함께 가질 수 있음을 배워요.

탐험 키워드: 모가디슈 · 인도양 무역 · 해안 도시 · 세콘도리도 등대 · 항해 · 옛 항구 · 문화의 만남 · 도시의 건물 · 바닷길 · 모가디슈의 오래된 해안 도시

엽서 장면: 모가디슈의 오래된 해안 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/tentativelists/6754/

## 남아프리카공화국 · ZA

수도·정부 소재지: 프리토리아

프리토리아는 행정 수도, 케이프타운은 입법 수도, 블룸폰테인은 사법 수도예요.

1. 남아프리카공화국은 수도 기능이 세 도시에 나뉘어요. 프리토리아는 행정, 케이프타운은 의회, 블룸폰테인은 사법 기능을 맡아요.

2. 케이프타운 옆에는 꼭대기가 평평한 테이블산이 솟아 있어요.

3. 넬슨 만델라는 인종 차별에 맞서 민주주의를 위해 일했고, 1994년에 남아프리카공화국의 첫 흑인 대통령이 되었어요.

탐험 키워드: 프리토리아 · 케이프타운 · 테이블산 · 크루거 국립공원 · 로벤섬 · 아프리카펭귄 · 스프링복 · 넬슨 만델라 · 루이보스차 · 남아프리카 수어

엽서 장면: 테이블산과 케이프타운

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 남수단 · SS

수도·정부 소재지: 주바

1. 남수단은 아프리카에 있어요. 수도는 주바예요.

2. 남수단의 수드 습지는 백나일강을 따라 펼쳐져 있어요. 강물과 풀밭이 넓게 이어지는 자연 경관이에요.

3. 수드에는 파피루스와 갈대 같은 습지 식물이 자라요. 물이 퍼지는 곳과 식물이 많은 곳이 어우러져요.

탐험 키워드: 주바 · 아프리카 · 수드 습지 · 백나일강 · 파피루스 · 갈대 · 습지 생태계 · 수생식물 · 서식지 · 물과 식물

엽서 장면: 백나일강의 수드 습지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ss/
- https://whc.unesco.org/en/tentativelists/6276/

## 스페인 · ES

수도·정부 소재지: 마드리드

1. 스페인의 수도는 마드리드예요. 사그라다 파밀리아는 바르셀로나에 있는 안토니 가우디의 성당이에요.

2. 사그라다 파밀리아 안의 기둥은 나무줄기와 가지처럼 갈라져요. 가우디는 자연의 모양을 살피며 건물의 무게를 받치는 구조를 만들었어요.

3. 스페인 여러 지역에서는 스페인어와 함께 카탈루냐어, 바스크어, 갈리시아어도 쓰여요.

탐험 키워드: 마드리드 · 사그라다 파밀리아 · 바르셀로나 · 피레네산맥 · 지중해 · 플라멩코 · 파에야 · 올리브 · 카탈루냐어 · 갈리시아어

엽서 장면: 사그라다 파밀리아

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://blog.sagradafamilia.org/en/columns-sagrada-familia-geometry-mechanics-materials-stone-forest/

## 스리랑카 · LK

수도·정부 소재지: 스리자야와르데네푸라코테

스리자야와르데네푸라코테에는 의회가 있고, 콜롬보에는 많은 정부 기관이 있어요.

1. 스리자야와르데네푸라코테에는 의회가 있고, 콜롬보에는 많은 정부 기관이 있어요.

2. 시기리야는 약 180m 높이의 화강암 바위 위에 세운 옛 도시의 유적이에요. 높은 지형을 어떻게 건축에 활용했는지 보여줘요.

3. 유적으로 올라가는 길에는 커다란 사자 모양 건축물의 흔적과 계단이 있어요. 바위와 벽돌, 석고를 함께 사용한 모습을 보며 자연과 건축의 만남을 배워요.

탐험 키워드: 스리자야와르데네푸라코테 · 시기리야 · 화강암 · 사자 바위 · 옛 도시 · 높은 지형 · 계단 · 벽돌 · 석고 · 자연과 건축

엽서 장면: 시기리야

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lk/
- https://www.gov.lk/sri-lanka/country-overview
- https://whc.unesco.org/en/list/202/

## 수단 · SD

수도·정부 소재지: 하르툼

1. 수단은 아프리카에 있어요. 수도는 하르툼예요.

2. 메로에는 옛 쿠시 왕국의 중심지였어요. 피라미드와 사원, 집터는 나일강 주변에 이집트뿐 아니라 여러 문명이 있었음을 알려줘요.

3. 메로에 주변 유적에는 물을 관리하던 시설의 흔적도 있어요. 건조한 지역에서 도시가 자라려면 물을 모으고 사용하는 기술이 중요했어요.

탐험 키워드: 하르툼 · 메로에 · 쿠시 왕국 · 피라미드 · 나일강 · 아트바라강 · 옛 사원 · 집터 · 물 관리 · 건조 지역

엽서 장면: 메로에의 피라미드

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sd/
- https://whc.unesco.org/en/list/1336/

## 수리남 · SR

수도·정부 소재지: 파라마리보

1. 수리남은 아메리카에 있어요. 수도는 파라마리보예요.

2. 파라마리보의 역사 지구에는 네덜란드 건축의 영향과 현지 재료·기술이 함께 나타나요. 같은 양식도 지역의 환경과 장인에 따라 다른 모습이 될 수 있어요.

3. 파라마리보에는 17~18세기 도시에서 이어진 거리의 배치가 남아 있어요. 건물 하나뿐 아니라 길과 도시 전체도 역사 자료가 될 수 있어요.

탐험 키워드: 파라마리보 · 파라마리보 역사 지구 · 현지 재료 · 건축 기술 · 네덜란드 건축 · 장인 · 거리 배치 · 17~18세기 · 도시의 역사 · 문화의 만남

엽서 장면: 파라마리보

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sr/
- https://whc.unesco.org/en/list/940/

## 스웨덴 · SE

수도·정부 소재지: 스톡홀름

1. 스웨덴의 수도 스톡홀름은 여러 섬과 다리 위에 펼쳐진 도시예요.

2. 스웨덴 북쪽에서는 여름에 해가 아주 늦게 지고, 겨울에는 오로라를 볼 수 있어요.

3. 스톡홀름의 바사 박물관에는 1600년대에 만들어진 커다란 배가 전시되어 있어요.

탐험 키워드: 스톡홀름 · 감라스탄 · 바사호 · 오로라 · 숲 · 무스 · 계피빵 · 미트볼 · 스웨덴어 · 달라 말

엽서 장면: 스톡홀름 감라스탄

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 스위스 · CH

수도·정부 소재지: 베른

베른은 스위스의 연방도시로, 연방 정부가 있는 곳이에요.

1. 베른은 스위스 정부가 있는 연방도시예요. 보통 수도처럼 소개하지만, 공식 명칭인 연방도시도 함께 알아두어요.

2. 스위스에는 알프스산맥, 쥐라산맥, 그 사이의 고원 지대가 있어요. 산악 철도로 높은 곳까지 오를 수도 있어요.

3. 스위스의 국가 언어는 독일어·프랑스어·이탈리아어·로만슈어 네 가지예요. 지역마다 사용하는 언어가 달라요.

탐험 키워드: 베른 · 연방도시 · 알프스산맥 · 쥐라산맥 · 스위스 고원 · 산악 철도 · 독일어 · 프랑스어 · 이탈리아어 · 로만슈어

엽서 장면: 베른 치트글로게 시계탑

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ch/
- https://www.aboutswitzerland.eda.admin.ch/en/political-system
- https://www.aboutswitzerland.eda.admin.ch/en/geography
- https://www.aboutswitzerland.eda.admin.ch/en/languages-and-dialects

## 시리아 · SY

수도·정부 소재지: 다마스쿠스

1. 시리아는 아시아에 있어요. 수도는 다마스쿠스예요.

2. 보스라에는 2세기 로마 시대의 큰 극장이 남아 있어요. 둥글게 이어진 좌석을 살피며 사람들이 공연을 함께 보던 공간을 상상할 수 있어요.

3. 보스라는 메카로 향하던 옛 대상들의 길에서 중요한 정류장이었어요. 극장과 종교 건축물은 여러 시대의 사람과 문화가 이 도시를 지나갔음을 알려줘요.

탐험 키워드: 다마스쿠스 · 보스라 · 로마 극장 · 2세기 · 곡선 좌석 · 공연 · 대상 무역 · 메카 · 종교 건축 · 보스라 고대 도시

엽서 장면: 보스라 고대 도시

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sy/
- https://whc.unesco.org/en/list/22/

## 대만 · TW

수도·정부 소재지: 타이베이

1. 대만은 아시아에 있어요. 수도는 타이베이예요.

2. 타이베이 101에는 바람에 따른 건물의 흔들림을 줄이는 큰 추 장치가 있어요. 동조질량댐퍼라고 부르며, 높은 건물을 편안하게 사용하는 데 도움을 줘요.

3. 전망대에서는 타이베이의 강과 분지, 주변 산을 볼 수 있어요. 높은 곳에서 도시를 살피면 건물의 위치와 강, 산의 관계를 한눈에 생각해 볼 수 있어요.

탐험 키워드: 타이베이 · 타이베이 101 · 동조질량댐퍼 · 흔들림 줄이기 · 바람 · 높은 건물 · 전망대 · 타이베이 분지 · 도시의 강 · 주변 산

엽서 장면: 타이베이 101과 타이베이 분지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.taipei-101.com.tw/en/observatory/feature
- https://www.taipei-101.com.tw/en/observatory/feature/damper

## 타지키스탄 · TJ

수도·정부 소재지: 두샨베

1. 타지키스탄은 아시아에 있어요. 수도는 두샨베예요.

2. 파미르의 타지크 국립공원에는 높은 봉우리와 고원, 많은 빙하가 있어요. 산의 높이와 계절에 따라 온도가 크게 달라지는 환경을 배울 수 있어요.

3. 공원에는 빙하와 강, 호수가 함께 있어요. 눈과 얼음이 모였다 녹아 물길로 이어지는 모습을 생각하며 산과 물의 관계를 배워 보세요.

탐험 키워드: 두샨베 · 파미르 · 타지크 국립공원 · 고원 · 빙하 · 높은 봉우리 · 계절의 온도 · 강 · 산의 호수 · 이스칸데르쿨 호수

엽서 장면: 이스칸데르쿨 호수

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tj/
- https://whc.unesco.org/en/list/1252/

## 탄자니아 · TZ

수도·정부 소재지: 도도마

1. 탄자니아의 수도 도도마는 나라의 가운데쯤에 있어요.

2. 킬리만자로산은 아프리카에서 가장 높은 산이에요.

3. 탄자니아 북부 세렝게티에서는 많은 동물들이 초원을 오가며 살아가요.

탐험 키워드: 도도마 · 킬리만자로산 · 세렝게티 · 사바나 · 바오밥나무 · 코끼리 · 스와힐리어 · 잔지바르 · 우갈리 · 커피

엽서 장면: 킬리만자로산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 태국 · TH

수도·정부 소재지: 방콕

1. 태국의 수도 방콕에는 화려한 왕궁과 차오프라야강이 있어요.

2. 태국은 북쪽의 산과 숲부터 남쪽의 따뜻한 바다까지 풍경이 다양해요.

3. 송크란은 태국의 새해를 맞아 가족과 이웃이 함께 축하하는 축제예요.

탐험 키워드: 방콕 · 왕궁 · 차오프라야강 · 치앙마이 · 아시아코끼리 · 팟타이 · 망고 찹쌀밥 · 툭툭 · 태국어 · 송크란

엽서 장면: 왕궁

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 동티모르 · TL

수도·정부 소재지: 딜리

1. 동티모르는 아시아에 있어요. 수도는 딜리예요.

2. 동티모르의 타이스는 손으로 짠 전통 천이에요. 식물로 물들인 목화를 준비하고 실을 엮는 과정에 오랜 시간과 기술이 들어가요.

3. 타이스의 색과 무늬는 공동체마다 다르며 옷과 의식, 축제에 사용돼요. 천의 무늬를 살피면 사람들의 문화가 생활 속 물건에 담기는 모습을 배울 수 있어요.

탐험 키워드: 딜리 · 타이스 · 손으로 짜기 · 목화 · 식물 염료 · 천의 무늬 · 색 · 전통 옷 · 축제 · 딜리와 크리스투 레이 언덕

엽서 장면: 딜리와 크리스투 레이 언덕

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/USL/tais-traditional-textile-01688

## 토고 · TG

수도·정부 소재지: 로메

1. 토고는 아프리카에 있어요. 수도는 로메예요.

2. 쿠타마쿠의 바탐마리바 사람들은 탑처럼 생긴 흙집인 타키엔타를 지어 왔어요. 집의 모양은 건축 기술뿐 아니라 공동체의 생활 방식을 보여줘요.

3. 이 지역의 마을에는 밭과 숲, 샘과 의식을 치르는 장소가 함께 있어요. 집만 보는 대신 주변 땅과 생활을 연결하면 문화 경관의 뜻을 배울 수 있어요.

탐험 키워드: 로메 · 쿠타마쿠 · 바탐마리바 · 타키엔타 · 흙집 · 탑 모양 집 · 밭 · 샘 · 의식 장소 · 문화 경관

엽서 장면: 쿠타마쿠의 바탐마리바 흙집

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tg/
- https://whc.unesco.org/en/list/1140/

## 통가 · TO

수도·정부 소재지: 누쿠알로파

1. 통가는 오세아니아에 있어요. 수도는 누쿠알로파예요.

2. 통가타푸섬의 하아몽가 아 마우이는 커다란 돌 세 개로 만든 옛 관문이에요. 두 돌기둥 위에 가로 돌을 올린 모습을 살피며 구조와 균형을 생각해 보세요.

3. 통가의 문화에는 전통 춤과 오래된 왕실의 유산도 있어요. 돌로 남은 유적뿐 아니라, 사람들이 이어 가는 춤과 공연에서도 역사를 배울 수 있어요.

탐험 키워드: 누쿠알로파 · 하아몽가 아 마우이 · 통가타푸섬 · 돌 관문 · 세 개의 돌 · 기둥 · 가로 돌 · 균형 · 전통 춤 · 왕실 유산

엽서 장면: 하아몽가 아 마우이

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thekingdomoftonga.com/true-culture/

## 트리니다드 토바고 · TT

수도·정부 소재지: 포트오브스페인

1. 트리니다드 토바고는 아메리카에 있어요. 수도는 포트오브스페인예요.

2. 트리니다드 토바고에서 발달한 스틸팬은 금속으로 만든 타악기예요. 표면의 여러 부분을 두드리면 서로 다른 높이의 소리가 나요.

3. 스틸팬은 1930~1940년대에 발전했으며 이 나라의 국악기예요. 생활 속 금속통을 악기로 바꾸어 온 역사에서 음악과 창의적인 만들기의 만남을 배울 수 있어요.

탐험 키워드: 포트오브스페인 · 스틸팬 · 타악기 · 금속 · 음의 높이 · 진동 · 국악기 · 1930~1940년대 · 악기 만들기 · 트리니다드 카니발

엽서 장면: 트리니다드 카니발

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://foreign.gov.tt/about/trinidad-tobago/national-symbols/national-instrument/

## 튀니지 · TN

수도·정부 소재지: 튀니스

1. 튀니지는 아프리카에 있어요. 수도는 튀니스예요.

2. 카르타고는 튀니스만에 세워진 옛 도시로, 지중해 무역의 중심지로 자랐어요. 항구 도시가 바닷길을 통해 먼 지역과 연결되는 역사를 보여줘요.

3. 옛 카르타고가 무너진 뒤 같은 자리에 로마 시대의 도시가 다시 세워졌어요. 한 장소의 여러 유적을 비교하면 도시가 사라지고 다시 자란 시간을 읽을 수 있어요.

탐험 키워드: 튀니스 · 카르타고 · 튀니스만 · 지중해 무역 · 항구 도시 · 바닷길 · 로마 시대 · 도시 재건 · 유적 비교 · 고고학

엽서 장면: 카르타고

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tn/
- https://whc.unesco.org/en/list/37/

## 튀르키예 · TR

수도·정부 소재지: 앙카라

1. 튀르키예의 수도는 앙카라예요. 이스탄불은 보스포루스 해협을 사이에 두고 유럽과 아시아에 걸쳐 있어요.

2. 이스탄불의 아야 소피아는 여러 시대에 걸쳐 쓰인 오래된 건축물이에요.

3. 튀르키예에는 바닷가와 높은 산, 카파도키아의 독특한 바위 지형이 있어요.

탐험 키워드: 앙카라 · 이스탄불 · 아야 소피아 · 보스포루스 해협 · 카파도키아 · 튀르키예어 · 시미트 · 바클라바 · 차 · 지중해

엽서 장면: 아야 소피아와 블루 모스크

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 투르크메니스탄 · TM

수도·정부 소재지: 아시가바트

1. 투르크메니스탄은 아시아에 있어요. 수도는 아시가바트예요.

2. 메르브는 중앙아시아 실크로드의 오아시스 도시였어요. 건조한 지역의 물과 길이 만나는 곳에서 사람들이 머무르고 물건을 교환했어요.

3. 메르브에는 오랜 세월에 걸친 도시의 흔적이 남아 있어요. 성벽과 건물의 자리를 살피면 같은 오아시스에서 도시가 여러 번 변화한 역사를 배울 수 있어요.

탐험 키워드: 아시가바트 · 메르브 · 실크로드 · 오아시스 · 중앙아시아 · 건조 지역 · 옛 성벽 · 무역 · 도시의 흔적 · 고대 메르브

엽서 장면: 고대 메르브

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tm/
- https://whc.unesco.org/en/list/886/

## 투발루 · TV

수도·정부 소재지: 푸나푸티

수도 푸나푸티는 여러 섬으로 이루어진 환초예요. 핀은 정부 기관이 있는 퐁가팔레섬의 바이아쿠를 표시해요.

1. 수도 푸나푸티는 여러 섬으로 이루어진 환초예요. 핀은 정부 기관이 있는 퐁가팔레섬의 바이아쿠를 표시해요.

2. 투발루는 태평양의 낮은 산호섬 아홉 개로 이루어져 있어요. 여러 섬에는 산호초로 둘러싸인 석호가 있어, 섬과 바다의 관계를 배울 수 있어요.

3. 석호는 바다와 이어진 해안의 물 공간이에요. 낮은 섬의 생활을 살피며 해안과 산호초를 돌보고, 기후 변화에 함께 대비하는 일이 왜 필요한지 생각해 보세요.

탐험 키워드: 푸나푸티 · 산호섬 · 석호 · 산호초 · 태평양 · 낮은 지대 · 섬과 바다 · 해안 보호 · 기후 변화 · 푸나푸티 보호 구역

엽서 장면: 푸나푸티 보호 구역

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://finance.gov.tv/contact-us/
- https://finance.gov.tv/wp-content/uploads/2023/11/181024-TvICT-ESMP-Rev-G-2.pdf
- https://thecommonwealth.org/our-member-countries/tuvalu

## 우간다 · UG

수도·정부 소재지: 캄팔라

1. 우간다는 아프리카에 있어요. 수도는 캄팔라예요.

2. 브윈디 국립공원은 평지의 숲과 산의 숲이 만나는 지역에 있어요. 많은 나무와 양치식물, 새와 나비가 서로 다른 환경에서 살아가요.

3. 브윈디는 멸종 위험에 놓인 마운틴고릴라의 서식지이기도 해요. 동물만 따로 보호하는 대신 먹이와 보금자리가 있는 숲을 함께 지키는 일이 중요해요.

탐험 키워드: 캄팔라 · 브윈디 국립공원 · 마운틴고릴라 · 평지 숲 · 산지 숲 · 양치식물 · 나비 · 새 · 멸종 위험 · 브윈디 원시림 국립공원

엽서 장면: 브윈디 원시림 국립공원

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ug/
- https://whc.unesco.org/en/list/682/

## 우크라이나 · UA

수도·정부 소재지: 키이우

1. 우크라이나는 유럽에 있어요. 수도는 키이우예요.

2. 키이우의 성 소피아 대성당은 11세기 도시의 역사를 보여주는 건축물이에요. 콘스탄티노폴리스의 성당과 관련된 구상에서 다른 도시 사이의 문화 연결을 배울 수 있어요.

3. 키이우 페체르스크 라브라는 종교와 배움에 영향을 준 오랜 수도원이에요. 대성당과 수도원을 함께 살피면 같은 도시에서도 건물마다 다른 역할이 있음을 배워요.

탐험 키워드: 키이우 · 성 소피아 대성당 · 키이우 페체르스크 라브라 · 11세기 · 콘스탄티노폴리스 · 문화의 연결 · 수도원 · 종교 건축 · 배움의 역사 · 건물의 역할

엽서 장면: 키이우 성 소피아 대성당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ua/
- https://whc.unesco.org/en/list/527/

## 아랍에미리트 · AE

수도·정부 소재지: 아부다비

1. 아랍에미리트는 일곱 토후국이 함께 이루는 나라예요. 수도는 아부다비이고, 두바이는 다른 토후국의 도시예요.

2. 아부다비에는 셰이크 자이드 대모스크가 있고, 두바이에는 높은 부르즈 할리파가 있어요.

3. 아랍에미리트에는 사막과 바다에 닿는 해안이 함께 있어요. 알아인에서는 오아시스와 오래된 문화 유적을 볼 수 있어요.

탐험 키워드: 아부다비 · 두바이 · 일곱 토후국 · 셰이크 자이드 대모스크 · 부르즈 할리파 · 알아인 오아시스 · 아라비아반도 · 사막 · 해안 · 아랍어

엽서 장면: 알아인 오아시스와 팔라지 수로

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ae/
- https://u.ae/en/about-the-uae/fact-sheet
- https://u.ae/en/about-the-uae/the-seven-emirates

## 영국 · GB

수도·정부 소재지: 런던

1. 영국의 수도는 런던이에요. 런던의 엘리자베스 타워 안에 있는 종을 빅벤이라고 불러요.

2. 영국은 잉글랜드, 스코틀랜드, 웨일스, 북아일랜드로 이루어져 있어요.

3. 템스강이 런던을 지나고, 빨간 2층 버스도 도시의 익숙한 모습이에요.

탐험 키워드: 런던 · 빅벤 · 템스강 · 잉글랜드 · 스코틀랜드 · 웨일스 · 북아일랜드 · 2층 버스 · 영어 · 피시 앤드 칩스

엽서 장면: 엘리자베스 타워와 국회의사당

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 미국 · US

수도·정부 소재지: 워싱턴 D.C.

1. 미국의 수도는 워싱턴 D.C.이고, 미국은 50개 주로 이루어져 있어요.

2. 큰바위얼굴은 사우스다코타주의 산에 조각된 네 명의 대통령 얼굴이에요.

3. 미국에는 그랜드캐니언, 미시시피강, 하와이섬처럼 다양한 자연 풍경이 있어요.

탐험 키워드: 워싱턴 D.C. · 큰바위얼굴 · 그랜드캐니언 · 미시시피강 · 알래스카 · 하와이 · 50개 주 · 재즈 · 야구 · 햄버거

엽서 장면: 큰바위얼굴

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 우루과이 · UY

수도·정부 소재지: 몬테비데오

1. 우루과이의 수도는 몬테비데오예요. 도시는 넓은 강 하구인 라플라타강을 따라 자리해요.

2. 몬테비데오의 람블라는 물가를 따라 이어지는 길이에요. 산책하거나 자전거를 타며 도시의 해안 풍경을 볼 수 있어요.

3. 칸돔베는 아프리카계 공동체의 역사와 이어진 북 음악과 춤이에요. 몬테비데오 여러 동네에서 전통을 이어가요.

탐험 키워드: 몬테비데오 · 라플라타강 · 람블라 · 칸돔베 · 북 · 수르 지구 · 팔레르모 지구 · 코르돈 지구 · 강 하구 · 스페인어

엽서 장면: 몬테비데오 해안

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uy/
- https://montevideo.gub.uy/areas-tematicas/amiga-del-futbol/descubri-montevideo
- https://www.montevideo.gub.uy/areas-tematicas/cultura-y-tiempo-libre/parques/rambla
- https://ich.unesco.org/en/RL/candombe-and-its-socio-cultural-space-a-community-practice-00182

## 우즈베키스탄 · UZ

수도·정부 소재지: 타슈켄트

1. 우즈베키스탄의 수도는 타슈켄트예요. 사마르칸트와 부하라는 실크로드를 따라 여러 문화가 만났던 도시예요.

2. 사마르칸트에는 오래된 모스크와 큰 광장이 있어요. 건물의 푸른 타일 장식을 살펴볼 수 있어요.

3. 팔로브는 쌀을 중심으로 만든 음식이에요. 손님과 이웃이 함께 나누어 먹는 전통도 이어지고 있어요.

탐험 키워드: 타슈켄트 · 사마르칸트 · 부하라 · 이찬칼라 · 실크로드 · 레기스탄 광장 · 푸른 타일 · 팔로브 · 오아시스 · 우즈베크어

엽서 장면: 사마르칸트 레기스탄

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uz/
- https://whc.unesco.org/en/list/603/
- https://ich.unesco.org/en/RL/palov-culture-and-tradition-01166

## 바누아투 · VU

수도·정부 소재지: 포트빌라

1. 바누아투는 오세아니아에 있어요. 수도는 포트빌라예요.

2. 로이 마타 추장의 유산은 에파테와 렐레파, 아르토크섬에 남아 있어요. 지도자의 거처와 관련된 장소들이 여러 섬에 걸친 역사를 보여줘요.

3. 로이 마타 이야기는 입으로 전해진 전통과 고고학 자료를 함께 연구해요. 사람들의 기억과 땅에 남은 흔적을 비교하면 역사에 다가가는 방법도 다양해져요.

탐험 키워드: 포트빌라 · 로이 마타 추장 · 에파테섬 · 렐레파섬 · 아르토크섬 · 옛 거처 · 구전 전통 · 고고학 · 역사 자료 · 야수르 화산

엽서 장면: 야수르 화산

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/vu/
- https://whc.unesco.org/en/list/1280/

## 바티칸 · VA

수도·정부 소재지: 바티칸시국

1. 바티칸은 유럽에 있어요. 수도는 바티칸시국예요.

2. 바티칸에는 성 베드로 대성당과 광장, 궁전과 정원이 모여 있어요. 작은 국가 안에서도 건축과 미술의 오랜 역사를 살펴볼 수 있어요.

3. 대성당과 광장을 만드는 일에는 미켈란젤로와 베르니니 등 여러 예술가가 참여했어요. 하나의 큰 건축물도 여러 사람의 설계와 솜씨가 모여 만들어진다는 걸 배워요.

탐험 키워드: 바티칸시국 · 성 베드로 대성당 · 성 베드로 광장 · 미켈란젤로 · 베르니니 · 궁전 · 정원 · 열주 · 건축과 미술 · 예술가의 협력

엽서 장면: 바티칸시국

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/va/
- https://whc.unesco.org/en/list/286/

## 베네수엘라 · VE

수도·정부 소재지: 카라카스

1. 베네수엘라의 수도는 카라카스예요. 남아메리카 북쪽에 있으며 카리브해와 만나는 해안이 있어요.

2. 카나이마 국립공원에는 앙헬폭포가 있어요. 높은 절벽 위에서 물이 길게 떨어지는 폭포예요.

3. 카나이마에는 꼭대기가 평평한 테푸이 산들이 있어요. 특별한 지형과 다양한 생물을 세계유산으로 보호해요.

탐험 키워드: 카라카스 · 카나이마 국립공원 · 앙헬폭포 · 테푸이 · 아우얀테푸이 · 고원 · 폭포 · 절벽 · 카리브해 · 스페인어

엽서 장면: 앙헬 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ve/
- https://whc.unesco.org/en/list/701/
- https://whc.unesco.org/document/218578

## 베트남 · VN

수도·정부 소재지: 하노이

1. 베트남의 수도 하노이는 홍강 가까이에 있고, 호찌민시는 남쪽에 있어요.

2. 하롱베이에는 바다 위로 솟은 석회암 섬과 바위가 많아요.

3. 뗏은 베트남의 설날 축제로 가족들이 함께 모여 새해를 맞아요.

탐험 키워드: 하노이 · 하롱베이 · 홍강 · 메콩강 · 논 · 쌀국수 · 반미 · 베트남어 · 뗏 · 물인형극

엽서 장면: 하롱베이

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400

## 예멘 · YE

수도·정부 소재지: 사나

1. 예멘은 아시아에 있어요. 수도는 사나예요.

2. 사나 구시가지는 높은 산골짜기에 자리하고 오랫동안 사람들이 살아온 도시예요. 도시의 위치를 살피면 해안 도시와 다른 자연환경을 배울 수 있어요.

3. 사나에는 흙을 다져 만든 여러 층의 탑 모양 집들이 있어요. 가까이에서 얻은 재료를 큰 건축물에 활용한 모습은 옛 건축가들의 지혜를 보여줘요.

탐험 키워드: 사나 · 사나 구시가지 · 산골짜기 · 탑 모양 집 · 다진 흙 · 여러 층 · 현지 재료 · 옛 건축 · 도시의 위치 · 오래된 생활 터전

엽서 장면: 사나 구시가지

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ye/
- https://whc.unesco.org/en/list/385/

## 잠비아 · ZM

수도·정부 소재지: 루사카

1. 잠비아는 아프리카에 있어요. 수도는 루사카예요.

2. 빅토리아 폭포는 잠베지강이 현무암 협곡으로 떨어지는 곳이에요. 떨어지는 물의 힘과 깎인 바위를 보며 물이 지형을 바꾸는 작용을 배울 수 있어요.

3. 폭포에서 올라오는 물안개에는 햇빛에 따라 무지개가 나타나기도 해요. 잠비아와 짐바브웨가 함께 지키는 이 자연유산은 국경을 넘는 협력도 알려줘요.

탐험 키워드: 루사카 · 빅토리아 폭포 · 모시와툰야 · 잠베지강 · 현무암 · 협곡 · 물안개 · 무지개 · 침식 · 국경을 넘는 협력

엽서 장면: 빅토리아 폭포

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zm/
- https://whc.unesco.org/en/list/509/

## 짐바브웨 · ZW

수도·정부 소재지: 하라레

1. 짐바브웨는 아프리카에 있어요. 수도는 하라레예요.

2. 그레이트짐바브웨는 쇼나 문명의 옛 도시 유적이에요. 11~15세기에 번성한 무역 중심지의 흔적에서 아프리카 도시의 역사를 배울 수 있어요.

3. 유적의 커다란 돌벽은 옛 건축 기술을 보여줘요. 돌의 모양과 벽의 곡선을 관찰하며 사람들이 주변 재료로 큰 공간을 만든 방법을 생각해 보세요.

탐험 키워드: 하라레 · 그레이트짐바브웨 · 쇼나 문명 · 돌벽 · 11~15세기 · 무역 중심지 · 곡선 벽 · 건축 기술 · 현지 재료 · 아프리카 도시사

엽서 장면: 그레이트짐바브웨의 돌벽 유적

출처:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zw/
- https://whc.unesco.org/en/list/364/
