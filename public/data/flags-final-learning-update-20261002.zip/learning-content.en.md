# World explorer final learning edition · 199 places

197 countries + Greenland territory + Antarctica continent

## Afghanistan · AF

Capital / seat: Kabul

1. Afghanistan is in Asia. Its capital is Kabul.

2. The Minaret of Jam is a brick tower about 65 metres tall. Repeating brick patterns and blue tiles show the skill of its builders.

3. The tower stands in a mountain valley where the Hari Rud and Jam rivers meet. A place where rivers join is called a confluence.

4. Jam’s minaret has tapering cylindrical sections above an octagonal base. Comparing its base plan and side view introduces two-dimensional and three-dimensional forms.

5. Jam’s surroundings preserve traces of forts, towers and inscribed stones. Evidence beyond the prominent minaret gives a fuller picture of an earlier settlement.

Explorer words: Kabul · Minaret of Jam · Hari Rud River · Jam River · bricks · blue tiles · repeating patterns · mountain valley · confluence · 12th-century architecture

Postcard scene: Minaret and Archaeological Remains of Jam

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/af/
- https://whc.unesco.org/en/list/211/

## Albania · AL

Capital / seat: Tirana

1. Albania is in Europe. Its capital is Tirana.

2. Butrint preserves a theatre and building remains from Greek and Roman times. One place can reveal how people lived in different periods.

3. Butrint's hill is surrounded by a lake and the Vivari Channel. Its mosaics are pictures made from many small pieces.

4. Butrint preserves traces of a Roman aqueduct. Expanding a town required infrastructure for carrying water as well as new homes.

5. Model a Butrint floor mosaic with small coloured paper pieces. Each piece’s colour contributes to the image formed by the whole arrangement.

Explorer words: Tirana · Butrint · Lake Butrint · Vivari Channel · ancient theatre · mosaics · ancient Greece · Roman period · archaeology · wetlands

Postcard scene: Butrint

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/al/
- https://whc.unesco.org/en/list/570/

## Algeria · DZ

Capital / seat: Algiers

1. Algeria is in Africa. Its capital is Algiers.

2. The Kasbah is an old district of Algiers overlooking the Mediterranean. Its citadel, mosques and palaces tell the story of the city's streets.

3. The Kasbah is an example of a traditional town called a medina. The arrangement of homes and streets records the history of community life.

4. The Casbah of Algiers groups buildings along a hillside. A street plan together with an elevation sketch explains movement through a sloping town.

5. Colour the Casbah’s homes, markets and religious spaces differently. Urban life depends on connections between places serving several functions.

Explorer words: Algiers · Kasbah of Algiers · Mediterranean Sea · medina · citadel · mosques · palaces · historic streets · coastal city · community

Postcard scene: Kasbah of Algiers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dz/
- https://whc.unesco.org/en/list/565/

## Andorra · AD

Capital / seat: Andorra la Vella

1. Andorra is in Europe. Its capital is Andorra la Vella.

2. The Madriu-Perafita-Claror Valley lies in the Pyrenees. High pastures and wooded valleys show a landscape shaped by ancient glaciers.

3. Stone paths, terraced fields and summer homes remain in the valley. They reveal how people adapted to raising livestock in the mountains.

4. The Madriu Valley also preserves traces of ironworking. Its mountain history includes processing materials as well as herding and farming.

5. The valley preserves a tradition of communal land management. Consider the agreements needed when several communities use pasture and paths.

Explorer words: Andorra la Vella · Madriu Valley · Pyrenees · pastures · glaciers · stone paths · terraced fields · summer homes · pastoralism · Madriu-Perafita-Claror Valley

Postcard scene: Madriu-Perafita-Claror Valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ad/
- https://whc.unesco.org/en/list/1160/

## Angola · AO

Capital / seat: Luanda

1. Angola is in Africa. Its capital is Luanda.

2. Mbanza Kongo was the capital of the old Kingdom of Kongo. Royal residences and court sites show how this centre of government was organised.

3. The town stands on a plateau. Buildings made with local materials and later stone structures record encounters between different cultures.

4. Mbanza Kongo records encounters between Kongo traditions and Christianity. Earlier customs can continue alongside a newly introduced cultural tradition.

5. The Kingdom of Kongo’s history also connects with the Atlantic slave trade. Learning about this past includes recognising every person’s freedom and dignity.

Explorer words: Luanda · Mbanza Kongo · Kingdom of Kongo · plateau · royal residence · customary court · stone buildings · local materials · cultural exchange · archaeological remains

Postcard scene: Mbanza Kongo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ao/
- https://whc.unesco.org/en/list/1511/

## Antigua and Barbuda · AG

Capital / seat: Saint John's

1. Antigua and Barbuda is in Americas. Its capital is Saint John's.

2. English Harbour on Antigua is a deep, narrow bay surrounded by hills. This sheltered setting helped make it a place for repairing ships.

3. The old dockyard buildings preserve the history of ships and harbours. They also remind us of the enslaved Africans forced to help build them.

4. Antigua’s dockyard buildings include verandas and storm shutters adapted to local conditions. Architectural designs from elsewhere can change in response to climate.

5. Connect Antigua’s hillside defences with its waterfront dockyard. High and low locations served different roles within one harbour complex.

Explorer words: Saint John's · Antigua · Barbuda · English Harbour · Antigua Naval Dockyard · bay · harbour · ship repair · historic storehouses · history of labour

Postcard scene: Antigua Naval Dockyard

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ag/
- https://whc.unesco.org/en/list/1499/

## Argentina · AR

Capital / seat: Buenos Aires

1. Buenos Aires is Argentina’s capital. Its Obelisk stands on the wide Avenida 9 de Julio.

2. The Andes run along Argentina’s west, and Aconcagua is the highest mountain in the Americas.

3. Tango is a style of dance and music that grew around the Río de la Plata region, including Buenos Aires.

4. Iguazú Falls lies in the border region of Argentina and Brazil. Connecting protected areas on both sides reveals a shared river and forest landscape.

5. Forests around Iguazú support animals such as tapirs, anteaters and monkeys. Considering food and shelter in the forest gives a fuller picture of the landscape.

Explorer words: Buenos Aires · Obelisk · Andes · Aconcagua · Patagonia · Iguazú Falls · tango · mate · Spanish · football

Postcard scene: Buenos Aires Obelisk & La Boca

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/303/

## Armenia · AM

Capital / seat: Yerevan

1. Armenia is in Asia. Its capital is Yerevan.

2. Echmiatsin's churches develop a design with a central dome. Comparing their shapes helps reveal changes in Armenian architecture.

3. Columns and foundations survive at Zvartnots. Archaeology studies such remains to help us understand buildings that no longer stand.

4. Four pillars support Echmiatsin Cathedral’s central dome. Parts that carry weight downwards are important alongside the visible shape of a roof.

5. The Echmiatsin and Zvartnots heritage property includes separate areas. Locate its components on a map to see how one property name can describe several places.

Explorer words: Yerevan · Echmiatsin · Zvartnots · cathedral · dome · columns · foundations · Armenian architecture · churches · archaeology

Postcard scene: Echmiatsin Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/am/
- https://whc.unesco.org/en/list/1011/

## Australia · AU

Capital / seat: Canberra

1. Canberra is Australia’s capital. The Sydney Opera House roof looks like sails or shells.

2. A huge reef off northeast Australia is home to corals and many sea creatures.

3. Australia is home to the ancient and diverse cultures of Aboriginal and Torres Strait Islander peoples.

4. Uluru and Kata Tjuta include a massive rock and groups of rounded rock formations. Comparing their outlines reveals different landforms within one rocky landscape.

5. This landscape has deep cultural importance for Anangu people. Learning about it includes listening to the community’s knowledge and treating meaningful places with respect.

Explorer words: Canberra · Sydney · Opera House · Great Barrier Reef · Uluru · kangaroo · koala · meat pie · First Nations cultures · cricket

Postcard scene: Sydney Opera House & Harbour Bridge

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/447/

## Austria · AT

Capital / seat: Vienna

1. Austria is in Europe. Its capital is Vienna.

2. Vienna has long been a city of composers and performers. Its historic buildings, as well as its concerts, tell a story of cultural life.

3. Vienna's Ringstrasse is lined with grand buildings and parks. Palaces, gardens and architecture from different periods stand together in the historic centre.

4. Map Vienna’s historic centre and Ringstrasse buildings. Studying urban growth shows how the relationship between centre and surroundings changes over time.

5. Explore Vienna’s musical theme by clapping a short rhythm slowly and quickly. Keeping the same pattern while changing tempo can change its character.

Explorer words: Vienna · historic Vienna · Ringstrasse · St Stephen's Cathedral · music · composers · palaces · gardens · Baroque architecture · city parks

Postcard scene: Historic Centre of Vienna — St Stephen's Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/at/
- https://whc.unesco.org/en/list/1033/

## Azerbaijan · AZ

Capital / seat: Baku

1. Azerbaijan is in Asia. Its capital is Baku.

2. Baku's walled city contains the Maiden Tower and Shirvanshahs' Palace. The stone tower and palace record the city's growth through different periods.

3. The old city, called Icheri Sheher, preserves historic defensive walls. Walls helped protect a town and organise the ways people entered it.

4. Baku’s old city preserves Islamic heritage alongside traces of earlier cultures. One period’s buildings cannot explain the whole history of a town.

5. Draw Baku’s walls and towers in plan and side view. Wall length and tower height measure size along different directions.

Explorer words: Baku · walled city of Baku · Maiden Tower · Shirvanshahs' Palace · Icheri Sheher · city walls · stone tower · old town · defensive architecture · cultural encounters

Postcard scene: Walled City of Baku — Maiden Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/az/
- https://whc.unesco.org/en/list/958/

## Bahamas · BS

Capital / seat: Nassau

1. Bahamas is in Americas. Its capital is Nassau.

2. Dean's Blue Hole is on Long Island in the Bahamas. Its deep coastal water appears a rich blue.

3. Low rock cliffs and a sandy beach border Dean's Blue Hole, beside turquoise shallow water.

4. Seawater does not transmit every light colour equally. Red light is absorbed more readily; sand and other local conditions also help explain sea colours around the Bahamas.

5. Draw Dean’s Blue Hole from above and in cross-section. Surface width and underwater depth are different measurements, so label them separately.

Explorer words: Nassau · Long Island · Dean's Blue Hole · Limestone shore · Sandy beach · Turquoise shallows · water depth · blue hole · colour contrast · coastal landforms

Postcard scene: Dean's Blue Hole, Long Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bahamas.com/natural-wonders/deans-blue-hole
- https://oceanservice.noaa.gov/facts/oceanblue.html

## Bahrain · BH

Capital / seat: Manama

1. Bahrain is in Asia. Its capital is Manama.

2. Layers left by generations of residents lie beneath Bahrain Fort. This kind of archaeological mound is called a tell, with different traces in each layer.

3. The area was a centre of the Dilmun civilisation and a trading port. Remains of homes, markets and religious buildings reveal trade and daily life.

4. Bahrain Fort’s archaeological area includes residential, commercial, public and religious remains. Different functions together reveal life in an earlier town.

5. Explore Dilmun trade by mapping production places separately from exchange places. A port can connect goods and everyday life across different regions.

Explorer words: Manama · Bahrain Fort · Dilmun civilisation · tell · archaeological layers · trading port · excavation · ancient house remains · markets · trade

Postcard scene: Qal’at al-Bahrain

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bh/
- https://whc.unesco.org/en/list/1192/

## Bangladesh · BD

Capital / seat: Dhaka

1. Bangladesh’s capital, Dhaka, is close to the Buriganga River.

2. Bangladesh lies in a broad delta shaped by the Ganges and Brahmaputra river systems.

3. The Sundarbans mangrove forest is home to many plants and animals, including Bengal tigers.

4. Sundarbans mangroves are adapted to environments affected by salt water. Observe the watery surroundings of their roots as well as the land when drawing the forest.

5. The Sundarbans includes tidal waterways, islands and mudflats. Mapping these environments together reveals varied living spaces within one forest landscape.

Explorer words: Dhaka · Lalbagh Fort · Buriganga River · Sundarbans · Bengal tiger · rickshaw art · Bangla · hilsa · Jamdani weaving · Padma Bridge

Postcard scene: Lalbagh Fort

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/798/

## Barbados · BB

Capital / seat: Bridgetown

1. Barbados is in Americas. Its capital is Bridgetown.

2. Bridgetown's old streets preserve buildings from the 17th to 19th centuries. Homes and public buildings record Atlantic trade and the colonial period.

3. Bridgetown's historic streets curve rather than following a straight grid. Street patterns show that towns can develop in different ways.

4. Bridgetown’s Garrison contains former military facilities. Distinguishing residential, commercial and defensive areas reveals several functions of a port town.

5. Trace a route between two points along Bridgetown’s winding streets. Straight-line distance can differ from the distance travelled along a real route.

Explorer words: Bridgetown · historic Bridgetown · historic garrison · Atlantic Ocean · curving streets · town planning · public buildings · historic houses · trade · colonial period

Postcard scene: Historic Bridgetown and its Garrison

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bb/
- https://whc.unesco.org/en/list/1376/

## Belarus · BY

Capital / seat: Minsk

1. Belarus is in Europe. Its capital is Minsk.

2. Mir Castle combines Gothic, Renaissance and Baroque work added over time. One building can show how walls and windows changed across different periods.

3. Mir Castle was later restored after damage and war. Its preservation, together with the surrounding park, passes architecture and history to future generations.

4. Towers occupy corners of Mir Castle. Drawing its outline and tower positions helps explore repetition and symmetry within a building arrangement.

5. Use colours to mark Mir Castle’s different architectural styles. Changes to an old building can leave earlier and later forms visible together.

Explorer words: Minsk · Mir Castle · Gothic style · Renaissance · Baroque style · castle towers · brick architecture · restoration · park · heritage conservation

Postcard scene: Mir Castle Complex

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/by/
- https://whc.unesco.org/en/list/625/

## Belgium · BE

Capital / seat: Brussels

1. Belgium is in Europe. Its capital is Brussels.

2. Brussels' Grand-Place is a square surrounded by historic buildings. Public buildings and merchants' houses reveal the life of the old city.

3. Buildings around the square largely preserve late-17th-century designs. Compare their roofs and facades to distinguish the buildings gathered around one square.

4. Grand-Place’s guild buildings connect with associations of craftspeople and merchants. Their history introduces ways in which people organised shared work.

5. Break a Grand-Place façade into small shapes. Repeated windows and roof forms help explain complex decoration through the relationships between its parts.

Explorer words: Brussels · Grand-Place · town square · town hall · merchants' houses · public buildings · facade · roof decorations · 17th century · urban life

Postcard scene: La Grand-Place, Brussels

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/be/
- https://whc.unesco.org/en/list/857/

## Belize · BZ

Capital / seat: Belmopan

1. Belize is in Americas. Its capital is Belmopan.

2. Belize's reef reserves include coral reefs, sandy islands and mangrove forests. Mangroves are trees that grow along shallow coastal waters.

3. The area provides important habitat for sea turtles and manatees. Protecting both reefs and coastal forests helps marine animals survive.

4. Belize’s reef reserve system includes atolls and a blue hole. Looking at coastlines alongside underwater terrain reveals marine spaces beyond the shore.

5. Belize’s manatees and sea turtles both live in water, but belong to different animal groups. Distinguish habitat information from classification as mammals or reptiles.

Explorer words: Belmopan · Belize Barrier Reef · coral · sand cays · mangroves · lagoon · sea turtles · manatee · habitat · marine ecosystem

Postcard scene: Belize Barrier Reef Reserve System

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bz/
- https://whc.unesco.org/en/list/764/

## Benin · BJ

Capital / seat: Porto-Novo

Porto-Novo is the official capital; many government offices are in Cotonou.

1. Porto-Novo is the official capital; many government offices are in Cotonou.

2. The Royal Palaces of Abomey were built by generations of rulers. Palaces within a shared enclosure record the history of the old kingdom.

3. Abomey's palaces used earthen walls and local materials. Building large structures with nearby resources is an important form of architectural knowledge.

4. Abomey’s palace walls include reliefs that communicate stories. Compare a flat drawing with raised sculpture to explore different artistic forms.

5. Represent Abomey’s palaces with a generational timeline and a plan. One shows when they were built; the other shows where they stand.

Explorer words: Porto-Novo · Royal Palaces of Abomey · historic kingdom · earthen walls · local materials · palaces · enclosure walls · building materials · royal history · cultural heritage

Postcard scene: Royal Palaces of Abomey

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bj/
- https://whc.unesco.org/en/list/323/

## Bhutan · BT

Capital / seat: Thimphu

1. Bhutan is in Asia. Its capital is Thimphu.

2. Tashichho Dzong stands beside the Wang Chhu River in Thimphu. Bhutan's fortress-like dzongs serve as centres of administration and religion.

3. Tashichho Dzong has white walls and decorated wooden windows. At the Thimphu Tshechu festival, masked dances and performances pass on traditional stories.

4. In Tashichho Dzong’s name, dzong refers to a type of fortified building in Bhutan. Distinguishing a place name from its building type helps compare different examples.

5. Masked dances at Thimphu Tshechu combine face imagery and movement. Explore expression beyond words by showing one feeling with a paper mask and a simple gesture.

Explorer words: Thimphu · Tashichho Dzong · Wang Chhu River · dzong · white walls · wooden windows · Thimphu Tshechu · masked dances · fortress architecture · Thimphu valley

Postcard scene: Thimphu valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thimphu.gov.bt/tashichho-dzong/

## Bolivia · BO

Capital / seat: Sucre

Sucre is the constitutional capital; La Paz is the seat of government and parliament.

1. Sucre is Bolivia’s constitutional capital. The government and parliament are in La Paz, so the two cities have different roles.

2. Sucre’s UNESCO-listed historic centre preserves white-walled buildings, squares and churches.

3. Tiwanaku preserves an ancient Andean civilisation, with stone buildings and carvings.

4. Sucre’s architecture combines local traditions with European influences. Comparing expressions within a building reveals traces of cultural exchange.

5. Sucre was formerly known as La Plata. Comparing past and present place names helps identify the same city in historical records.

Explorer words: Sucre · La Paz · constitutional capital · historic Sucre · Tiwanaku · Andes · Lake Titicaca · stone architecture · stone carvings · ancient civilisation

Postcard scene: City of Potosí

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bo/
- https://whc.unesco.org/en/list/566/
- https://whc.unesco.org/en/list/567/

## Bosnia and Herzegovina · BA

Capital / seat: Sarajevo

1. Bosnia and Herzegovina is in Europe. Its capital is Sarajevo.

2. Mostar's Old Bridge connects the banks of the Neretva River. Bridges provide important routes linking people across rivers and deep valleys.

3. The bridge was destroyed in war and rebuilt with international help. Its reconstruction also represents the possibility of different cultures living together.

4. Mostar’s arch spans an open space above the river. Draw the arch and its supports separately to explore the structure connecting both banks.

5. Mostar’s reconstruction drew on research into traditional methods. Restoring a monument involves studying surviving evidence and earlier forms as well as building anew.

Explorer words: Sarajevo · Mostar · Stari Most · Neretva River · stone bridge · arch · valley · reconstruction · historic houses · Old Bridge Area of the Old City of Mostar

Postcard scene: Old Bridge Area of the Old City of Mostar

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ba/
- https://whc.unesco.org/en/list/946/

## Botswana · BW

Capital / seat: Gaborone

1. Gaborone is Botswana’s capital. Botswana is a landlocked country in southern Africa.

2. The Okavango Delta is an inland wetland whose waters do not reach the sea. Floods arrive during the dry season and support many animals.

3. The Tsodilo Hills preserve ancient rock paintings and archaeological sites that tell the region’s long human history.

4. The Okavango includes permanent swamps and seasonally flooded grasslands. Comparing one picture with seasonal views reveals how a wetland changes through time.

5. The timing of Okavango flooding connects with living things’ cycles. A timeline of water, plants and animals helps explore linked natural processes.

Explorer words: Gaborone · Okavango Delta · Okavango River · wetlands · inland delta · Tsodilo · rock paintings · Kalahari · elephants · lions

Postcard scene: Okavango Delta

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bw/
- https://whc.unesco.org/en/list/1432/
- https://whc.unesco.org/en/list/1021/

## Brazil · BR

Capital / seat: Brasília

1. Brazil is the largest country in South America, and Brasília is its capital.

2. The Amazon rainforest is home to a huge variety of plants and animals.

3. Portuguese is spoken in Brazil, and Rio de Janeiro is known for its coast and mountains.

4. Brasília was planned through the arrangement of roads and urban areas. Its intersecting main axes, including a curved axis, reveal design at the scale of a whole city.

5. Lúcio Costa planned Brasília, while Oscar Niemeyer designed major buildings. Compare organising a city with designing one structure within it.

Explorer words: Brasília · Amazon · Rio de Janeiro · Christ the Redeemer · Atlantic Ocean · jaguar · Portuguese · samba · coffee · football

Postcard scene: Christ the Redeemer

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/445/

## Brunei · BN

Capital / seat: Bandar Seri Begawan

1. Brunei is in Asia. Its capital is Bandar Seri Begawan.

2. Kampong Ayer is a water village near the capital on the Brunei River. Homes stand on stilts and are connected by wooden paths and bridges.

3. Boats are important transport in Kampong Ayer. Its cultural gallery explains the history and everyday life of communities living beside the river.

4. Water passes beneath Kampong Ayer’s raised houses. Comparing them with land-based homes highlights the role of supports holding a floor above water.

5. Draw bridge routes and boat routes through the water village with different lines. The same destination can be reached along different paths depending on transport.

Explorer words: Bandar Seri Begawan · Kampong Ayer · Brunei River · water village · stilt houses · wooden bridges · boats · river life · cultural gallery · Bandar Seri Begawan riverfront

Postcard scene: Bandar Seri Begawan riverfront

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.bruneitourism.com/places/kampong-ayer/

## Bulgaria · BG

Capital / seat: Sofia

1. Bulgaria is in Europe. Its capital is Sofia.

2. Rila Monastery began in the 10th century. After serious fire damage, it was rebuilt in the 19th century, continuing its older traditions.

3. Its buildings reflect a period of renewed Bulgarian cultural life. Repairing and protecting old places is another way of passing on history.

4. Rila Monastery has buildings arranged around a courtyard. Distinguish open and covered spaces to explore areas for gathering and movement.

5. Place Rila’s older and rebuilt elements on a timeline. A building’s origin can differ from the period when its present appearance took shape.

Explorer words: Sofia · Rila Monastery · St John of Rila · monastery · 10th century · 19th century · rebuilding · Bulgarian culture · religious architecture · cultural preservation

Postcard scene: Rila Monastery

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bg/
- https://whc.unesco.org/en/list/216/

## Burkina Faso · BF

Capital / seat: Ouagadougou

1. Burkina Faso is in Africa. Its capital is Ouagadougou.

2. The Royal Court of Tiébélé has earthen houses joined by narrow passages. Their arrangement reflects how the Kasena community lives together.

3. Women decorate the walls with meaningful patterns and pass on their skills. Decorating a home preserves a living tradition as well as creating beauty.

4. Tiébélé’s wall designs bring art into homes. Images and patterns can appear on buildings and everyday objects as well as on paper.

5. Choose a repeated shape in a Tiébélé pattern and predict the next one. Exploring mathematical repetition can accompany learning the community’s symbolic meanings.

Explorer words: Ouagadougou · Tiébélé · Kasena people · earthen houses · wall patterns · traditional skills · passageways · courtyards · symbols · living tradition

Postcard scene: Royal Court of Tiébélé

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/bf/
- https://whc.unesco.org/en/list/1713/

## Burundi · BI

Capital / seat: Gitega

1. Burundi is in Africa. Its capital is Gitega.

2. Burundi's royal drum tradition combines coordinated drumming and dancing. Songs and poetry join the performance to tell the community's stories.

3. The performance is an art of movement as well as sound. Keeping a shared rhythm means listening to others and watching their movements.

4. Burundi’s royal drum performance is a collective art. Coordinating claps after a shared starting signal explores the listening and cooperation involved in performing together.

5. Continuing the drumming tradition includes making instruments and learning to perform. Crafting an object connects with the skills needed to use it.

Explorer words: Gitega · royal drums · drumming · rhythm · dance · songs · poetry · community · traditional performance · Gitega and its surroundings

Postcard scene: Gitega and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/decisions/9.COM/10.10

## Cambodia · KH

Capital / seat: Phnom Penh

1. Cambodia is in Asia. Its capital is Phnom Penh.

2. Angkor contains remains of several capitals of the Khmer Empire. Angkor Wat and the Bayon display architecture and sculpture from different periods.

3. Forests surround Angkor's monuments. Protecting buildings and their natural setting helps preserve carved stonework and the landscape around it.

4. Angkor preserves traces of reservoirs and water-management channels. Looking beyond temples reveals systems that helped sustain a large city.

5. Look for repetition and variation in Angkor’s stone carvings. Comparing details reveals different choices within seemingly similar designs.

Explorer words: Phnom Penh · Angkor · Angkor Wat · Bayon · Khmer Empire · temples · stone carvings · ancient capitals · forest · site conservation

Postcard scene: Angkor

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kh/
- https://whc.unesco.org/en/list/668/

## Cameroon · CM

Capital / seat: Yaoundé

1. Cameroon is in Africa. Its capital is Yaoundé.

2. The Dja Faunal Reserve is a rainforest almost surrounded by the Dja River. The river forms a boundary and provides water and habitat for wildlife.

3. Many primates and other mammals live in Dja. Biodiversity describes the variety of living things found together in a place.

4. The Dja River connects with the Congo Basin’s drainage area. A catchment includes land whose waterways feed a river system, extending beyond one river line.

5. Record observation locations separately from animal features when studying Dja. Detailed evidence supports research and care for a forest.

Explorer words: Yaoundé · Dja Faunal Reserve · Dja River · rainforest · primates · mammals · biodiversity · habitat · river boundary · nature conservation

Postcard scene: Dja Faunal Reserve

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cm/
- https://whc.unesco.org/en/list/407/

## Canada · CA

Capital / seat: Ottawa

1. Ottawa is Canada’s capital. Niagara Falls lies on the border between Canada and the United States.

2. Canada borders the Pacific, Atlantic and Arctic Oceans.

3. Canada is home to First Nations, Inuit and Métis communities, with many cultures and languages.

4. Fossils in Joggins’s coastal cliffs reveal ancient living environments. Rocks beside today’s sea can preserve evidence of forests and life from the distant past.

5. Model Joggins’s rock layers with coloured paper. Marking fossils in different layers introduces how geologists compare evidence from different periods.

Explorer words: Ottawa · Niagara Falls · maple leaf · Rocky Mountains · Arctic Ocean · beaver · ice hockey · poutine · French · Inuit

Postcard scene: Niagara Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1285/

## Cape Verde · CV

Capital / seat: Praia

1. Cape Verde is in Africa. Its capital is Praia.

2. Cidade Velha on Santiago Island preserves historic streets, churches and a royal fortress. It is a different town from today's capital, Praia.

3. This port town records Atlantic trade and the colonial period. Learning its history means remembering people's lives as well as its buildings.

4. Cidade Velha’s history also connects with the Atlantic slave trade. A port’s past includes people forcibly displaced, alongside the movement of goods.

5. Cidade Velha and Praia are both on Santiago Island. A historic town and a present-day capital can be separate places on the same island.

Explorer words: Praia · Santiago Island · Cidade Velha · Ribeira Grande · Atlantic Ocean · royal fortress · port town · historic streets · churches · colonial period

Postcard scene: Cidade Velha, Historic Centre of Ribeira Grande

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cv/
- https://whc.unesco.org/en/list/1310/

## Central African Republic · CF

Capital / seat: Bangui

1. Central African Republic is in Africa. Its capital is Bangui.

2. The Sangha Trinational forests are protected by the Central African Republic, Cameroon and Congo. Connected parks protect wildlife habitat across borders.

3. Grassy clearings occur within the forests, where forest elephants and gorillas live. Forest and open areas provide different kinds of habitat.

4. Clearings in the Sangha forests, also called bais, are used by wildlife. Include open spaces rather than representing the whole forest with one uniform green colour.

5. Draw national boundaries and wildlife routes in the trinational area with different lines. Political borders can differ from the paths used by living things.

Explorer words: Bangui · Sangha River · Sangha Trinational · forest elephant · western lowland gorilla · tropical forest · forest clearings · national parks · borders · habitat connectivity

Postcard scene: Sangha Trinational

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cf/
- https://whc.unesco.org/en/list/1380/

## Chad · TD

Capital / seat: N'Djamena

1. Chad is in Africa. Its capital is N'Djamena.

2. Water and wind have shaped Ennedi's sandstone into cliffs and natural arches. The wearing away of rock and soil is called erosion.

3. Ennedi's caves and rocks preserve ancient paintings and carvings. Even in the dry Sahara, water in its valleys supports people and animals.

4. Water persists in some deep Ennedi canyons. Even in a desert, water location helps determine where plants, animals and people can live.

5. Compare Ennedi’s natural arches with built arches. Similar shapes can arise through different processes, such as erosion and human construction.

Explorer words: N'Djamena · Ennedi · Sahara · sandstone · natural arches · erosion · cliffs · rock art · caves · Ennedi Massif: Natural and Cultural Landscape

Postcard scene: Ennedi Massif: Natural and Cultural Landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/td/
- https://whc.unesco.org/en/list/1475/

## Chile · CL

Capital / seat: Santiago

1. Chile’s capital, Santiago, sits in a broad valley facing the Andes Mountains.

2. Moai statues made by the Rapa Nui people stand on Rapa Nui Island in the Pacific.

3. Chile is a long country stretching north to south along the Pacific coast.

4. Sewell in the Andes is connected by stairs along steep slopes. Comparing it with level city streets shows how elevation shapes routes through a settlement.

5. Sewell preserves colourful wooden buildings used by copper-mining workers. Studying the mine’s history includes both industrial facilities and everyday living spaces.

Explorer words: Santiago · Rapa Nui · moai · Pacific Ocean · Andes Mountains · Atacama Desert · copper · empanada · Spanish · Andean condor

Postcard scene: Moai of Rapa Nui

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1214/

## China · CN

Capital / seat: Beijing

1. Beijing is China’s capital. China is a very large country with many kinds of landscapes and climates.

2. The Great Wall is a long system of old walls and watchtowers that crosses mountain ridges.

3. Giant pandas live in mountain bamboo forests in China.

4. A Mogao mural near Dunhuang depicts a camel pulling a cart. Painted scenes provide clues about movement and trade along the Silk Road.

5. Mogao’s Mount Wutai painting includes mountains, rivers, towns and roads. Comparing painting and map invites questions about showing scenery and communicating locations.

Explorer words: Beijing · Great Wall · giant panda · Yangtze River · Yellow River · dumplings · Peking duck · Mandarin Chinese · Spring Festival · paper cutting

Postcard scene: Great Wall

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/440/

## Colombia · CO

Capital / seat: Bogotá

1. Colombia’s capital, Bogotá, sits on a high plateau in the Andes.

2. Cartagena’s walled Old Town lies on Colombia’s Caribbean coast.

3. Colombia grows much of its fragrant coffee in mountain regions.

4. Colombia’s coffee cultural landscape links mountain farmland with settlements. Farming across uneven terrain encouraged people to develop methods suited to the slopes.

5. Connect routes, workplaces and villages in a coffee-growing landscape. Behind a farm product are people cooperating to grow and transport it.

Explorer words: Bogotá · Cartagena · walled city · Caribbean Sea · Andes Mountains · coffee · arepa · Spanish · emerald · Andean condor

Postcard scene: Cartagena Walled City

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1121/

## Comoros · KM

Capital / seat: Moroni

1. Comoros is in Africa. Its capital is Moroni.

2. Comoros' historic sultanate towns grew through Indian Ocean trade and migration. Their buildings and streets record meetings between different cultures.

3. These towns are spread across several islands and retain living social traditions. Different islands within one country can have distinct histories and ways of life.

4. Map the Comoros’s historic towns by island. One country’s cultural heritage can be distributed across several islands.

5. Draw coastlines, streets and buildings of a sultanate town together. Connecting seaborne exchange with urban spaces gives a fuller picture of a port’s history.

Explorer words: Moroni · sultanate towns · medinas · Indian Ocean · island towns · maritime trade · migration · city-states · traditional customs · cultural exchange

Postcard scene: The Medinas of the Historic Sultanates of the Comoros

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/km/
- https://whc.unesco.org/en/list/1768/

## Costa Rica · CR

Capital / seat: San José

1. San José is Costa Rica’s capital. Costa Rica is in Central America, which is part of North America.

2. Costa Rica’s tropical forests and national parks shelter sloths, monkeys and many birds. Protected areas help conserve this wildlife.

3. The Diquís region has large stone spheres made by earlier communities. Archaeological sites with these spheres are protected as World Heritage.

4. Diquís stone spheres introduce the difference between a circle and a sphere. A drawn circle is flat, while a sphere is a three-dimensional form.

5. Questions remain about the meaning and production of Diquís spheres. Distinguishing evidence from unknowns helps avoid treating an imagined explanation as established fact.

Explorer words: San José · Central America · tropical forest · sloth · monkey · national parks · Pacific Ocean · Caribbean Sea · Diquís · stone spheres

Postcard scene: Arenal Volcano

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cr/
- https://www.visitcostarica.com/where-to-go/central-pacific
- https://whc.unesco.org/en/list/1453/

## Croatia · HR

Capital / seat: Zagreb

1. Croatia is in Europe. Its capital is Zagreb.

2. Plitvice's lakes and waterfalls are linked by natural barriers formed as minerals build up in the water. Water continues to reshape this landscape.

3. Bears, wolves and many birds live in the surrounding forests. Protecting the woods as well as the lakes keeps wildlife habitats connected.

4. At Plitvice, calcium carbonate deposits help form barriers between lakes. Compare erosion by water with the accumulation of materials carried within it.

5. Connect Plitvice’s lakes and waterfalls in flow order. This reveals a linked water system beyond the study of individual lakes.

Explorer words: Zagreb · Plitvice Lakes · waterfalls · limestone · natural barriers · minerals · bears · wolves · forests · Dubrovnik

Postcard scene: Dubrovnik

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hr/
- https://whc.unesco.org/en/list/98/

## Cuba · CU

Capital / seat: Havana

1. Havana is Cuba’s capital. Old Havana preserves historic squares, fortifications and buildings from different periods.

2. Viñales Valley has rounded limestone hills called mogotes, with farming villages and fields between them.

3. Cuba is an island country in the Caribbean. Old Havana and Viñales Valley are UNESCO World Heritage sites.

4. Viñales combines farmland and villages within a cultural landscape. Different colours for natural hills and cultivated fields reveal people’s contributions to the scenery.

5. Draw Viñales’s mogotes on a map and in side view. A map compares their positions, while a profile compares rounded outlines and heights.

Explorer words: Havana · Old Havana · Viñales Valley · mogotes · limestone · Caribbean Sea · island country · fortifications · squares · Spanish

Postcard scene: Old Havana

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cu/
- https://whc.unesco.org/en/list/204/
- https://whc.unesco.org/en/list/840/

## Cyprus · CY

Capital / seat: Nicosia

1. Cyprus is in Europe. Its capital is Nicosia.

2. Choirokoitia is a village site from the Neolithic period. House remains and excavated objects reveal daily life before written records.

3. Parts of the site are left unexcavated for future research. Even a small object underground can be an important clue to past life.

4. Khirokitia’s houses had circular ground plans. Arranging round and rectangular plans on paper explores different ways of grouping living spaces.

5. At excavated sites such as Khirokitia, an object’s location is important evidence. Record its layer and building alongside the object’s name.

Explorer words: Nicosia · Choirokoitia · Neolithic period · house remains · excavated objects · prehistory · archaeology · village · Mediterranean Sea · Paphos mosaics

Postcard scene: Paphos mosaics

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cy/
- https://whc.unesco.org/en/list/848/

## Czechia · CZ

Capital / seat: Prague

1. Prague is Czechia’s capital. The Vltava River flows through the city, with historic buildings on both banks.

2. Charles Bridge is a historic stone bridge across the Vltava. It offers views of Prague Castle and the city’s towers.

3. Prague’s UNESCO-listed historic centre preserves Gothic, Renaissance and Baroque buildings together.

4. Litomyšl Castle reflects Renaissance architecture developed in Italy. Its arcaded spaces show how architectural ideas travel between regions with people.

5. Litomyšl Castle also preserves later decoration. Use a timeline to distinguish its initial construction from subsequent alterations and embellishments.

Explorer words: Prague · Charles Bridge · Vltava River · Prague Castle · St Vitus Cathedral · Old Town · Gothic architecture · Renaissance · Baroque · Czech

Postcard scene: Charles Bridge, Prague

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cz/
- https://whc.unesco.org/en/list/616/
- https://prague.eu/en/objevujte/charles-bridge-karluv-most/
- https://whc.unesco.org/en/list/901/

## Denmark · DK

Capital / seat: Copenhagen

1. Copenhagen is Denmark’s capital. Nyhavn harbour is lined with colourful houses and boats.

2. Hans Christian Andersen was a Danish storyteller. Copenhagen’s Little Mermaid statue was inspired by his fairy tale.

3. Many people in Copenhagen cycle to school or work, using the city’s connected cycling routes.

4. Jelling’s runic writing is carved into stone. Comparing it with writing on paper invites questions about how a recording material affects preservation.

5. Jelling brings burial mounds, runestones and a church together. Their chronology records changes in Denmark’s religion and royal authority.

Explorer words: Copenhagen · Nyhavn · Little Mermaid statue · Hans Christian Andersen · fairy tales · bicycles · harbour · canal · boats · Danish

Postcard scene: Nyhavn, Copenhagen

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dk/
- https://www.visitdenmark.com/denmark/plan-your-trip/nyhavn-harbour-gdk426287
- https://www.visitdenmark.com/denmark/plan-your-trip/the-little-mermaid-gdk586951
- https://www.visitcopenhagen.com/
- https://whc.unesco.org/en/list/697/

## Djibouti · DJ

Capital / seat: Djibouti

1. Djibouti is in Africa. Its capital is Djibouti.

2. Lake Assal lies below sea level. Sea level gives us a reference for comparing whether land is higher or lower.

3. Djibouti has traditions of telling stories through songs, poetry and dance. The ways of life of different communities contribute to its varied culture.

4. Lake Assal’s salt introduces evaporation. When water leaves salt water as vapour, salt remains, illustrating different changes in the two materials.

5. Draw Lake Assal and the surrounding higher ground in profile. A sea-level reference line allows elevation comparisons even away from a visible coast.

Explorer words: Djibouti · Lake Assal · sea level · depression · lake · songs · poetry · dance · nomadic traditions · cultural encounters

Postcard scene: Lake Assal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guide.visitdjibouti.dj/

## Dominica · DM

Capital / seat: Roseau

1. Dominica is in Americas. Its capital is Roseau.

2. Morne Trois Pitons National Park combines tropical forest and volcanic landscapes. Steep valleys and lakes show the variety of a volcanic island.

3. Boiling Lake and hot springs show how heat underground affects water. Dominica is a different country from the similarly named Dominican Republic.

4. Map Morne Trois Pitons’s forests and lakes together. Water within a volcanic island connects with terrain and helps provide living environments.

5. Boiling Lake introduces the distinction between temperature and water quantity. Knowing that water is hot does not reveal a pool’s width or depth.

Explorer words: Roseau · Morne Trois Pitons · Boiling Lake · volcanoes · hot springs · geothermal heat · tropical forest · valleys · volcanic island · freshwater lakes

Postcard scene: Boiling Lake

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/dm/
- https://whc.unesco.org/en/list/814/

## Dominican Republic · DO

Capital / seat: Santo Domingo

1. Santo Domingo is the Dominican Republic’s capital. Its historic centre stands near the mouth of the Ozama River.

2. The Dominican Republic shares the Caribbean island of Hispaniola with Haiti. It is a different country from Dominica.

3. Merengue is music and dance from the Dominican Republic, shared at festivals and gatherings.

4. Santo Domingo’s colonial city has a planned grid of streets. Compare it with winding historic streets to explore how road arrangements affect movement.

5. Santo Domingo’s historic public buildings record colonial rule. Studying their architecture also involves learning about Indigenous people and others who experienced that period.

Explorer words: Santo Domingo · historic Santo Domingo · Hispaniola · Ozama River · Caribbean Sea · merengue · dance · festivals · Haiti · Spanish

Postcard scene: Colonial City of Santo Domingo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/do/
- https://whc.unesco.org/en/list/526/
- https://ich.unesco.org/en/RL/music-and-dance-of-the-merengue-in-the-dominican-republic-01162

## DR Congo · CD

Capital / seat: Kinshasa

1. DR Congo is in Africa. Its capital is Kinshasa.

2. Virunga National Park includes volcanic grasslands, wetlands and high mountain snowfields. Different heights and landscapes create different wildlife habitats.

3. Virunga is home to mountain gorillas. Birds also arrive from distant regions for winter, showing how wildlife conservation connects different places.

4. Draw Virunga’s high mountains and low watersides in a profile. Nearby places on a map can offer different living conditions when their elevations differ.

5. Group Virunga’s animals as birds and mammals. Gorillas and birds can share a park while differing in body characteristics and reproduction.

Explorer words: Kinshasa · Virunga · mountain gorilla · volcanoes · wetlands · Rwenzori Mountains · grasslands · hippopotamus · migratory birds · habitat

Postcard scene: Virunga volcanoes and mountain gorillas

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cd/
- https://whc.unesco.org/en/list/63/

## Ecuador · EC

Capital / seat: Quito

1. Ecuador is in Americas. Its capital is Quito.

2. Giant tortoises and different finches live in the Galápagos Islands. Long-isolated islands can develop wildlife different from that found elsewhere.

3. Ocean currents meet around the Galápagos, whose islands were shaped by volcanoes. Observing their animals helped Darwin develop his studies of evolution.

4. Compare Galápagos tortoises with marine iguanas. Reptiles within one island region can differ in feeding places and body forms.

5. Compare the beak shapes of Galápagos finches. Linking observed forms with food use explores relationships between an organism’s features and its environment.

Explorer words: Quito · Galápagos Islands · giant tortoise · finches · iguana · ocean currents · volcanoes · Charles Darwin · evolution · Basilica del Voto Nacional

Postcard scene: Basilica del Voto Nacional, Quito

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ec/
- https://whc.unesco.org/en/list/1/

## Egypt · EG

Capital / seat: Cairo

1. Cairo is Egypt’s capital. The Nile flows through the desert toward the Mediterranean Sea.

2. The Pyramids of Giza are enormous stone tombs built in ancient Egypt.

3. Today, many people live and farm in towns along the Nile.

4. Abu Simbel’s temples were relocated when a dam threatened to submerge them. Moving and reassembling large monuments required technical skill and cooperation among countries.

5. The rescue of Egypt’s Nubian monuments became an important example of international heritage conservation. Consider why countries work together to protect a place’s history.

Explorer words: Cairo · Pyramids of Giza · Nile River · Sahara Desert · Great Sphinx · hieroglyphs · Arabic · dates · Red Sea · pharaohs

Postcard scene: Pyramids of Giza

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/88/

## El Salvador · SV

Capital / seat: San Salvador

1. El Salvador is in Americas. Its capital is San Salvador.

2. Joya de Cerén is an old farming village buried by a volcanic eruption. Remains preserved beneath ash reveal how its residents lived.

3. Unlike a palace or great temple, this site records ordinary farmers' lives. Homes and farming remains can be important evidence for history.

4. Joya de Cerén developed after older volcanic ash weathered into fertile soil. Evidence of a natural event can later help provide the basis for settlement.

5. Record Joya de Cerén’s building remains and tools by location. Adding find positions to object names provides clues about the spaces in which they were used.

Explorer words: San Salvador · Joya de Cerén · volcanic ash · Laguna Caldera volcano · farming village · ancient homes · farming · excavation · daily life · archaeology

Postcard scene: Joya de Cerén

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sv/
- https://whc.unesco.org/en/list/675/

## Equatorial Guinea · GQ

Capital / seat: Ciudad de la Paz

In January 2026, Ciudad de la Paz replaced Malabo as the capital.

1. In January 2026, Ciudad de la Paz replaced Malabo as the capital.

2. Pico Basile is a high mountain on Bioko Island in Equatorial Guinea. This postcard scene is separate from the capital on the mainland.

3. Bioko has forests that change with elevation, bringing tropical and mountain habitats together.

4. Bioko’s forests support primates such as drills and black colobus monkeys. Animals within a broad group can differ in appearance and behaviour.

5. Bioko’s biosphere reserve brings conservation, research and community life together. Consider the roles that researchers and residents can play in caring for a forest.

Explorer words: Ciudad de la Paz · Africa · French · Portuguese · Bioko Island · Pico Basile · Montane forest · Spanish · altitude · habitats

Postcard scene: Pico Basilé on Bioko Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.guineaecuatorialpress.com/noticias/decreto_ley_por_el_que_se_declara_la_ciudad_de_la_paz_djibloho_capital_de_la_republica_de_guinea_ecuatorial
- https://minturismo.gob.gq/lugares-turisticos/
- https://www.unesco.org/en/mab/isla-de-bioko

## Eritrea · ER

Capital / seat: Asmara

1. Eritrea is in Africa. Its capital is Asmara.

2. Asmara stands more than 2,000 metres above sea level. Compare this high city's position with lower land near the sea on the map.

3. Asmara preserves early-20th-century modernist buildings. Cinemas, shops and religious buildings show different designs from a period of new urban planning.

4. Asmara’s architecture includes buildings used by different religious communities. A city’s culture cannot be explained through only one way of life.

5. Break Asmara’s cinemas and shops into simple shapes. Comparing curved and straight elements reveals variety within modern architecture.

Explorer words: Asmara · Asmara modernist architecture · Fiat Tagliero · elevation · highland city · urban planning · cinemas · shops · modernist architecture · 20th century

Postcard scene: Asmara modernist city and Fiat Tagliero

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/er/
- https://whc.unesco.org/en/list/1550/

## Estonia · EE

Capital / seat: Tallinn

1. Estonia is in Europe. Its capital is Tallinn.

2. Tallinn was an important trading city of the Hanseatic League. Merchants' houses and public buildings preserve traces of that history.

3. Tallinn's Old Town preserves medieval streets and buildings. Caring for older buildings helps people learn how a city developed.

4. Tallinn includes elevated Toompea and a lower town. Mapping both reveals differences in elevation and function within one historic centre.

5. Compare Tallinn’s merchants’ houses with public buildings. Recording windows and entrances connects observation of form with questions about a building’s use.

Explorer words: Tallinn · Tallinn Old Town · Hanseatic League · trade · merchants' houses · medieval streets · churches · castle · public buildings · urban conservation

Postcard scene: Tallinn Old Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ee/
- https://whc.unesco.org/en/list/822/

## Eswatini · SZ

Capital / seat: Mbabane

Mbabane is the administrative capital; Lobamba is the royal and legislative centre.

1. Mbabane is the administrative capital; Lobamba is the royal and legislative centre.

2. Sibebe, north of Mbabane, is a huge rounded rock formation. Its shape and surrounding valleys show that mountains can take very different forms.

3. Eswatini's Umhlanga Reed Dance is a community tradition. Songs, dances and the gathering of reeds help pass on its cultural heritage.

4. Locate Mbabane and Lobamba separately when mapping Sibebe. A natural site’s position differs from information about cities and their capital functions.

5. Sibebe introduces the difference between size and age. A larger object is not necessarily older, so geological age cannot be determined from appearance alone.

Explorer words: Mbabane · Sibebe Rock · Mantenga Falls · Lobamba · Umhlanga · reeds · Reed Dance · rock formation · valleys · community celebrations

Postcard scene: Mantenga Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.thekingdomofeswatini.com/central-eswatini/sibebe-rock/
- https://www.thekingdomofeswatini.com/news-blogs/backpacker-tours-visitor-guide-to-the-2026-umhlanga-reed-dance/

## Ethiopia · ET

Capital / seat: Addis Ababa

1. Addis Ababa is Ethiopia’s capital. Ethiopia has highlands and historic cultural sites.

2. Lalibela’s churches were carved from solid rock, with buildings and passageways cut into the stone.

3. Yayu Biosphere Reserve protects mountain rainforest with wild Arabica coffee and many other living things.

4. Aksum’s tall stelae have carvings resembling multistorey buildings. Comparing buildings with their sculpted representations reveals architecture expressed in stone.

5. Aksum participated in trade linked to the Red Sea port of Adulis. Tracing inland-to-coast routes connects regions through the movement of goods and knowledge.

Explorer words: Addis Ababa · Lalibela · rock-hewn churches · rock carving · Yayu · coffee forest · Arabica coffee · Ethiopian Highlands · biodiversity · Amharic

Postcard scene: Rock-Hewn Churches of Lalibela

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/et/
- https://whc.unesco.org/en/list/18/
- https://www.unesco.org/en/mab/yayu?hub=66369
- https://whc.unesco.org/en/list/15/

## Fiji · FJ

Capital / seat: Suva

1. Fiji is in Oceania. Its capital is Suva.

2. Levuka is a historic port town in Fiji. Low buildings, coconut palms and mango trees line the seafront, showing a town shaped by the sea.

3. Levuka preserves traces of local residents and people who arrived by sea. Warehouses, schools and shops show that ports connected knowledge as well as goods.

4. Levuka is on Ovalau, while today’s capital Suva is on Viti Levu. Locating both clarifies relationships between Fiji’s islands.

5. Draw Levuka’s coastline alongside the higher land behind it. A town’s position between sea and slopes reveals how terrain influences urban arrangement.

Explorer words: Suva · Levuka · Bouma waterfalls · port town · coconut palms · mango trees · seafront · warehouses · shops · cultural exchange

Postcard scene: Bouma waterfalls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fj/
- https://whc.unesco.org/en/list/1399/

## Finland · FI

Capital / seat: Helsinki

1. Finland’s capital, Helsinki, is home to the white-domed Helsinki Cathedral.

2. Finland has many forests and lakes where people spend time outdoors.

3. Finnish and Swedish are the official languages of Finland.

4. Suomenlinna is a sea fortress built across islands. Mapping rocky shores and buildings together shows how natural terrain was used for defence.

5. Suomenlinna preserves history from Swedish, Russian and Finnish periods. Use a location map alongside a timeline to distinguish present geography from historical change.

Explorer words: Helsinki · Helsinki Cathedral · Senate Square · Baltic Sea · Finnish · sauna · reindeer · blueberries · rye bread · northern lights

Postcard scene: Helsinki Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/583/

## France · FR

Capital / seat: Paris

1. Paris is France’s capital. The Eiffel Tower was built for the 1889 World’s Fair.

2. France has the high Alps as well as Atlantic and Mediterranean coasts.

3. The Louvre in Paris is home to many well-known works of art.

4. Mont-Saint-Michel’s abbey and village grew on a rocky islet. Studying tides explains how the surrounding shoreline can change over time.

5. Mont-Saint-Michel’s builders adapted structures to a narrow, elevated rock. Drawing lower and upper spaces helps explore the relationship between terrain and architecture.

Explorer words: Paris · Eiffel Tower · Louvre · Seine River · Alps · baguette · croissant · French · lavender · cheese

Postcard scene: Eiffel Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/80/

## Gabon · GA

Capital / seat: Libreville

1. Gabon is in Africa. Its capital is Libreville.

2. Lopé-Okanda combines dense rainforest and open savanna. Where forest meets grassland, wildlife can find several different kinds of habitat.

3. The area also preserves old settlement remains, iron-working traces and rock carvings. A nature reserve can hold a long human history too.

4. Lopé-Okanda’s rock engravings preserve carved marks. Comparing them with drawings introduces making an image by removing material from a surface.

5. Overlay a natural-environment map of Lopé-Okanda with an archaeological map. A conservation area can also be a place for studying earlier human life.

Explorer words: Libreville · Lopé-Okanda · rainforest · savanna · mandrill · ecosystem · rock carvings · iron-working · settlement remains · habitat

Postcard scene: Lopé-Okanda landscape and mandrill

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ga/
- https://whc.unesco.org/en/list/1147/

## Gambia · GM

Capital / seat: Banjul

1. Gambia is in Africa. Its capital is Banjul.

2. Sites around Kunta Kinteh Island record encounters between Africa and Europe along the River Gambia. They teach the history of the slave trade and its abolition.

3. Protecting these sites means more than preserving buildings. It also means remembering people denied their freedom and reflecting on everyone's dignity.

4. Kunta Kinteh Island’s related sites extend across several locations around the river. Heritage named for one island can encompass a wider historical landscape.

5. Studying the Gambia River’s heritage invites comparison between forced movement and freedom to travel. Considering people’s choices makes the meaning of liberty more concrete.

Explorer words: Banjul · River Gambia · Kunta Kinteh Island · Senegambian stone circles · historic sites · slave trade · abolition · freedom · dignity · historical memory

Postcard scene: Senegambian stone circles

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gm/
- https://whc.unesco.org/en/list/761/

## Georgia · GE

Capital / seat: Tbilisi

1. Georgia is in Asia. Its capital is Tbilisi.

2. Gelati Monastery displays medieval Georgian architecture and art. Large dressed stones and decorative arches record the skills of its builders.

3. Gelati also housed an academy for scholarship and education. It shows how religious buildings could become centres of learning and culture.

4. Gelati’s interiors preserve mosaics and wall paintings. Comparing assembled pieces with painted surfaces reveals different artistic techniques.

5. Explore Gelati Academy by recording questions separately from answers. A place of learning can share existing knowledge while investigating new questions.

Explorer words: Tbilisi · Gelati Monastery · Narikala Fortress · academy · stone architecture · arches · medieval Georgia · science · education · craftsmanship

Postcard scene: Tbilisi and Narikala Fortress

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ge/
- https://whc.unesco.org/en/list/710/

## Germany · DE

Capital / seat: Berlin

1. Berlin is Germany’s capital, and the Brandenburg Gate is one of its best-known historic landmarks.

2. Germany’s landscapes range from the North and Baltic seas to the Alps in the south.

3. The Berlin Wall once divided the city; when it opened in 1989, people could travel between its sides again.

4. Zollverein preserves a former coal mine and industrial facilities. Linking tracks and buildings helps explain the sequence of extracting, moving and processing a resource.

5. Zollverein’s history includes workers’ lives as well as machines. Studying workplaces with housing reveals how industry shaped a community.

Explorer words: Berlin · Brandenburg Gate · Berlin Wall · Rhine River · Black Forest · Alps · pretzel · bread · German · football

Postcard scene: Brandenburg Gate

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/975/

## Ghana · GH

Capital / seat: Accra

1. Accra is Ghana’s capital, on the country’s Atlantic coast.

2. Kente is made by joining narrow woven strips. Its colours and patterns carry meanings and community stories.

3. Coastal forts and castles preserve the history of trade and the suffering caused by the slave trade. Remembering it helps us learn about human rights.

4. Asante traditional buildings use materials such as earth, wood and bamboo. Identifying their different roles shows ways of using local resources in construction.

5. Wall motifs on Asante buildings carry symbolic meanings. Record their shapes, then learn the meanings explained within the community’s traditions.

Explorer words: Accra · kente · weaving · woven strips · loom · cotton · Atlantic Ocean · Elmina Castle · Cape Coast Castle · Jamestown

Postcard scene: Black Star Square, Accra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gh/
- https://ich.unesco.org/en/RL/craftsmanship-of-traditional-woven-textile-kente-02130
- https://whc.unesco.org/en/list/34/
- https://whc.unesco.org/en/list/35/

## Greece · GR

Capital / seat: Athens

1. Greece’s capital, Athens, has the Acropolis, where the Parthenon stands on a hill.

2. Greece has mountains, coastlines, and many large and small islands.

3. The ancient Olympic Games were held at Olympia in Greece.

4. Meteora’s monasteries stand on high sandstone formations. Drawing rock and building outlines separately reveals how architecture uses natural terrain.

5. Meteora’s monasteries also contain religious wall paintings. Compare a distant building view with a close view of a mural to observe one place at different scales.

Explorer words: Athens · Parthenon · Acropolis · Olympia · Aegean Sea · Mount Olympus · olives · feta cheese · Greek · Greek islands

Postcard scene: Acropolis & Parthenon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/455/

## Grenada · GD

Capital / seat: St. George's

1. Grenada is in Americas. Its capital is St. George's.

2. Grenada's spice gardens grow nutmeg and other aromatic plants. Spices are plant ingredients that add flavour and aroma to food.

3. Spices such as nutmeg are also used in syrups, jams and sauces. One plant ingredient can become part of many different foods.

4. When learning about nutmeg, distinguish the plant from the spice. The whole tree and the part used in food describe different scopes.

5. Organise a Grenadian spice garden with plant and ingredient drawings. Tracing a finished food back to its plant reveals where an ingredient begins.

Explorer words: St. George's · nutmeg · spices · herbs · spice garden · syrup · jam · sauce · plant aromas · Carenage

Postcard scene: Carenage, St. George’s

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.puregrenada.com/de-la-grenade-nutmeg-garden/

## Guatemala · GT

Capital / seat: Guatemala City

1. Guatemala is in Americas. Its capital is Guatemala City.

2. Tikal is an ancient Maya city within tropical forest. Tall temples, palaces and broad squares reveal Maya building skills.

3. Remains of ordinary homes are scattered around the larger buildings. Understanding a city means studying everyday spaces as well as grand monuments.

4. Tikal’s temples use steps and levels to create elevated spaces. A layered paper model can represent the transition from a ground plan to a tall structure.

5. Tikal protects cultural and natural heritage together. Drawing ruins within forest boundaries connects archaeological study with wildlife conservation.

Explorer words: Guatemala City · Tikal · Maya civilisation · tropical forest · temples · palaces · public squares · house remains · city ruins · excavation

Postcard scene: Tikal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gt/
- https://whc.unesco.org/en/list/64/

## Guinea · GN

Capital / seat: Conakry

1. Guinea is in Africa. Its capital is Conakry.

2. Mount Nimba has forested slopes and grassy uplands. Lower and higher parts of the mountain provide different habitats for plants and animals.

3. Some chimpanzees around Mount Nimba use stones as tools. Watching animals can show how members of the same species live in different ways.

4. Mount Nimba’s heritage extends across Guinea and Côte d’Ivoire. Mapping protected areas with borders reveals why caring for nature can require neighbouring countries’ cooperation.

5. Observe documented stone use by Nimba chimpanzees. Recording tool materials separately from actions helps study the connection between objects and behaviour.

Explorer words: Conakry · Mount Nimba · chimpanzee · stone tools · mountain forest · grasslands · slopes · endemic species · animal behaviour · nature reserve

Postcard scene: Mount Nimba

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gn/
- https://whc.unesco.org/en/list/155/

## Guinea-Bissau · GW

Capital / seat: Bissau

1. Guinea-Bissau is in Africa. Its capital is Bissau.

2. The Bijagós Islands contain mangroves, mudflats and shallow seas. Rising and falling tides create changing habitats along the shore.

3. Sea turtles, manatees and travelling shorebirds use these islands. Protecting seas and island coasts helps preserve places for many animals.

4. Bijagós mudflats become exposed as water recedes. Overlaying high- and low-tide drawings shows how a water–land boundary can move.

5. Map both island stopovers and routes of Bijagós’s migratory birds. Caring for one bird involves considering several places used during its journey.

Explorer words: Bissau · Bijagós Archipelago · mangroves · mudflats · high tide · low tide · sea turtles · manatee · shorebirds · coastal ecosystem

Postcard scene: Bijagós coastal and marine ecosystems

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/gw/
- https://whc.unesco.org/en/list/1431/

## Guyana · GY

Capital / seat: Georgetown

1. Guyana is in Americas. Its capital is Georgetown.

2. At Kaieteur Falls, the Potaro River flows through rainforest before dropping over a high cliff. Spray forms as falling water breaks into tiny droplets.

3. Different birds and plants live in the forest around the waterfall. Study the connected river and forest, rather than the waterfall alone.

4. Tiny droplets at Kaieteur can create rainbows in sunlight. Compare them with rainbows after rain to explore interactions between water and light.

5. Swifts use spaces behind Kaieteur’s falling water for nesting. Around a striking waterfall are living spaces that people may overlook.

Explorer words: Georgetown · Kaieteur Falls · Potaro River · rainforest · spray · cliff · national park · forest birds · river water · ecological connections

Postcard scene: Kaieteur Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://guyanatourism.com/kaieteur-falls/

## Haiti · HT

Capital / seat: Port-au-Prince

1. Haiti is in Americas. Its capital is Port-au-Prince.

2. The Citadelle Laferrière and Sans-Souci Palace were built after Haiti gained independence. They record a time when newly free people were building a country.

3. Haiti's history park communicates the meaning of freedom as well as preserving buildings. Its monuments invite us to think about independence and human dignity.

4. Locate Haiti’s Citadelle Laferrière separately from Port-au-Prince. A historical monument’s position differs from the location of today’s political centre.

5. Place Haitian independence and the historic park’s construction on a timeline. Distinguish an event from the later creation of buildings connected with it.

Explorer words: Port-au-Prince · Citadelle Laferrière · Sans-Souci Palace · Ramiers · independence · freedom · dignity · history park · fortress · 19th century

Postcard scene: Citadelle Laferrière

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ht/
- https://whc.unesco.org/en/list/180/

## Honduras · HN

Capital / seat: Tegucigalpa

1. Honduras is in Americas. Its capital is Tegucigalpa.

2. Copán is an ancient Maya city site. Large squares and building remains reveal how the city changed through different periods.

3. Archaeologists excavate sites and compare surviving traces. Even an abandoned city such as Copán can teach us about past life and architecture.

4. Copán has stone monuments bearing writing and imagery. Small surface records provide clues to Maya history alongside large buildings.

5. Draw separate plans for different periods of Copán. Comparing them reveals stages of alteration and growth rather than one permanently finished city.

Explorer words: Tegucigalpa · Copán · Maya civilisation · public squares · city remains · foundations · excavation · archaeologists · ancient city · urban change

Postcard scene: Copán

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hn/
- https://whc.unesco.org/en/list/129/

## Hungary · HU

Capital / seat: Budapest

1. Hungary is in Europe. Its capital is Budapest.

2. Budapest spreads along both banks of the Danube, with the Buda Castle Quarter and historic buildings. The river shapes its scenery and movement through the city.

3. Compare Budapest's Roman remains with architecture from later periods. Buildings surviving together reveal a city's long history of change.

4. Budapest’s Andrássy Avenue is part of its heritage property. A long urban street provides historical evidence alongside riverbanks and a castle district.

5. Find routes joining both sides of Budapest’s river. A waterway can divide urban areas, while bridges connect people and everyday spaces again.

Explorer words: Budapest · Danube · Buda Castle · Andrássy Avenue · Aquincum · Roman remains · riverbanks · Gothic architecture · cityscape · Hungarian Parliament

Postcard scene: Hungarian Parliament, Budapest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/hu/
- https://whc.unesco.org/en/list/400/

## Iceland · IS

Capital / seat: Reykjavik

1. Iceland is in Europe. Its capital is Reykjavik.

2. The outdoor assembly called the Althing began at Thingvellir in 930. Its historic site records where people gathered to make laws and settle disputes.

3. Traces of shelters made from turf and stone remain at Thingvellir. A meeting place can become important heritage even without a grand palace.

4. Compare Þingvellir’s outdoor assembly place with an indoor meeting room. Places for discussion and arrangements for listening can take several forms.

5. Þingvellir offers both cultural history and geology. Use a timeline for human activity and a drawing for terrain to organise different kinds of information.

Explorer words: Reykjavik · Thingvellir · Althing · open-air assembly · laws · assembly · turf and stone · historic shelters · farming remains · Reykjavík and aurora

Postcard scene: Reykjavík and aurora

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/is/
- https://whc.unesco.org/en/list/1152/

## India · IN

Capital / seat: New Delhi

1. India is in South Asia, and New Delhi is its capital.

2. The Himalayas rise in the north, and the Indian Ocean borders India to the south.

3. The Taj Mahal is a marble monument in the city of Agra.

4. Rani-ki-Vav in India is a well reached by descending steps. Stairways and several levels of space were designed to provide access to water below ground.

5. Rani-ki-Vav has detailed carvings on walls and pillars. Art within a water facility shows how a building’s practical purpose and beauty can develop together.

Explorer words: New Delhi · Taj Mahal · Himalayas · Ganges River · Bengal tiger · mango · samosa · Hindi · Diwali · yoga

Postcard scene: Taj Mahal

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/922/

## Indonesia · ID

Capital / seat: Jakarta

1. Jakarta is Indonesia’s capital. Nusantara, a planned future capital, is being built on the island of Borneo.

2. Indonesia stretches across many islands between the Indian and Pacific Oceans.

3. Borobudur on Java is an ancient Buddhist temple with stone stupas and story carvings.

4. Bali’s subak irrigation system channels water to rice fields. Farmers’ shared water management connects agriculture with cooperation within a community.

5. Bali’s rice terraces, channels and water temples form a cultural landscape. Land used to grow food can also embody practical knowledge and shared beliefs.

Explorer words: Jakarta · Nusantara · Java · Borobudur · Komodo dragon · volcanoes · nasi goreng · satay · Bahasa Indonesia · batik

Postcard scene: Borobudur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1194/

## Iran · IR

Capital / seat: Tehran

1. Iran is in Asia. Its capital is Tehran.

2. Persepolis was a capital of the Achaemenid Empire. Its great palaces stood on a raised terrace, displaying the skills of ancient builders.

3. The terrace beneath the palaces combines natural landforms with constructed sections. Ancient builders adapted the ground while creating their buildings.

4. Persepolis’s stairways have reliefs showing processions of people. Carved images provide evidence of social representations alongside the structure of a palace.

5. Mark Persepolis’s columns on a ground plan and side view. Their number, spacing and height offer different clues to the organisation of a large space.

Explorer words: Tehran · Persepolis · Achaemenid Empire · Darius I · palaces · raised terrace · ancient architecture · ruins · landforms · builders

Postcard scene: Persepolis

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ir/
- https://whc.unesco.org/en/list/114/

## Iraq · IQ

Capital / seat: Baghdad

1. Iraq is in Asia. Its capital is Baghdad.

2. Babylon was an important city of ancient Mesopotamia. Its walls, gates, palaces and temple remains reveal the structure of a large ancient city.

3. Villages and farming areas also surrounded Babylon. Ancient cities depended on nearby farmland as well as the buildings within their walls.

4. Locate Babylon separately from today’s capital, Baghdad. An ancient city and a present capital describe different places and historical settings.

5. Model Babylon’s walls and urban areas with simple shapes. Adding gates to enclosing walls explores the relationship between boundaries and movement.

Explorer words: Baghdad · Babylon · Mesopotamia · city walls · city gates · palaces · temples · farmland · ancient city · Ziggurat of Ur

Postcard scene: Ziggurat of Ur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/iq/
- https://whc.unesco.org/en/list/278/

## Ireland · IE

Capital / seat: Dublin

1. Ireland is in Europe. Its capital is Dublin.

2. Brú na Bóinne near the River Boyne contains prehistoric sites such as Newgrange, Knowth and Dowth. They display building and art using large stones.

3. These monuments reveal social life as well as funerary and religious practices. Buildings and objects can tell human stories even without written records.

4. Brú na Bóinne’s stones bear spirals and geometric designs. Record stone outlines separately from surface patterns to observe both construction material and artistic expression.

5. Newgrange invites study of sunlight direction in relation to an entrance. A paper model can explore how the path of light changes with time.

Explorer words: Dublin · Brú na Bóinne · River Boyne · Newgrange · Knowth · Dowth · prehistory · megalithic architecture · archaeology · Cliffs of Moher

Postcard scene: Cliffs of Moher

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ie/
- https://whc.unesco.org/en/list/659/

## Israel · IL

Capital / seat: Jerusalem

Israel’s government is based in Jerusalem, which it designates as its capital. The city’s international status is disputed.

1. Israel’s government is based in Jerusalem, which it designates as its capital. The city’s international status is disputed.

2. The Bahá'í holy places in Haifa include a shrine and surrounding gardens. Religious buildings and landscaped grounds are cared for together.

3. Bahá'í holy places are spread across Haifa and Western Galilee. Pilgrimage is a tradition of travelling to places that hold spiritual meaning.

4. Haifa’s gardens extend in terraces on sloping ground. A plan and side profile together explain both their arrangement and their elevation.

5. When studying Bahá’i holy places, distinguish a religious site from its whole city. One site name cannot describe every community and way of life around it.

Explorer words: Jerusalem · Haifa · Bahá'í Gardens · Shrine of the Báb · Acre · Western Galilee · gardens · shrine · pilgrimage · religious architecture

Postcard scene: Bahá’í Gardens and Shrine in Haifa

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/il/
- https://whc.unesco.org/en/list/1220/

## Italy · IT

Capital / seat: Rome

1. Rome is Italy’s capital, with many buildings from ancient times.

2. The Colosseum is a huge arena built in ancient Rome for public events.

3. Italy has a boot-shaped peninsula reaching into the Mediterranean Sea, plus many islands.

4. Venice stands on islands in a lagoon connected to the sea. Drawing islands and waterways in different colours reveals an urban network unlike streets on solid land.

5. Venice’s buildings and paintings preserve the work of generations of artists. Looking at architecture and interior art offers different ways to understand one city.

Explorer words: Rome · Colosseum · Leaning Tower of Pisa · Venice · Mediterranean Sea · pizza · pasta · gelato · Italian · Alps

Postcard scene: Colosseum

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/394/

## Ivory Coast · CI

Capital / seat: Yamoussoukro

1. Ivory Coast is in Africa. Its capital is Yamoussoukro.

2. Taï National Park protects an ancient tropical forest in West Africa. Its dense woods support many interconnected plants and animals.

3. Pygmy hippos and different monkeys live in Taï. Losing even a small habitat can make a big difference to the animals that depend on it.

4. Connect plants and plant-eating and meat-eating animals in a Taï forest diagram. Food relationships show how one animal’s life links with others.

5. Draw Taï’s high foliage, low plants and ground surface as layers. A forest provides three-dimensional living space beyond the area of its floor.

Explorer words: Yamoussoukro · Taï National Park · pygmy hippopotamus · monkeys · tropical forest · West Africa · plants · biodiversity · habitat protection · Basilica of Our Lady of Peace

Postcard scene: Basilica of Our Lady of Peace, Yamoussoukro

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ci/
- https://whc.unesco.org/en/list/195/

## Jamaica · JM

Capital / seat: Kingston

1. Jamaica is in Americas. Its capital is Kingston.

2. The Blue and John Crow Mountains are steep, forested uplands. Trails and settlements preserve traces of life in Maroon communities.

3. Maroons escaped enslavement and formed communities in the mountains. Forests supplied resources, while traditions such as songs and dances continued.

4. Jamaica’s mountain landscape preserves routes used by Maroon communities. Mapping paths with steep terrain helps explain the setting of their efforts to maintain freedom.

5. Study plants and birds in the Blue and John Crow Mountains. Forests holding cultural history are also habitats, connecting human stories with conservation.

Explorer words: Kingston · Blue Mountains · John Crow Mountains · Maroon communities · mountain forest · Nanny Town Heritage Route · mountain trails · freedom · traditional dances · forest resources

Postcard scene: Blue Mountains and Kingston coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jm/
- https://whc.unesco.org/en/list/1356/

## Japan · JP

Capital / seat: Tokyo

1. Japan is an island country in East Asia, and Tokyo is its capital.

2. Mount Fuji is Japan’s tallest mountain.

3. Japan has many islands and a network of fast Shinkansen trains.

4. Gassho-style houses in Shirakawa-go and Gokayama have steep thatched roofs. Their form developed in response to the snowy conditions of mountain villages.

5. Silkworm rearing was important in these villages. Linking mulberry leaves, silkworm cocoons and silk thread explains a route from plants to textile production.

Explorer words: Tokyo · Mount Fuji · five-story pagoda · cherry blossom · Hokkaido · sushi · ramen · Japanese · Shinkansen · origami

Postcard scene: Mount Fuji & Five-Story Pagoda

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/734/

## Jordan · JO

Capital / seat: Amman

1. Jordan is in Asia. Its capital is Amman.

2. Petra is an ancient city partly carved into rock. Built structures and carved rock faces stand together among mountains and narrow gorges.

3. Petra was a crossroads for caravan trade between regions. Travelling traders brought together goods, cultures and different building traditions.

4. Petra had systems for collecting and storing water. A diagram of this dryland city should connect buildings and trade routes with water management.

5. Draw a sequence from Petra’s narrow gorge into wider urban spaces. Views along a route provide different information from one photograph taken at a single point.

Explorer words: Amman · Petra · Nabataeans · rock-cut architecture · gorges · caravan trade · crossroads · Red Sea · Dead Sea · cultural exchange

Postcard scene: Petra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/jo/
- https://whc.unesco.org/en/list/326/

## Kazakhstan · KZ

Capital / seat: Astana

1. Kazakhstan is in Asia. Its capital is Astana.

2. Saryarka's grasslands and lakes provide resting places for migratory waterbirds. Birds travel between regions to find food and breeding grounds.

3. The Mausoleum of Khoja Ahmed Yasawi in Turkestan is a large Timurid building. Construction methods tried there later influenced work in other cities.

4. Distinguish migration stopovers from breeding periods at Saryarka’s lakes. A bird’s presence in one place does not always mean the same activity.

5. The Mausoleum of Khoja Ahmed Yasawi has a large dome and multiple spaces. An outline and a floor plan reveal different information about exterior form and internal arrangement.

Explorer words: Astana · Saryarka · steppe · lakes · migratory birds · wetlands · Turkestan · Yasawi Mausoleum · Timurid period · Baiterek Tower

Postcard scene: Baiterek Tower, Astana

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kz/
- https://whc.unesco.org/en/list/1102/
- https://whc.unesco.org/en/list/1103/

## Kenya · KE

Capital / seat: Nairobi

1. Nairobi is Kenya’s capital. Kenya has grasslands, mountains, large lakes and part of the Great Rift Valley.

2. Zebras and wildebeest move across the Maasai Mara grasslands during seasonal migrations.

3. Kiswahili and English are official languages in Kenya, and communities also speak many other languages.

4. Kenya’s Bogoria, Nakuru and Elementaita lakes support many waterbirds. Mapping lakes used by flamingos shows how a bird’s life can connect several places.

5. Lake Bogoria has hot springs and evidence of volcanic activity nearby. Heat within the Earth provides clues about the lake’s environment alongside its water and birds.

Explorer words: Nairobi · Maasai Mara · Mount Kenya · Great Rift Valley · wildebeest · giraffe · Kiswahili · ugali · track and field · Lake Victoria

Postcard scene: Maasai Mara

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1060/

## Kiribati · KI

Capital / seat: South Tarawa

1. Kiribati is in Oceania. Its capital is South Tarawa.

2. The Phoenix Islands Protected Area conserves coral islands and surrounding seas. Beneath the surface are seamounts and deep-water habitats.

3. Corals, fish and seabirds use the same ocean in different ways. Consider why conservation must protect wide areas of sea as well as islands.

4. Seamounts in the Phoenix Islands region are mountains beneath the sea. Adding underwater elevations to an island map reveals hidden terrain.

5. Compare seabirds with corals in the Phoenix Islands. Corals are animals too; living things within one marine environment do not all belong to the fish group.

Explorer words: South Tarawa · Phoenix Islands · coral islands · seamounts · corals · fish · seabirds · deep sea · marine protected area · Maneaba meeting house

Postcard scene: Maneaba meeting house

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ki/
- https://whc.unesco.org/en/list/1325/

## Kosovo · XK

Capital / seat: Pristina

1. Kosovo is in Europe. Its capital is Pristina.

2. Pristina's National Library collects materials such as books, newspapers and photographs. Preserving different records helps people learn about earlier life and culture.

3. The library also presents historical materials through digital collections. Paper records and digital resources are both ways to pass knowledge to others.

4. Kosovo’s National Library was founded in Prizren and later moved to Prishtina. Distinguishing present location from origin reveals movement within an institution’s history.

5. Book searches use information such as title and author. Preserving material connects with organising it so it can be found again.

Explorer words: Pristina · National Library in Pristina · books · newspapers · photographs · digital collections · cultural records · library · document preservation · Pristina and its surroundings

Postcard scene: Pristina and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://bkk-pjeterbogdani.rks-gov.net/en/

## Kuwait · KW

Capital / seat: Kuwait City

1. Kuwait is in Asia. Its capital is Kuwait City.

2. The rounded parts of the Kuwait Towers include water storage facilities. An eye-catching building can also help meet a city's everyday needs.

3. Water stored high above the ground can use gravity to flow downwards. Look for three-dimensional shapes, such as spheres and columns, in water towers.

4. Use Kuwait Towers to distinguish a sphere’s diameter from a column’s height. A round storage chamber and its long support are different three-dimensional forms.

5. Mark water entering and leaving a storage tower with different arrows. Changes in stored quantity depend on both incoming water and water used.

Explorer words: Kuwait City · Kuwait Towers · water storage · water reservoir · gravity · spheres · columns · city life · everyday architecture · water use

Postcard scene: Kuwait City waterfront and Kuwait Towers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.archnet.org/sites/135

## Kyrgyzstan · KG

Capital / seat: Bishkek

1. Kyrgyzstan is in Asia. Its capital is Bishkek.

2. Sulaiman-Too stands behind Osh at a crossroads of the Silk Roads. Travellers long used the mountain as an important landmark.

3. The mountain has caves, rock carvings and old places of worship. Images of people, animals and geometric forms record a long cultural history.

4. Sulaiman-Too has several peaks. Distinguishing the mountain’s name from individual peak locations connects the whole landform with its parts.

5. Add trade routes to a map of Osh and Sulaiman-Too. Linking urban paths with a prominent landform explores clues travellers could use for orientation.

Explorer words: Bishkek · Osh · Sulaiman-Too · Silk Roads · Fergana Valley · caves · petroglyphs · geometric patterns · landmark mountain · places of worship

Postcard scene: Sulaiman-Too Sacred Mountain in Osh

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kg/
- https://whc.unesco.org/en/list/1230/

## Laos · LA

Capital / seat: Vientiane

1. Laos is in Asia. Its capital is Vientiane.

2. Luang Prabang preserves Lao traditional buildings alongside European colonial architecture. Roofs and streets reveal how different cultures met.

3. Conserving an old town means caring for streets and neighbouring buildings, not just one monument. These connections shape Luang Prabang's distinctive townscape.

4. Luang Prabang stands where the Mekong and Nam Khan rivers meet. Drawing the town with both waterways connects its position with riverside terrain.

5. Compare Luang Prabang’s wooden structures with masonry buildings. Materials and construction skills provide clues alongside decoration when studying architectural traditions.

Explorer words: Vientiane · Luang Prabang · Lao traditional architecture · townscape · streets · roofs · cultural exchange · colonial period · architectural conservation · Pha That Luang

Postcard scene: Pha That Luang

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/la/
- https://whc.unesco.org/en/list/479/

## Latvia · LV

Capital / seat: Riga

1. Latvia is in Europe. Its capital is Riga.

2. Riga grew as a trading city of the Hanseatic League. Its old centre and later wooden buildings record the city's expansion.

3. Riga preserves many Art Nouveau buildings. Curves and decorations on their facades show that architecture can also be art.

4. When drawing Riga’s Art Nouveau buildings, distinguish façades from floor plans. An ornate exterior does not by itself reveal the arrangement of rooms inside.

5. Compare Riga’s wooden structures with decorated urban buildings. Recording material, style and construction period separately explains a city’s varied architecture more precisely.

Explorer words: Riga · historic Riga · Art Nouveau · Hanseatic League · wooden buildings · old town · facade · trade · curving decoration · Riga Art Nouveau architecture

Postcard scene: Riga Art Nouveau architecture

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lv/
- https://whc.unesco.org/en/list/852/

## Lebanon · LB

Capital / seat: Beirut

1. Lebanon is in Asia. Its capital is Beirut.

2. Baalbek preserves large temples built in Roman times. Their tall stone columns and scale offer clues to the building skills of the past.

3. Baalbek has roots in the Phoenician period and was once called Heliopolis. A city's names and buildings can preserve the history of different eras.

4. Label diameter and height separately when drawing Baalbek’s columns. Columns of equal height can differ in thickness, so study proportions in several directions.

5. Locate Baalbek separately from today’s capital, Beirut. Distinguishing an ancient site from a current capital connects a country’s history with its geography.

Explorer words: Beirut · Baalbek · Roman temples · stone columns · Phoenicia · Heliopolis · building skills · archaeological remains · city names · changing eras

Postcard scene: Baalbek Roman temple ruins

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lb/
- https://whc.unesco.org/en/list/294/

## Lesotho · LS

Capital / seat: Maseru

1. Lesotho is in Africa. Its capital is Maseru.

2. Lesotho's Sehlabathebe and a park in South Africa form the Maloti-Drakensberg Park. Protecting nature can bring neighbouring countries together across a border.

3. The park contains sandstone cliffs, caves and rock pools. Different habitats provide homes for plants, fish and birds such as the bearded vulture.

4. Maloti-Drakensberg’s rock paintings preserve San cultural expression. A natural park can also provide opportunities to study human art.

5. When mapping Lesotho’s highlands, distinguish altitude from slope. High elevation does not necessarily mean a pointed or steep landform.

Explorer words: Maseru · Sehlabathebe · Maloti-Drakensberg · sandstone cliffs · caves · rock pools · habitats · bearded vulture · cross-border cooperation · Maletsunyane Falls

Postcard scene: Maletsunyane Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ls/
- https://whc.unesco.org/en/list/985/

## Liberia · LR

Capital / seat: Monrovia

1. Liberia is in Africa. Its capital is Monrovia.

2. Sapo National Park protects tropical forest in Liberia. Pygmy hippopotamuses, chimpanzees and forest elephants are among the animals living there.

3. Protecting a forest means considering both wildlife and nearby communities. Local residents, forest authorities and conservation organisations work together to care for Sapo.

4. Compare Sapo’s pygmy hippos with forest elephants. Mammals sharing one forest can differ in body size and the living spaces they need.

5. Imagine recording a Sapo forest observation with its date and location. Knowing when and where an animal was seen allows comparison with later observations.

Explorer words: Monrovia · Sapo National Park · tropical forest · pygmy hippopotamus · chimpanzee · forest elephant · local communities · forest conservation · wildlife · shared stewardship

Postcard scene: Sapo National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.fauna-flora.org/projects/implementing-effective-management-sapo-national-park/

## Libya · LY

Capital / seat: Tripoli

1. Libya is in Africa. Its capital is Tripoli.

2. Leptis Magna flourished in Roman times. Its harbour, market, storehouses and residential remains reveal how people worked and lived.

3. Septimius Severus was born here and later became a Roman emperor. The city expanded under him, linking a person's history with changes in a town.

4. Leptis Magna also preserves a theatre. Comparing it with market spaces introduces places for exchange and recreation within an ancient city.

5. Imagine a route from Leptis Magna’s harbour through a market to homes. Tracing goods for daily use connects different urban functions.

Explorer words: Tripoli · Leptis Magna · Roman period · ancient harbour · market · storehouses · house remains · Septimius Severus · urban growth · archaeology

Postcard scene: Archaeological Site of Leptis Magna

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ly/
- https://whc.unesco.org/en/list/183/

## Liechtenstein · LI

Capital / seat: Vaduz

1. Liechtenstein is in Europe. Its capital is Vaduz.

2. Vaduz Castle stands on a hill above the capital. A castle on high ground offered a wide view of the surrounding roads and settlement.

3. The area around the castle offers views of the Rhine Valley. Comparing hills and valleys helps us think about how terrain influences where buildings stand.

4. Liechtenstein lies between Switzerland and Austria. Mapping its neighbours and the Rhine helps locate the small country within a wider region.

5. Draw Vaduz Castle’s hill and the lower town in profile. Nearby map locations can still differ in elevation and the distance needed to reach them.

Explorer words: Vaduz · Vaduz Castle · Rhine Valley · hills · castle · high ground · valleys · observing terrain · settlement landscape · building location

Postcard scene: Vaduz Castle and Alpine Rhine Valley

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://tourismus.li/en/activities/popular-sights-the-countryside/sights/?pn=6&sortBy=0
- https://en.tourismus.li/reiseland/unser-land/zahlen-fakten.html

## Lithuania · LT

Capital / seat: Vilnius

1. Lithuania is in Europe. Its capital is Vilnius.

2. Vilnius's historic centre includes Gothic, Renaissance and Baroque buildings. Comparing windows, roofs and decorations reveals changing tastes across different periods.

3. Vilnius preserves its medieval street layout. Historic streets and buildings show the city's long role as a centre of cultural life.

4. Vilnius combines religious buildings with everyday urban structures. Mapping uses separately reveals several functions within a historic city.

5. Record visible windows and roof features separately from style labels in Vilnius. Starting with observations makes the reasons for an architectural comparison easier to explain.

Explorer words: Vilnius · historic Vilnius · Gothic style · Renaissance · Baroque · medieval streets · windows · roofs · building decorations · Vilnius Old Town

Postcard scene: Vilnius Old Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lt/
- https://whc.unesco.org/en/list/541/

## Luxembourg · LU

Capital / seat: Luxembourg

1. Luxembourg is in Europe. Its capital is Luxembourg.

2. Luxembourg City preserves fortifications built and strengthened over different periods. Its important location led successive rulers to reshape its defences.

3. Parts of the fortifications were dismantled from 1867, but historic defences remain. Comparing them with the old town reveals how a city's uses can change.

4. Luxembourg City’s fortifications developed under successive rulers. Distinguishing a national border from a city’s defensive wall explains two different geographical extents.

5. Map Luxembourg’s surviving defences with its present streets. A former boundary can continue within everyday urban life in a different form.

Explorer words: Luxembourg · Luxembourg old town · fortifications · city walls · defences · strategic location · 1867 · historic architecture · changes of rule · urban change

Postcard scene: Luxembourg Old Quarters and Fortifications

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lu/
- https://whc.unesco.org/en/list/699/

## Madagascar · MG

Capital / seat: Antananarivo

1. Madagascar is in Africa. Its capital is Antananarivo.

2. Madagascar's tsingy are landscapes of sharp limestone pinnacles. Water slowly dissolves and wears away the rock, creating an unusual stone forest.

3. The Andrefana Dry Forests shelter lemurs and many birds. Protecting forests, wetlands and mangroves also protects the living things that depend on them.

4. Madagascar’s lemurs are primates. Distinguishing birds from mammals shows how animals in one forest can belong to different biological groups.

5. Draw Tsingy’s pointed rocks separately from forest trees. Studying where rock terrain meets living plants connects landforms with wildlife shelter.

Explorer words: Antananarivo · tsingy · limestone · stone forest · Andrefana Dry Forests · lemurs · mangroves · wetlands · erosion · Baobab landscape

Postcard scene: Baobab landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mg/
- https://whc.unesco.org/en/list/494/

## Malawi · MW

Capital / seat: Lilongwe

1. Malawi is in Africa. Its capital is Lilongwe.

2. Lake Malawi is home to many kinds of cichlid fish. Different food sources and habitats within one lake are associated with fish that have different characteristics.

3. Many Lake Malawi fish occur naturally only in this lake. A species restricted to one area is called endemic, so protecting its habitat is especially important.

4. Compare cichlid images from Lake Malawi by colour and body shape. Similar colour alone does not establish species identity; examine several features together.

5. Map fish habitats within Lake Malawi, distinguishing the whole lake from particular areas. Underwater conditions can vary with depth and the character of the bottom.

Explorer words: Lilongwe · Lake Malawi · cichlids · freshwater fish · endemic species · habitat · fish diets · lake ecosystem · biological diversity · habitat protection

Postcard scene: Lake Malawi

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mw/
- https://whc.unesco.org/en/list/289/

## Malaysia · MY

Capital / seat: Kuala Lumpur

Kuala Lumpur is the capital; Putrajaya is the administrative centre.

1. Kuala Lumpur is the capital; Putrajaya is the administrative centre.

2. Around Mount Kinabalu on Borneo, life ranges from lowland rainforest to high-mountain plants. Changes in altitude help explain differences in climate and vegetation.

3. Kinabalu Park has plants with connections to Southeast Asia, the Himalayas and other regions. Studying one mountain can reveal the history of how living things spread.

4. Mount Kinabalu is on Borneo, while Kuala Lumpur is on a different landmass. Locate island and peninsula places separately within Malaysia.

5. Arrange Kinabalu’s plants by elevation in a diagram. Adding location information to plant names connects mountain environments with the distribution of life.

Explorer words: Kuala Lumpur · Mount Kinabalu · Borneo · rainforest · altitude · mountain climate · plants · Himalayas · species distribution · Petronas Twin Towers

Postcard scene: Petronas Twin Towers

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/my/
- https://whc.unesco.org/en/list/1012/

## Maldives · MV

Capital / seat: Malé

1. Maldives is in Asia. Its capital is Malé.

2. Hukuru Miskiy in Malé is an old mosque built with coral stone. Patterns carved into the stone show craftsmanship developed in these ocean islands.

3. Traditional Maldivian mosques also use timber columns, roofs and lacquer decoration. Seeing how materials work together connects the study of architecture with crafts.

4. Draw a Maldivian mosque’s columns, roof and walls separately. Marking where wood and coral stone are used reveals different roles within one structure.

5. The Coral Stone Mosques of Maldives appear on a World Heritage Tentative List. Distinguish nomination from inscription while recognising the value of study and preservation.

Explorer words: Malé · Hukuru Miskiy · coral stone · stone carving · timber columns · roofs · lacquerwork · traditional mosques · craftspeople · Maldivian atoll

Postcard scene: Maldivian atoll

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://visitmaldives.com/en/experience/mosques-in-maldives-a-standing-testament-to-the-local-craftsmanship
- https://whc.unesco.org/en/tentativelists/5812/

## Mali · ML

Capital / seat: Bamako

1. Mali is in Africa. Its capital is Bamako.

2. Timbuktu was long a centre of learning. Sankore and its historic mosques preserve the story of a city where people studied and shared knowledge.

3. Timbuktu's heritage needs to be understood alongside its desert setting. UNESCO identifies risks from desertification, showing why both the environment and cultural heritage need care.

4. Timbuktu connects with exchanges across the Sahara and Sahel. Study its surrounding environments and movement routes alongside the city’s name.

5. Timbuktu’s historic buildings need continuing care. Distinguish a single repair from observing and maintaining a structure over many years.

Explorer words: Bamako · Timbuktu · Sankore · centre of learning · sharing knowledge · historic mosques · desert · desertification · heritage conservation · Great Mosque of Djenné

Postcard scene: Great Mosque of Djenné

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ml/
- https://whc.unesco.org/en/list/119/

## Malta · MT

Capital / seat: Valletta

1. Malta is in Europe. Its capital is Valletta.

2. Valletta brings together fortifications, palaces and churches. Historic buildings stand close together, allowing a small area to reveal the history of different periods.

3. The Order of St John played an important role in Valletta's history. The city's fortifications show how architecture was used to protect a harbour and its settlement.

4. Valletta is the capital on Malta’s main island. Distinguishing country, island and city reveals relationships between a whole territory and its parts.

5. Mark Valletta’s walls and entrances on a plan. Considering enclosing boundaries together with passages reveals the organisation of defensive structures.

Explorer words: Valletta · city walls · fortifications · palaces · churches · Order of St John · harbour · defensive architecture · urban history · Valletta Grand Harbour

Postcard scene: Valletta Grand Harbour

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mt/
- https://whc.unesco.org/en/list/131/

## Marshall Islands · MH

Capital / seat: Majuro

1. Marshall Islands is in Oceania. Its capital is Majuro.

2. Marshallese navigators travelled between islands by observing waves and winds. Charts made with palm strips and shells helped them learn patterns of ocean movement.

3. These charts did not show distances at an exact scale like a paper map. Navigators studied them on land, then used experience and observation to find their way at sea.

4. Shells can represent islands in Marshallese navigation charts. Distinguishing a real island from its small symbol introduces how marks communicate information.

5. Curved elements in navigation charts express relationships in wave patterns. Compare measuring distances on a map with learning characteristics of moving seas.

Explorer words: Majuro · navigation charts · palm strips · shells · waves · winds · navigators · canoes · scale · Majuro Atoll

Postcard scene: Majuro Atoll

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mh/
- https://ocean.si.edu/human-connections/history-cultures/navigating-waters-micronesian-stick-charts

## Mauritania · MR

Capital / seat: Nouakchott

1. Mauritania is in Africa. Its capital is Nouakchott.

2. Banc d'Arguin National Park combines dunes, shallow seas and coastal wetlands. Many migratory birds stop there to feed or rest.

3. Migratory birds travel between distant regions with the seasons. Protecting resting wetlands supports journeys that extend beyond the borders of any one country.

4. Connect Banc d’Arguin’s waterbirds with food sources in a diagram. Shallow water and mudflats matter for feeding alongside places used for resting.

5. Draw Banc d’Arguin’s desert and marine sides together. Neighbouring environments can support different life because water and vegetation conditions differ.

Explorer words: Nouakchott · Banc d'Arguin · migratory birds · coastal wetlands · shallow seas · dunes · seasonal migration · bird feeding · resting sites · wetland conservation

Postcard scene: Banc d’Arguin

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mr/
- https://whc.unesco.org/en/list/506/

## Mauritius · MU

Capital / seat: Port Louis

1. Mauritius is in Africa. Its capital is Port Louis.

2. Le Morne is a rocky mountain overlooking the sea. People escaping enslavement once sought refuge there, making it a place that remembers the search for freedom.

3. Stories about Le Morne have also survived through memory and oral tradition. Studying history includes listening to these stories and respecting people's dignity.

4. Le Morne is a mountain in Mauritius, separate from the capital, Port Louis. Locate a historically meaningful landform separately from an administrative centre.

5. When reading Le Morne’s oral traditions, record who transmitted an account. Studying historical evidence includes its source and means of transmission alongside its content.

Explorer words: Port Louis · Le Morne · rocky mountain · Indian Ocean · refuge · freedom · oral tradition · memory · human dignity · learning history

Postcard scene: Le Morne Cultural Landscape

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mu/
- https://whc.unesco.org/en/list/1259/

## Mexico · MX

Capital / seat: Mexico City

1. Mexico City, Mexico’s capital, sits high in a valley surrounded by mountains.

2. Chichén Itzá was an ancient Maya city, with a great stone pyramid called El Castillo.

3. Maize is used in many Mexican foods, and many Indigenous languages and cultures continue today.

4. Sian Ka’an includes tropical forest, mangroves and wetlands. Mapping water and vegetation together reveals varied environments where land meets sea.

5. Sian Ka’an also protects coral reefs offshore. Connecting forest and sea through water movement helps explain why different habitats are conserved together.

Explorer words: Mexico City · Chichén Itzá · Yucatán Peninsula · Copper Canyon · monarch butterfly · maize · tacos · Spanish · Nahuatl · mariachi

Postcard scene: Chichén Itzá

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/410/

## Micronesia · FM

Capital / seat: Palikir

1. Micronesia is in Oceania. Its capital is Palikir.

2. Nan Madol on Pohnpei is a historic settlement built on small artificial islands. Channels run between islands constructed with basalt and coral materials.

3. Nan Madol preserves remains of palaces and ceremonial places used by past leaders. Its layout reveals an approach to building a settlement alongside the sea.

4. Nan Madol’s basalt is a rock associated with volcanic processes. Studying its material connects the construction of artificial islets with the natural setting.

5. Arrange a model of Nan Madol’s islets and channels. Understanding its layout involves routes between islands as well as the buildings placed on them.

Explorer words: Palikir · Nan Madol · Pohnpei · artificial islands · basalt · coral materials · channels · historic palaces · ceremonial places · island layout

Postcard scene: Nan Madol

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/fm/
- https://whc.unesco.org/en/list/1503/

## Moldova · MD

Capital / seat: Chișinău

1. Moldova is in Europe. Its capital is Chișinău.

2. Moldova has a survey point in the Struve Geodetic Arc. Measurements linking points across several countries in triangles helped scientists study Earth's size and shape.

3. This survey was a nineteenth-century scientific collaboration across countries. Triangles help us explore how careful measurement contributes to making accurate maps.

4. The Struve Geodetic Arc links many survey points. Distinguish one point in Moldova from the whole network extending across several countries.

5. Draw a surveying triangle and label angles and sides. Using measurements to determine other lengths helps create maps across long distances.

Explorer words: Chișinău · Struve Geodetic Arc · surveying · triangles · survey points · Earth's size · mapmaking · 19th century · scientific cooperation · Old Orhei

Postcard scene: Old Orhei

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/md/
- https://whc.unesco.org/en/list/1187/

## Monaco · MC

Capital / seat: Monaco

1. Monaco is in Europe. Its capital is Monaco.

2. Monaco's Oceanographic Museum introduces marine life and ocean research. Observing aquarium animals can be a starting point for learning about habitats beneath the sea.

3. The museum presents both ocean nature and conservation. When exploring an exhibit, ask not only an animal's name but also where it lives and what it needs.

4. Monaco’s Oceanographic Museum has also presented digital marine experiences. Comparing a represented sea with an aquarium reveals different ways to communicate one subject.

5. Record an organism’s name separately from behaviour observed in museum material. Identifying a species and exploring how it lives are connected parts of learning.

Explorer words: Monaco · Oceanographic Museum of Monaco · aquarium · ocean research · marine life · habitats · Mediterranean Sea · conservation · observation · Monaco harbor and Mediterranean coast

Postcard scene: Monaco harbor and Mediterranean coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://musee.oceano.org/en/

## Mongolia · MN

Capital / seat: Ulaanbaatar

1. Ulaanbaatar is Mongolia’s capital. The Orkhon Valley preserves the history of herding communities, old cities and monasteries.

2. Naadam is a Mongolian festival celebrating traditional horse racing, wrestling and archery.

3. The morin khuur is a two-stringed instrument decorated with a horse’s head. A bow makes its strings sound.

4. The Orkhon Valley includes the ruins of Karakorum, an earlier Mongol capital. Mapping it separately from Ulaanbaatar shows how capital locations can change over time.

5. The Orkhon Valley’s river and grasslands have long supported pastoral life. Link grazing land, water and movement routes to explore a cultural landscape.

Explorer words: Ulaanbaatar · Orkhon Valley · Erdene Zuu Monastery · grasslands · nomadic herding · Naadam · horse racing · wrestling · archery · morin khuur

Postcard scene: Gobi landscape and ger

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mn/
- https://whc.unesco.org/en/list/1081/
- https://ich.unesco.org/en/RL/naadam-mongolian-traditional-festival-00395
- https://ich.unesco.org/en/RL/traditional-music-of-the-morin-khuur-00068

## Montenegro · ME

Capital / seat: Podgorica

1. Montenegro is in Europe. Its capital is Podgorica.

2. Kotor is a historic harbour town in an Adriatic bay. Its walls, churches and old buildings reveal a history of trade and cultural life.

3. Kotor's heritage was restored after serious damage in the 1979 earthquake. Caring for old buildings involves using historical evidence alongside building skills.

4. Draw Kotor’s bay alongside the mountains behind it. A town between sea and high ground links harbour routes with the surrounding slopes.

5. Caring for heritage after an earthquake begins with recording surviving structures and damage. Kotor’s restoration history introduces the sequence of investigation and repair.

Explorer words: Podgorica · Kotor · Adriatic Sea · Bay of Kotor · harbour town · city walls · historic churches · earthquake · heritage restoration · Kotor region

Postcard scene: Kotor region

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/me/
- https://whc.unesco.org/en/list/125/

## Morocco · MA

Capital / seat: Rabat

1. Morocco’s capital, Rabat, is a coastal city looking out to the Atlantic Ocean.

2. Morocco has the Atlas Mountains, the Sahara, and coasts on the Atlantic and Mediterranean.

3. Arabic and Amazigh are official languages of Morocco.

4. Aït-Ben-Haddou groups earthen houses within defensive walls. Its walls and roofs show how local building materials shape a settlement.

5. Colour homes and shared spaces differently on an Aït-Ben-Haddou plan. Distinguishing household areas from community spaces reveals aspects of village life.

Explorer words: Rabat · Marrakech · Koutoubia Mosque · Atlas Mountains · Sahara Desert · Amazigh · Arabic · couscous · mint tea · zellij tilework

Postcard scene: Marrakech & Koutoubia Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/444/

## Mozambique · MZ

Capital / seat: Maputo

1. Mozambique is in Africa. Its capital is Maputo.

2. The Island of Mozambique was an important port in Indian Ocean trade. Its buildings record encounters between people travelling by sea from different regions.

3. The island combines stone-and-lime buildings with homes using wood and plant materials. Local resources and ways of living help shape the appearance of houses.

4. The Island of Mozambique shares the country’s name but is not its whole territory. Map it separately from the present capital, Maputo.

5. Use colours to distinguish building materials on Mozambique Island. Comparing masonry with wood and plant materials connects houses with environment and technical choices.

Explorer words: Maputo · Island of Mozambique · Indian Ocean trade · historic port · stone buildings · lime · wood materials · macuti houses · cultural encounters · Maputo railway station

Postcard scene: Maputo railway station

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mz/
- https://whc.unesco.org/en/list/599/

## Myanmar · MM

Capital / seat: Naypyidaw

1. Myanmar is in Asia. Its capital is Naypyidaw.

2. Bagan is a historic city near the Ayeyarwady River. Its temples, stupas, murals and sculptures reveal the religious and artistic life of earlier communities.

3. Bagan was a major royal centre, especially in the eleventh to thirteenth centuries. Distinguishing it from today's capital, Naypyidaw, shows how a city's role changes over time.

4. Bagan includes temple buildings with interior spaces and stupa forms viewed from outside. Comparing exterior form with internal space explores different architectural uses.

5. Represent one Bagan theme as a painting and a sculpture. Colour on a surface and three-dimensional form can express related stories in different ways.

Explorer words: Naypyidaw · Bagan · Ayeyarwady River · temples · stupas · murals · sculpture · 11th–13th centuries · historic kingdom · roles of cities

Postcard scene: Bagan

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mm/
- https://whc.unesco.org/en/list/1588/

## Namibia · NA

Capital / seat: Windhoek

1. Namibia is in Africa. Its capital is Windhoek.

2. The Namib Sand Sea is a landscape of dunes built by wind. Sand transported through rivers, the sea and wind helps form this desert landscape.

3. Fog is an important source of moisture in this coastal desert. Even where rain is scarce, plants and animals can adapt to obtain the water they need.

4. Wind moves sand and reshapes dunes in the Namib. Comparing dunes with rocky mountains reveals different materials and processes behind elevated landforms.

5. Fog is an important water source for life in the coastal Namib. Low rainfall does not exclude other ways for organisms to obtain water.

Explorer words: Windhoek · Namib Sand Sea · sand dunes · wind · fog · moisture · sand transport · coastal desert · adaptation · Sossusvlei

Postcard scene: Sossusvlei

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/na/
- https://whc.unesco.org/en/list/1430/

## Nauru · NR

Capital / seat: Yaren

Nauru has no official capital. The map shows Yaren, the district where government offices are located.

1. Nauru has no official capital. The map shows Yaren, the district where government offices are located.

2. Nauru is a small island country surrounded by coral reef. Compare the coastal strip where many people live with the land in the island's interior.

3. Phosphate mining has greatly changed the island's interior. It shows how extracting resources can reshape nature and raises questions about caring for the land.

4. Represent Nauru as an island outline and as national territory. An island describes a landform, while a country describes a political unit governed by people.

5. Map land uses along Nauru’s coast and in its interior. Comparing settlement areas with resource-extraction areas explores different functions within one island.

Explorer words: Yaren · coral reef · coastal strip · island interior · phosphate · resource extraction · landscape change · environmental care · Pacific Ocean · Buada Lagoon

Postcard scene: Buada Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thecommonwealth.org/our-member-countries/nauru
- https://thecommonwealth.org/our-member-countries/naeoro

## Nepal · NP

Capital / seat: Kathmandu

1. Nepal is in Asia. Its capital is Kathmandu.

2. The Kathmandu Valley includes historic palace squares in Kathmandu, Patan and Bhaktapur. Buildings and sculptures reveal the art and history developed in these towns.

3. The valley contains Buddhist stupas at Swayambhu and Boudhanath and a Hindu temple at Pashupati. One region can teach us to recognise and respect different religious traditions.

4. Kathmandu Valley’s heritage also includes urban spaces in Patan and Bhaktapur. It extends across several cities, beyond the capital sharing its name.

5. Kathmandu Valley has temples with tiered roofs. Drawing lower and upper outlines in sequence helps compare layered forms and overall proportions.

Explorer words: Kathmandu · Kathmandu Valley · Patan · Bhaktapur · palace squares · Swayambhu · Boudhanath · Pashupati · Buddhism · Hinduism

Postcard scene: Swayambhunath

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/np/
- https://whc.unesco.org/en/list/121/

## Netherlands · NL

Capital / seat: Amsterdam

Amsterdam is the capital, while the government and parliament are in The Hague.

1. Amsterdam is the capital of the Netherlands. The government and parliament are based in The Hague.

2. Kinderdijk’s windmills and channels helped drain low-lying land. The windmills are part of a water-management system.

3. Amsterdam has a ring of canals lined with historic houses and streets.

4. Kinderdijk manages water through windmills, dikes, pumps and sluices. A connected-system drawing explains more than studying one device alone.

5. Kinderdijk has round brick mills and octagonal mill structures. Comparing them shows how facilities serving similar purposes can use different forms and materials.

Explorer words: Amsterdam · The Hague · Kinderdijk · windmills · canals · dykes · polders · water management · bicycles · Dutch

Postcard scene: Amsterdam canals

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/nl/
- https://whc.unesco.org/en/list/818/
- https://whc.unesco.org/en/list/1349/
- https://www.holland.com/de/tourist/lass-dich-inspirieren

## New Zealand · NZ

Capital / seat: Wellington

1. New Zealand’s capital, Wellington, sits at the southern tip of the North Island by the sea.

2. Māori is one of New Zealand’s official languages.

3. The kiwi is a flightless bird native to New Zealand that is mostly active at night.

4. Tongariro includes mountains shaped by volcanic activity. Comparing summits and craters reveals variety within a volcanic landscape.

5. Tongariro’s mountains hold deep cultural meaning for Māori communities. Learning about them includes people’s relationships with the land as well as rocks and terrain.

Explorer words: Wellington · Milford Sound · Southern Alps · kiwi · Māori · Māori language · hāngī · silver fern · Fiordland · Wellington Cable Car

Postcard scene: Milford Sound

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/421/

## Nicaragua · NI

Capital / seat: Managua

1. Nicaragua is in Americas. Its capital is Managua.

2. León Cathedral was built during a transition from Baroque to Neoclassical architecture. A single building can contain features associated with more than one period.

3. The cathedral's interior has abundant natural light and restrained decoration. Compare the lighting with the decorated sanctuary ceiling to explore how architects shape a space.

4. León Cathedral followed a design by a Guatemalan architect. The movement of people and skills across borders can contribute to creating new buildings.

5. León Cathedral reminds us that interior space belongs to architecture too. Add movement routes to a drawing of walls and roofs to explore how space is used.

Explorer words: Managua · León Cathedral · Baroque · Neoclassicism · natural light · ceiling decoration · architectural styles · interior space · light in buildings · Ometepe Island

Postcard scene: Ometepe Island

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ni/
- https://whc.unesco.org/en/list/1236/

## Niger · NE

Capital / seat: Niamey

1. Niger is in Africa. Its capital is Niamey.

2. The Aïr and Ténéré reserves combine Saharan desert landscapes with volcanic-rock mountains. A desert is not just one endless sandy plain; it contains different landforms.

3. The Aïr mountains have climate and wildlife distinct from the surrounding desert. Comparing mountains and plains reveals how conditions for living things can differ.

4. Niger’s Aïr mountains and Ténéré desert reveal different landforms together. Drawing mountain and sandy areas separately shows variety within the Sahara.

5. Map wildlife locations alongside water sources in Aïr and Ténéré. Conditions for life can vary from place to place even within a broad desert region.

Explorer words: Niamey · Aïr mountains · Ténéré desert · Sahara · volcanic rock · sandy landforms · mountain climate · desert wildlife · comparing landforms · Aïr and Ténéré desert

Postcard scene: Aïr and Ténéré desert

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ne/
- https://whc.unesco.org/en/list/573/

## Nigeria · NG

Capital / seat: Abuja

1. Nigeria’s capital, Abuja, sits near Aso Rock, a huge granite outcrop.

2. The Niger and Benue rivers meet near Lokoja before the Niger flows south to the sea.

3. Nigeria is home to many languages, kinds of music and films. English is the official language.

4. Osun-Osogbo’s grove includes a river, shrines and sculptures. It shows connections between Yoruba religious traditions and natural spaces.

5. Artists at Osun-Osogbo have created new works drawing on tradition. Cultural heritage can include present-day creativity alongside the preservation of older objects.

Explorer words: Abuja · Aso Rock · Niger River · Benue River · Yoruba · Hausa · jollof rice · Nollywood · talking drum · cocoa

Postcard scene: Aso Rock

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1118/

## North Korea · KP

Capital / seat: Pyongyang

1. North Korea is in Asia. Its capital is Pyongyang.

2. Heaven Lake on Mount Paektu fills a large depression formed by volcanic activity. Such a depression is called a caldera, recording volcanic history in rock and water.

3. The Mount Paektu area contains hot springs, lava features and landforms shaped by glaciers. One mountain shows how heat inside Earth and moving ice can reshape landscapes.

4. The Mt Paektu UNESCO Global Geopark introduces volcanic landforms. A geopark supports learning about and caring for the Earth’s history and geological features.

5. Food culture in the Mt Paektu geopark region includes dishes using potato starch. Trace how a plant becomes an ingredient and then a prepared food.

Explorer words: Pyongyang · Mount Paektu · Heaven Lake · caldera · volcanic activity · hot springs · lava · glaciers · geothermal heat · Earth processes

Postcard scene: Mount Paektu and Heaven Lake

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kp/
- https://www.unesco.org/en/iggp/mt-paektu-unesco-global-geopark

## North Macedonia · MK

Capital / seat: Skopje

1. North Macedonia is in Europe. Its capital is Skopje.

2. Lake Ohrid shelters many aquatic species that occur naturally only in this region. Protecting this ancient lake's habitats helps conserve its distinctive wildlife.

3. The lakeside town of Ohrid preserves historic monasteries and religious paintings. The area's natural and cultural value lets us study the lake alongside the town.

4. Ohrid’s heritage extends across North Macedonia and Albania. Mapping shoreline and national borders reveals a shared natural landscape.

5. Ohrid’s icons are images with religious meaning. Comparing them with scientific drawings of aquatic life reveals different purposes and information within visual expression.

Explorer words: Skopje · Lake Ohrid · endemic species · aquatic wildlife · lake conservation · Ohrid · monasteries · religious paintings · nature and culture · Stone Bridge, Skopje

Postcard scene: Stone Bridge, Skopje

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/mk/
- https://whc.unesco.org/en/list/99/

## Norway · NO

Capital / seat: Oslo

1. Norway’s capital, Oslo, sits by the sea near forests and fjords.

2. A fjord is a long sea inlet formed when glaciers cut deep valleys that later filled with seawater.

3. In northern Norway, people can sometimes see the northern lights dancing across the night sky.

4. Urnes’s historic church is built of wood. Comparing it with stone churches shows how different building materials can create substantial spaces.

5. Urnes’s carvings depict animals and interlacing lines. Elements reused from an earlier church carry older craftsmanship into a later building.

Explorer words: Oslo · Geirangerfjord · northern lights · Svalbard · Scandinavian Mountains · Sámi people · salmon · brown cheese · Norwegian · reindeer

Postcard scene: Geirangerfjord

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/58/

## Oman · OM

Capital / seat: Muscat

1. Oman is in Asia. Its capital is Muscat.

2. Oman's aflaj are historic channels that carry spring or underground water to homes and fields. They use gravity to move water from higher to lower ground.

3. Sharing this water depended on cooperation within communities. The channels teach us about farming technology and agreements for fairly using a valuable resource.

4. Oman’s aflaj draw on groundwater, springs or surface water. Different sources can be channelled towards homes and agricultural land.

5. Label flow direction separately from water quantity in an Omani channel diagram. Arrows show direction, while distribution amounts require additional records.

Explorer words: Muscat · aflaj · water channels · springs · groundwater · gravity · farming · water sharing · community cooperation · Sultan Qaboos Grand Mosque

Postcard scene: Sultan Qaboos Grand Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/om/
- https://whc.unesco.org/en/list/1207/

## Pakistan · PK

Capital / seat: Islamabad

1. Pakistan’s capital, Islamabad, is a planned city below the Margalla Hills.

2. Faisal Mosque is known for its four tall minarets set against the hills.

3. The Indus River flows through Pakistan toward the Arabian Sea.

4. Mohenjo-Daro was a planned city of the Indus civilisation. Studying homes and streets reveals design at the scale of a whole settlement.

5. Mohenjo-Daro preserves evidence of wells, bathing spaces and drainage. Draw separate routes for bringing water in and carrying used water away.

Explorer words: Islamabad · Faisal Mosque · Margalla Hills · Indus River · K2 · truck art · Urdu · mango · biryani · markhor

Postcard scene: Faisal Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/138/

## Palau · PW

Capital / seat: Ngerulmud

1. Palau is in Oceania. Its capital is Ngerulmud.

2. Palau's Rock Islands include mushroom-shaped limestone islands and coral reefs. Different habitats among the islands and reefs provide homes for varied marine life.

3. Some islands contain marine lakes separated from the ocean by land. Comparing isolated habitats helps us explore how living things adapt to different conditions.

4. Palau’s Rock Islands have been shaped by weather, vegetation and other influences. An island continues to experience natural processes after its formation.

5. Distinguish wooded tops from water edges in a Rock Islands drawing. One small island can contain several kinds of space used by living things.

Explorer words: Ngerulmud · Rock Islands · limestone islands · coral reefs · lagoon · marine lakes · marine life · habitats · isolated environments · adaptation

Postcard scene: Rock Islands Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pw/
- https://whc.unesco.org/en/list/1386/

## Palestine · PS

Capital / seat: Ramallah

Palestine claims East Jerusalem as its capital; Ramallah is its administrative centre.

1. Palestine claims East Jerusalem as its capital; Ramallah is its administrative centre.

2. Tell es-Sultan at ancient Jericho is a mound of layered remains left by people. Its wall and tower preserve evidence of an early settled community.

3. The spring of 'Ain es-Sultan lies beside the site. Connecting a reliable water source with a lasting settlement helps us explore the history of people settling in one place.

4. Tell es-Sultan lies northwest of present-day Jericho. Distinguish an ancient settlement from the modern city by both period and location.

5. Label periods on a layered paper model of Jericho. Comparing find depth with production date introduces questions about the chronological order of archaeological evidence.

Explorer words: Ramallah · Ancient Jericho · Tell es-Sultan · archaeological layers · 'Ain es-Sultan spring · ancient wall · stone tower · settled life · community · archaeology

Postcard scene: Ancient Jericho / Tell es-Sultan

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ps/
- https://whc.unesco.org/en/list/1687/

## Panama · PA

Capital / seat: Panama City

1. Panama is in Americas. Its capital is Panama City.

2. The Panama Canal links the Atlantic and Pacific oceans. Ships use locks, chambers with changing water levels, to travel between an elevated lake and sea level.

3. Filling a lock raises a floating ship with the water; emptying it lowers the ship. The canal is an engineering system that uses buoyancy and gravity.

4. Panama Canal lock gates divide water chambers. Arranging a ship’s passage in sequence shows how several mechanisms operate in a coordinated order.

5. The Panama Canal’s original locks have paired lanes. Distinguishing elevation steps from traffic lanes helps explain their arrangement accurately.

Explorer words: Panama City · Panama Canal · locks · Atlantic Ocean · Pacific Ocean · Gatun Lake · water level · buoyancy · gravity · engineering

Postcard scene: Panama Canal locks

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pa/
- https://pancanal.com/en/design-of-the-locks/

## Papua New Guinea · PG

Capital / seat: Port Moresby

1. Papua New Guinea is in Oceania. Its capital is Port Moresby.

2. The Kuk site in New Guinea's highlands preserves evidence of early farming. Archaeologists have found raised cultivation areas and ditches dug to drain wet ground.

3. Kuk helps researchers study the development from gathering or using plants to farming. Ditches and changes in soil can reveal how people transformed their way of life.

4. Kuk lies in Papua New Guinea’s highlands. Wetlands can exist on high inland terrain as well as near a coast.

5. Kuk’s ditch remains invite comparison between bringing water in and draining it away. Farming water management includes collection and preventing excessive accumulation.

Explorer words: Port Moresby · Kuk Early Agricultural Site · New Guinea highlands · early farming · raised cultivation areas · drainage ditches · wetlands · soil evidence · archaeology · Parliament Haus, Port Moresby

Postcard scene: Parliament Haus, Port Moresby

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/pg/
- https://whc.unesco.org/en/list/887/

## Paraguay · PY

Capital / seat: Asunción

1. Paraguay is in Americas. Its capital is Asunción.

2. Trinidad and Jesús de Tavarangue preserve seventeenth- and eighteenth-century mission settlements. Homes, schools and workshops, as well as churches, reveal community life.

3. The sites' architecture and art combine Indigenous elements with European styles. Studying these cultural encounters also means learning about the experiences of Indigenous people.

4. Paraguay’s Jesuit missions connect with sites in present-day Argentina and Brazil. Distinguish historical activity areas from modern national borders.

5. Use a consistent scale when drawing Paraguay’s mission building plans. A large space can be reduced onto paper while preserving relationships between its parts.

Explorer words: Asunción · Trinidad mission ruins · Jesús de Tavarangue · 17th–18th centuries · historic schools · workshops · Indigenous culture · cultural encounters · architectural styles · Itaipu Dam

Postcard scene: Itaipu Dam

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/py/
- https://whc.unesco.org/en/list/648/

## Peru · PE

Capital / seat: Lima

1. Peru’s capital, Lima, is on the Pacific coast; the Andes and Amazon rainforest also reach across Peru.

2. Machu Picchu is an old city built high in the Andes by the Inca people.

3. Potatoes were cultivated in the Andes long ago, and Peru grows many different kinds.

4. Machu Picchu has terraces and stone walls along mountain slopes. A layered paper model can show how level spaces are created on sloping terrain.

5. Machu Picchu’s setting connects the Andes with forests of the upper Amazon region. Studying both ruins and woodland reveals the importance of a heritage site’s natural surroundings.

Explorer words: Lima · Machu Picchu · Andes Mountains · Amazon River · alpaca · potato · ceviche · Quechua · Nazca Lines · quinoa

Postcard scene: Machu Picchu

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/274/

## Philippines · PH

Capital / seat: Manila

1. The Philippines’ capital, Manila, sits beside Manila Bay on the island of Luzon.

2. The Banaue Rice Terraces follow mountain slopes and show generations of Ifugao farming knowledge.

3. The Philippines is a country of thousands of islands in the western Pacific.

4. Puerto-Princesa’s underground river passes through a cave towards the sea. Tracing it connects higher ground, underground spaces and the coast.

5. Tides influence the lower part of this underground river. Water inside a cave can be connected with changes in the sea outside.

Explorer words: Manila · Banaue Rice Terraces · Ifugao people · Luzon · jeepney · mango · adobo · tarsier · Filipino · Pacific Ocean

Postcard scene: Banaue Rice Terraces

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/652/

## Poland · PL

Capital / seat: Warsaw

1. Poland’s capital, Warsaw, stretches along both sides of the Vistula River.

2. Much of Warsaw’s Old Town was rebuilt after World War II.

3. European bison live in Poland’s Białowieża Forest.

4. Malbork Castle is a large brick structure. Repeated small bricks forming walls and arches show how individual parts create a larger whole.

5. Malbork’s conservation involved studying and repairing historic fabric. Distinguishing original remains from later restoration helps explain a building’s passage through time.

Explorer words: Warsaw · Warsaw Old Town · Royal Castle · Vistula River · Białowieża Forest · European bison · pierogi · Chopin · Polish · Baltic Sea

Postcard scene: Warsaw Old Town & Royal Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/847/

## Portugal · PT

Capital / seat: Lisbon

1. Portugal’s capital, Lisbon, stands on hills near the mouth of the Tagus River.

2. Belém Tower was built in the early 1500s to help guard Lisbon’s riverfront.

3. Portugal makes cork, used for bottle stoppers, from the bark of cork oak trees.

4. Vineyards extend across the slopes of Alto Douro. A landscape shaped through farming on natural terrain is an example of a cultural landscape.

5. Connect Alto Douro’s villages, farmland and routes in a drawing. A farming landscape links places where people live, work and move.

Explorer words: Lisbon · Belém Tower · Tagus River · azulejo tiles · yellow tram · cork oak · pastel de nata · Atlantic Ocean · Portuguese · Madeira

Postcard scene: Belém Tower

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1046/

## Qatar · QA

Capital / seat: Doha

1. Qatar is in Asia. Its capital is Doha.

2. Al Zubarah was a coastal town known for pearling and trade. Its harbour and residential remains reveal connections made between regions through the sea.

3. Wind-blown desert sand covered and protected remains of streets and buildings. Archaeologists study homes and channels beneath the sand to understand the past town.

4. Al Zubarah was founded by merchants from Kuwait. People crossing the sea to establish a town illustrate connections between ports, movement and trade.

5. Arrange Al Zubarah’s growth and decline in sequence. Its surviving remains represent stages of change rather than a city that always looked the same.

Explorer words: Doha · Al Zubarah · pearling · coastal trade · historic harbour · desert sand · house remains · historic canal · excavation · maritime connections

Postcard scene: Al Zubarah Archaeological Site

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/qa/
- https://whc.unesco.org/en/list/1402/

## Republic of Korea · KR

Capital / seat: Seoul

1. South Korea is in East Asia, on the southern part of the Korean Peninsula. Seoul is its capital.

2. Hangul was developed under King Sejong and introduced in 1446.

3. In Seoul, you can see the tiled roofs of Bukchon Hanok Village and N Seoul Tower together.

4. Jongmyo in Seoul is a wooden shrine holding ancestral tablets of the Joseon royal family. Its long buildings and surrounding woodland form a setting for royal ancestral rituals.

5. Jongmyo’s ritual tradition includes music and dance. Preserving its buildings connects with people learning the sounds and movements that keep a tradition alive.

Explorer words: Seoul · N Seoul Tower · Bukchon Hanok Village · Jeju Island · Hallasan · kimchi · bibimbap · Hangul · hanbok · taekwondo

Postcard scene: N Seoul Tower & Bukchon Hanok Village

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/738/

## Republic of the Congo · CG

Capital / seat: Brazzaville

1. Republic of the Congo is in Africa. Its capital is Brazzaville.

2. Odzala-Kokoua brings together forests, savannas and other ecosystems. Comparing grassland and forest reveals different habitats for living things.

3. The area is important for forest elephants and diverse primates in Central Africa. It also records how forests spread and change, helping researchers study natural history.

4. Mark the edges where Odzala-Kokoua’s forests meet grasslands. Habitat connections matter for wildlife alongside the amount of space available.

5. When reading about Congolese forests, distinguish the Republic of the Congo from the Democratic Republic of the Congo. Similar names describe separate neighbouring states.

Explorer words: Brazzaville · Odzala-Kokoua · forest elephants · primates · savanna · tropical forest · ecosystems · forest succession · habitats · Sangha forest landscape in the Republic of the Congo

Postcard scene: Sangha forest landscape in the Republic of the Congo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/cg/
- https://whc.unesco.org/en/list/692/

## Romania · RO

Capital / seat: Bucharest

1. Romania is in Europe. Its capital is Bucharest.

2. The Danube reaches the Black Sea through a delta of channels and wetlands. Sediment carried by a river can build up and reshape the land at its mouth.

3. Lakes and marshes in the Danube Delta shelter many birds and freshwater fish. Protecting this connected landscape helps conserve life between river and sea.

4. Compare branching channels in the Danube Delta with a river confluence. Joining and dividing watercourses represent different flow arrangements.

5. Draw the Danube Delta’s birds above water and freshwater fish below it. Including less visible aquatic life gives a fuller view of the habitat.

Explorer words: Bucharest · Danube Delta · Danube River · Black Sea · delta · sediment · river mouth · wetlands · freshwater fish · Bran Castle

Postcard scene: Bran Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ro/
- https://whc.unesco.org/en/list/588/

## Russia · RU

Capital / seat: Moscow

1. Moscow is Russia’s capital. Russia is a very large country that spans Europe and Asia.

2. Lake Baikal in Siberia is the world’s deepest lake and holds a great deal of fresh water.

3. The Trans-Siberian Railway travels a very long distance from Moscow toward eastern Russia.

4. The Altai mountain region includes headwaters of the Ob and Irtysh. Trace how waterways beginning in mountains connect with distant areas.

5. The Altai includes lakes, high plateaus and mountain terrain. Elevation and water location help create different spaces for living things within one region.

Explorer words: Moscow · Saint Basil’s Cathedral · Red Square · Lake Baikal · Siberia · taiga · matryoshka doll · Russian · ballet · Trans-Siberian Railway

Postcard scene: Saint Basil’s Cathedral

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/768/

## Rwanda · RW

Capital / seat: Kigali

1. Rwanda is in Africa. Its capital is Kigali.

2. Nyungwe National Park contains rainforest, peat bogs and grassland. Its varied environments support trees, ferns and wildlife living together.

3. Nyungwe is important for chimpanzees and many birds. Losing forest changes food supplies and homes, so protecting animals also means caring for their habitats.

4. Nyungwe’s heritage includes Cyamudongo, Gisakura and Nyungwe forests. Distinguish the whole property from the separate areas within it.

5. Nyungwe supports endemic species with restricted natural distributions. Knowing where organisms occur, alongside how many there are, helps explain a forest’s conservation value.

Explorer words: Kigali · Nyungwe National Park · rainforest · peat bogs · grasslands · ferns · chimpanzees · birds · biodiversity · Volcanoes National Park and mountain gorillas

Postcard scene: Volcanoes National Park and mountain gorillas

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rw/
- https://whc.unesco.org/en/list/1697/

## Saint Kitts and Nevis · KN

Capital / seat: Basseterre

1. Saint Kitts and Nevis is in Americas. Its capital is Basseterre.

2. Brimstone Hill Fortress records seventeenth- and eighteenth-century Caribbean defensive architecture. Its hilltop setting shows how high ground helped people observe the surroundings.

3. The fortress was designed by the British and built by enslaved Africans. Studying the building also means remembering the lives and dignity of the people who worked there.

4. Brimstone Hill Fortress is on St Kitts. Locate St Kitts and Nevis separately to distinguish two islands within one country.

5. Sketch Brimstone Hill’s slopes and walls in profile. Distinguish the natural hill’s elevation from built wall height to explore the defensive setting.

Explorer words: Basseterre · Brimstone Hill Fortress · Caribbean Sea · hill · defensive architecture · 17th–18th centuries · colonial period · construction labour · human dignity · remembering history

Postcard scene: Brimstone Hill Fortress National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/kn/
- https://whc.unesco.org/en/list/910/

## Saint Lucia · LC

Capital / seat: Castries

1. Saint Lucia is in Americas. Its capital is Castries.

2. Saint Lucia's Pitons are two volcanic peaks rising side by side near the sea. Nearby hot springs and geothermal features show how underground heat affects landscapes.

3. Forests and coral reefs occur around the Pitons. Studying mountain plants alongside marine life reveals that one region can contain several different ecosystems.

4. Coral reefs lie in the waters around the Pitons. Corals may look plant-like, but they are animals; appearance and biological classification are different information.

5. Compare close and distant views of the two Pitons. Apparent size in a picture depends on viewing distance as well as actual dimensions.

Explorer words: Castries · Pitons · Gros Piton · Petit Piton · volcanic peaks · hot springs · geothermal heat · coral reefs · forests · Pitons Management Area

Postcard scene: Pitons Management Area

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lc/
- https://whc.unesco.org/en/list/1161/

## Saint Vincent and the Grenadines · VC

Capital / seat: Kingstown

1. Saint Vincent and the Grenadines is in Americas. Its capital is Kingstown.

2. The botanical gardens near Kingstown feature the St Vincent parrot. This national bird lives naturally in forests on the island of St Vincent.

3. Dark View Falls has two waterfalls descending from cliffs in a forested setting. Studying water, plants and birds together reveals connections within the natural environment.

4. St Vincent’s Vermont Nature Trail crosses mountain forest where island birds can be observed. Comparing a garden with natural forest reveals different settings for studying species.

5. St Vincent and the Grenadines names a country, while St Vincent is its main island. Distinguishing them clarifies Kingstown’s location and neighbouring islands.

Explorer words: Kingstown · St Vincent parrot · botanical gardens · national bird · Dark View Falls · rainforest · cliffs · waterfalls · bird observation · Kingstown and its surroundings

Postcard scene: Kingstown and its surroundings

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://discoversvg.com/what-to-do/eco-adventures/

## Samoa · WS

Capital / seat: Apia

1. Samoa is in Oceania. Its capital is Apia.

2. To Sua Ocean Trench on Upolu is a deep natural pool below ground level. Its water and surrounding landforms reveal an unusual space in the island's landscape.

3. Traditional Samoan fale can have open sides. Looking at their design helps us think about how climate and ways of living influence architecture.

4. Draw Samoa’s To Sua pool from above and in cross-section. Water boundaries and depth below ground are clearer in different kinds of view.

5. A Samoan fale introduces the different roles of columns and walls. Supports can hold a roof to create a covered space with few walls.

Explorer words: Apia · To Sua Ocean Trench · Upolu · natural pool · island landforms · fale · open-sided houses · traditional architecture · climate and housing · Samoan ways of life

Postcard scene: To Sua Ocean Trench

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.samoa.travel/pagepreview/must-dos-in-samoa

## San Marino · SM

Capital / seat: City of San Marino

1. San Marino is in Europe. Its capital is City of San Marino.

2. San Marino's historic centre on Mount Titano contains defensive towers, walls and gates. This hilltop town shows the relationship between terrain and architecture.

3. The historic centre records a republican tradition extending from the Middle Ages. Civic institutions still use the town, showing how heritage can remain part of everyday life.

4. Represent San Marino’s historic centre and Mount Titano with a plan and profile. Together, urban arrangement and elevation explain building positions more fully.

5. San Marino names both country and capital. Distinguishing a city point from national territory helps avoid confusion caused by the shared name.

Explorer words: City of San Marino · Mount Titano · San Marino historic centre · defensive towers · city walls · city gates · Middle Ages · republic · civic institutions · living heritage

Postcard scene: San Marino Historic Centre and Mount Titano

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sm/
- https://whc.unesco.org/en/list/1245/

## São Tomé and Príncipe · ST

Capital / seat: São Tomé

1. São Tomé and Príncipe is in Africa. Its capital is São Tomé.

2. Príncipe is a volcanic island in the Gulf of Guinea. Its landscape helps us explore how volcanic activity can create land rising from the sea.

3. Príncipe's biosphere reserve includes land, surrounding sea and smaller islands. It shows why conservation needs to consider forests, coasts and marine areas together.

4. Map Príncipe’s forests and sea within one conservation diagram. Land boundaries may differ from the spaces used by wildlife, so include the connected coast.

5. Locate São Tomé and Príncipe’s two main islands separately from the capital, São Tomé. Similar country, island and city names can describe different extents.

Explorer words: São Tomé · Príncipe · Gulf of Guinea · volcanic island · island formation · biosphere reserve · land and sea · islets · coast · Pico Cão Grande and São Tomé rainforest

Postcard scene: Pico Cão Grande and São Tomé rainforest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.unesco.org/en/mab/island-principe

## Saudi Arabia · SA

Capital / seat: Riyadh

1. Riyadh is Saudi Arabia’s capital. Saudi Arabia covers a large part of the Arabian Peninsula.

2. At Hegra, the Nabataeans carved tombs into rock about 2,000 years ago.

3. Saudi Arabia has coastlines on both the Red Sea and the Persian Gulf.

4. Hegra preserves decorated façades of rock-cut tombs. Doors and carved patterns in natural cliffs reveal the skills of stoneworkers.

5. Hegra also has inscriptions and rock drawings predating the Nabataean period. Writing and images preserve different kinds of evidence of earlier people.

Explorer words: Riyadh · Hegra · AlUla · Arabian Desert · Red Sea · camel · dates · kabsa · Arabic · Nabataean heritage

Postcard scene: Hegra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1293/

## Senegal · SN

Capital / seat: Dakar

1. Senegal is in Africa. Its capital is Dakar.

2. Djoudj National Bird Sanctuary includes lakes and wetlands in the Senegal River delta. Pelicans, herons and many other birds use its waters to feed and rest.

3. Connected lakes, streams and ponds provide different places for birds. Studying a wetland means considering the whole network of water, rather than just one pond.

4. Djoudj supports pelicans, spoonbills and cormorants. Comparing beak shapes and life near water invites questions about how birds use their environment.

5. Djoudj is an important stop after birds cross the Sahara. Mapping journeys and resting places shows the need for connected migration stopovers.

Explorer words: Dakar · Djoudj National Bird Sanctuary · Senegal River · delta · pelicans · herons · lakes · ponds · wetlands · Lake Retba

Postcard scene: Lake Retba

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sn/
- https://whc.unesco.org/en/list/25/

## Serbia · RS

Capital / seat: Belgrade

1. Serbia is in Europe. Its capital is Belgrade.

2. Studenica Monastery was founded in the late twelfth century. Its two main churches, built with white marble, offer a way to study historic building materials and forms.

3. The churches preserve thirteenth- and fourteenth-century Byzantine paintings. Studying buildings and pictures together reveals how art expressed religious life and ideas.

4. Studenica groups buildings within an almost circular wall. Distinguishing its central church from surrounding living facilities clarifies the monastery’s layout.

5. Studenica preserves refectories and monks’ quarters. Studying religious architecture includes everyday spaces as well as places used for ceremonies.

Explorer words: Belgrade · Studenica Monastery · white marble · 12th century · Byzantine painting · historic churches · building materials · medieval art · religion and art · Kalemegdan Fortress, Belgrade

Postcard scene: Kalemegdan Fortress, Belgrade

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/rs/
- https://whc.unesco.org/en/list/389/

## Seychelles · SC

Capital / seat: Victoria

1. Seychelles is in Africa. Its capital is Victoria.

2. Vallée de Mai on Praslin preserves a largely natural palm forest. The coco de mer palm is known for its exceptionally large seed.

3. Seeds are a starting point for new plants. Comparing palms and their seeds at Vallée de Mai helps us explore different ways that plants reproduce and grow.

4. Vallée de Mai is on Praslin, while Seychelles’s capital, Victoria, is on another island. Locating both clarifies relationships within an island country.

5. Vallée de Mai has other endemic palms alongside coco de mer. Looking beyond one famous plant reveals the diversity of its forest community.

Explorer words: Victoria · Vallée de Mai · Praslin · coco de mer · palm forest · seeds · plant reproduction · tree growth · natural forest · forest conservation

Postcard scene: Vallée de Mai palm forest

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sc/
- https://whc.unesco.org/en/list/261/

## Sierra Leone · SL

Capital / seat: Freetown

1. Sierra Leone is in Africa. Its capital is Freetown.

2. The Gola-Tiwai area combines rainforest with an island in the Moa River. Protecting forest and river together helps wildlife that depends on different habitats.

3. The area shelters animals needing protection, including pygmy hippopotamuses and chimpanzees. Go beyond learning their names to ask why they need forests and water.

4. The wider Gola landscape extends into Liberia. Connecting Sierra Leone’s protected areas with neighbouring forests reveals an ecosystem crossing a national border.

5. Compare seasonal evidence of the Moa River around Tiwai Island. Changes in water conditions can also alter living spaces on islands and riverbanks.

Explorer words: Freetown · Gola-Tiwai · Moa River · river island · rainforest · pygmy hippopotamus · chimpanzee · habitat connections · wildlife conservation · Tacugama chimpanzees

Postcard scene: Tacugama chimpanzees

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sl/
- https://whc.unesco.org/en/list/1746/

## Singapore · SG

Capital / seat: Singapore

1. Singapore is a city-state whose capital shares its name. The Merlion combines a lion’s head with a fish’s body.

2. Singapore Botanic Gardens is a UNESCO World Heritage site where many plants and orchids grow.

3. Hawker centres bring many food stalls together. Dishes such as chicken rice reflect Singapore’s different cultures.

4. Singapore Botanic Gardens supports research, conservation and education as well as enjoyment. Growing plants can serve scientific study alongside creating an attractive garden.

5. Compare the gardens’ historical records with living plants today. Observations and research accumulated over generations can create new knowledge within one garden.

Explorer words: Singapore · Merlion · Marina Bay · Singapore River · Singapore Botanic Gardens · orchids · Gardens by the Bay · hawker centres · chicken rice · Little India

Postcard scene: Supertrees, Gardens by the Bay

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sg/
- https://www.visitsingapore.com/see-do-singapore/recreation-leisure/viewpoints/merlion-park/
- https://www.visitsingapore.com/things-to-do/top-things-to-do/city-in-nature/
- https://www.visitsingapore.com/content/visitsingapore/en/travel-tips/travelling-to-singapore/itineraries/singapore-city-tour-guide/
- https://whc.unesco.org/en/list/1483/

## Slovakia · SK

Capital / seat: Bratislava

1. Slovakia is in Europe. Its capital is Bratislava.

2. The Spiš Castle area preserves medieval defensive and religious buildings. Comparing Romanesque and Gothic styles reveals changes in European architecture.

3. Nearby Levoča contains a walled historic town and the church of St James. Its painted sculptures show that a building can bring together several forms of art.

4. Draw Spiš Castle’s natural rock separately from its built walls. Stony features can have different origins as landforms and constructed structures.

5. Locate Spiš Castle separately from Slovakia’s capital, Bratislava. A famous castle and a present-day political centre need not be in the same place.

Explorer words: Bratislava · Spiš Castle · Levoča · church of St James · Romanesque · Gothic · Middle Ages · defences · painted sculpture · walled town

Postcard scene: Spiš Castle

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sk/
- https://whc.unesco.org/en/list/620/

## Slovenia · SI

Capital / seat: Ljubljana

1. Slovenia is in Europe. Its capital is Ljubljana.

2. Škocjan Caves contain long passages and underground waterfalls within limestone. They reveal karst processes, in which water dissolves and wears away rock.

3. When a cave roof collapses, it can leave a depression at the surface. Studying both above and below ground reveals connected spaces beneath our feet.

4. At Škocjan, the Reka River enters an underground canyon. A dotted line can represent a water route hidden beneath the land surface.

5. Škocjan introduces the distinction between depth and volume. Distance downward and the amount of space within a cavern are different measurements.

Explorer words: Ljubljana · Škocjan Caves · limestone · karst · underground passages · underground waterfalls · rock dissolution · erosion · collapse depressions · underground spaces

Postcard scene: Škocjan Caves

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/si/
- https://whc.unesco.org/en/list/390/

## Solomon Islands · SB

Capital / seat: Honiara

1. Solomon Islands is in Oceania. Its capital is Honiara.

2. Lake Tegano on Rennell Island was once an atoll lagoon. Landscapes can change as coral-built land rises above the sea.

3. The lake contains brackish water, limestone islets and distinctive wildlife. Studying the island's forest and lake together connects geological history with ecosystems.

4. Rennell is an uplifted coral atoll. A marine landform can rise to become land, linking an island’s present appearance with its geological history.

5. East Rennell’s heritage covers part of the island and nearby sea. Similar island and property names do not necessarily describe the same area.

Explorer words: Honiara · Rennell Island · Lake Tegano · former lagoon · raised coral atoll · brackish water · limestone islets · island forest · endemic species · Marovo Lagoon

Postcard scene: Marovo Lagoon

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sb/
- https://whc.unesco.org/en/list/854/

## Somalia · SO

Capital / seat: Mogadishu

1. Somalia is in Africa. Its capital is Mogadishu.

2. Mogadishu is a coastal city historically connected to other regions through Indian Ocean trade. Its historic buildings record encounters between travelling people and cultures.

3. Mogadishu's Secondo-Lido Lighthouse helped ships navigate along the coast. A lighthouse shows how architecture can combine a distinctive appearance with a practical purpose.

4. Mogadishu’s lighthouse introduces light as a navigation signal. It helps indicate direction and coastal position without physically building a route across the sea.

5. The Secondo-Lido Lighthouse appears on a World Heritage Tentative List. A proposed site and an inscribed property represent different stages of the process.

Explorer words: Mogadishu · Indian Ocean trade · coastal city · Secondo-Lido Lighthouse · navigation · historic port · cultural encounters · urban buildings · sea routes · Mogadishu historic coast

Postcard scene: Mogadishu historic coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/tentativelists/6754/

## South Africa · ZA

Capital / seat: Pretoria

Pretoria is the administrative capital, Cape Town the legislative capital, and Bloemfontein the judicial capital.

1. South Africa shares capital-city roles: Pretoria is administrative, Cape Town is legislative, and Bloemfontein is judicial.

2. Table Mountain, with its flat top, rises beside Cape Town.

3. Nelson Mandela worked for democracy against racial discrimination and became South Africa’s first Black president in 1994.

4. Mapungubwe lies where the Limpopo and Shashe rivers meet. Water and fertile surrounding land helped support the life of its earlier society.

5. Mapungubwe connected with trade reaching East Africa, India and China. An inland settlement can link with distant regions through connected routes.

Explorer words: Pretoria · Cape Town · Table Mountain · Kruger National Park · Robben Island · African penguin · springbok · Nelson Mandela · rooibos tea · South African Sign Language

Postcard scene: Table Mountain & Cape Town

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1099/

## South Sudan · SS

Capital / seat: Juba

1. South Sudan is in Africa. Its capital is Juba.

2. The Sudd wetlands stretch along the White Nile in South Sudan, with broad landscapes of water and vegetation.

3. Papyrus and reeds grow in the Sudd. Open water and richly vegetated wetland areas lie together.

4. The flooded extent of the Sudd changes with the seasons. Comparing seasonal maps reveals water–land relationships beyond what one map can show.

5. The Sudd provides living spaces for waterbirds and fish. Drawing above and below the surface includes aquatic life that may be less visible.

Explorer words: Juba · Africa · Sudd wetlands · White Nile · Papyrus · Reeds · wetland ecosystem · aquatic plants · habitats · water and plants

Postcard scene: Sudd wetlands on the White Nile

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ss/
- https://whc.unesco.org/en/tentativelists/6276/

## Spain · ES

Capital / seat: Madrid

1. Madrid is Spain’s capital. The Sagrada Família is a church in Barcelona designed by Antoni Gaudí.

2. Columns inside the Sagrada Família branch like tree trunks. Gaudí studied natural forms to design structures that support the building’s weight.

3. Along with Spanish, Catalan, Basque and Galician are spoken in different parts of Spain.

4. Granada’s Alhambra includes palaces and fortifications of the Nasrid dynasty. Comparing it with Gaudí’s Barcelona architecture reveals different periods and traditions within Spain.

5. Water shapes the gardens of the Alhambra and Generalife. Linking channels with planting areas helps explain the conditions needed to create a garden.

Explorer words: Madrid · Sagrada Família · Barcelona · Pyrenees · Mediterranean Sea · flamenco · paella · olives · Catalan · Galician

Postcard scene: Sagrada Família

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://blog.sagradafamilia.org/en/columns-sagrada-familia-geometry-mechanics-materials-stone-forest/
- https://whc.unesco.org/en/list/314/

## Sri Lanka · LK

Capital / seat: Sri Jayewardenepura Kotte

Sri Jayewardenepura Kotte is the legislative capital; many government offices are in Colombo.

1. Sri Jayewardenepura Kotte is the legislative capital; many government offices are in Colombo.

2. Sigiriya preserves a historic city built on and around a granite rock about 180 metres high. It shows how builders used a dramatic elevated landform.

3. The approach includes stairs and remains of a large lion-shaped structure. Rock, brick and plaster together reveal the meeting of a natural landscape with architecture.

4. Sigiriya preserves water gardens and evidence of landscape design. Looking beyond the high rock to the gardens below reveals more of the ancient settlement.

5. Sigiriya’s lion imagery distinguishes a living animal from an animal used as a symbol. Architectural images can communicate people’s ideas.

Explorer words: Sri Jayewardenepura Kotte · Sigiriya · granite · Lion Rock · historic city · high ground · staircases · bricks · plaster · nature and architecture

Postcard scene: Sigiriya

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/lk/
- https://www.gov.lk/sri-lanka/country-overview
- https://whc.unesco.org/en/list/202/

## Sudan · SD

Capital / seat: Khartoum

1. Sudan is in Africa. Its capital is Khartoum.

2. Meroe was a centre of the Kingdom of Kush. Its pyramids, temples and residential remains show that the Nile region held civilisations beyond ancient Egypt.

3. The surrounding archaeological sites also preserve water-management structures. Collecting and using water was important to the growth of towns in this dry region.

4. Meroe’s heritage includes the royal city, burial areas, Naqa and Musawwarat es-Sufra. Several sites together record different aspects of the former kingdom.

5. Compare Meroe’s pyramids with Egyptian ones while distinguishing cultural and historical settings. Similar shapes do not mean identical communities or histories.

Explorer words: Khartoum · Meroe · Kingdom of Kush · pyramids · Nile River · Atbara River · historic temples · residential remains · water management · dry region

Postcard scene: Meroë pyramids

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sd/
- https://whc.unesco.org/en/list/1336/

## Suriname · SR

Capital / seat: Paramaribo

1. Suriname is in Americas. Its capital is Paramaribo.

2. Paramaribo's historic centre combines Dutch architectural influences with local materials and techniques. A style can take different forms through local conditions and craftsmanship.

3. Paramaribo preserves a street layout inherited from its seventeenth- and eighteenth-century town. Streets and a whole town, as well as individual buildings, can be historical evidence.

4. Paramaribo’s historic centre has many wooden buildings. Comparing them with stone-built European towns shows how related architectural influences can use different local materials.

5. Paramaribo lies along the Suriname River. Mapping river, fort and grid streets together explains an urban structure beyond individual buildings.

Explorer words: Paramaribo · historic Paramaribo · local materials · building techniques · Dutch architecture · craftspeople · street layout · 17th–18th centuries · urban history · cultural encounters

Postcard scene: Paramaribo

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sr/
- https://whc.unesco.org/en/list/940/

## Sweden · SE

Capital / seat: Stockholm

1. Sweden’s capital, Stockholm, spreads across many islands connected by bridges.

2. In northern Sweden, summer nights are very bright, and the northern lights can appear in winter.

3. Stockholm’s Vasa Museum displays a huge ship built in the 1600s.

4. Grimeton’s radio station sent communications across the Atlantic. Signals carried information over a long distance without a person crossing the sea.

5. Six large towers support Grimeton’s antenna system. Compare the journey of a letter carried by ship with information transmitted by radio.

Explorer words: Stockholm · Gamla Stan · Vasa ship · northern lights · forests · moose · cinnamon bun · meatballs · Swedish · Dala horse

Postcard scene: Gamla Stan, Stockholm

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/1134/

## Switzerland · CH

Capital / seat: Bern

Bern is Switzerland’s federal city and the seat of its federal government.

1. Bern is Switzerland’s federal city and seat of government. It is commonly described as the capital, while its official title is federal city.

2. Switzerland has the Alps, the Jura Mountains and a plateau between them. Mountain railways reach high into the Alps.

3. Switzerland has four national languages: German, French, Italian and Romansh. Language use varies by region.

4. The Albula and Bernina railway uses tunnels and bridges through difficult Alpine terrain. Compare routes around mountains with routes passing through them.

5. Represent the railway with a map and a side profile. One shows its route; the other shows changes in elevation along the same journey.

Explorer words: Bern · federal city · Alps · Jura Mountains · Swiss Plateau · mountain railways · German · French · Italian · Romansh

Postcard scene: Zytglogge, Bern

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ch/
- https://www.aboutswitzerland.eda.admin.ch/en/political-system
- https://www.aboutswitzerland.eda.admin.ch/en/geography
- https://www.aboutswitzerland.eda.admin.ch/en/languages-and-dialects
- https://whc.unesco.org/en/list/1276/

## Syria · SY

Capital / seat: Damascus

1. Syria is in Asia. Its capital is Damascus.

2. Bosra preserves a large Roman theatre from the second century. Its curved rows of seats help us imagine a space where people gathered to watch performances.

3. Bosra was an important stop on historic caravan routes towards Mecca. Its theatre and religious buildings record people and cultures passing through across different periods.

4. Bosra’s name appears in ancient diplomatic records. Buildings and written documents provide different kinds of evidence for studying a city.

5. Draw Bosra’s audience seating separately from its performance area. Explore arrangements designed so many people can watch the same scene.

Explorer words: Damascus · Bosra · Roman theatre · 2nd century · curved seating · performances · caravan trade · Mecca · religious architecture · Ancient City of Bosra

Postcard scene: Ancient City of Bosra

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/sy/
- https://whc.unesco.org/en/list/22/

## Taiwan · TW

Capital / seat: Taipei

1. Taiwan is in Asia. Its capital is Taipei.

2. Taipei 101 contains a large suspended mass that reduces movement caused by wind. This tuned mass damper helps make a tall building more comfortable to use.

3. The observatory looks across Taipei's rivers, basin and surrounding mountains. A high viewpoint helps us explore the relationship between a city's buildings, water and terrain.

4. Taipei 101’s large damping sphere is assembled from layers of steel plate. What appears to be one ball records a process of joining smaller material elements.

5. Taipei 101’s elevators introduce height and speed. How high a destination is differs from how far an elevator moves in a given time.

Explorer words: Taipei · Taipei 101 · tuned mass damper · reducing sway · wind · tall buildings · observatory · Taipei basin · urban rivers · surrounding mountains

Postcard scene: Taipei 101 and Taipei basin

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://www.taipei-101.com.tw/en/observatory/feature
- https://www.taipei-101.com.tw/en/observatory/feature/damper

## Tajikistan · TJ

Capital / seat: Dushanbe

1. Tajikistan is in Asia. Its capital is Dushanbe.

2. Tajik National Park in the Pamirs contains high peaks, plateaux and many glaciers. Its environment reveals how mountain height and seasons influence temperature.

3. The park brings together glaciers, rivers and lakes. Following the connection from snow and ice to flowing water helps us explore the relationship between mountains and water.

4. The Pamirs combine high eastern plateaus with rugged western peaks. High elevation alone does not distinguish a broad plateau from a steep summit.

5. The Pamirs connect with movements where large tectonic plates meet. Mountain height reflects uplift as well as erosion by water and wind.

Explorer words: Dushanbe · Pamirs · Tajik National Park · plateaux · glaciers · high peaks · seasonal temperature · rivers · mountain lakes · Iskanderkul

Postcard scene: Iskanderkul

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tj/
- https://whc.unesco.org/en/list/1252/

## Tanzania · TZ

Capital / seat: Dodoma

1. Tanzania’s capital, Dodoma, is near the center of the country.

2. Mount Kilimanjaro is the highest mountain in Africa.

3. Many animals travel across the grasslands of northern Tanzania’s Serengeti.

4. Tanzania’s Selous includes woodland, grassland and wetlands. Comparing it with Serengeti grasslands reveals different protected environments within one country.

5. Selous supports water-associated animals such as hippos and crocodiles. Mapping land and water together gives a fuller picture of their habitats.

Explorer words: Dodoma · Mount Kilimanjaro · Serengeti · savanna · baobab tree · elephant · Swahili · Zanzibar · ugali · coffee

Postcard scene: Mount Kilimanjaro

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/199/

## Thailand · TH

Capital / seat: Bangkok

1. Thailand’s capital, Bangkok, is home to a grand palace and the Chao Phraya River.

2. Thailand’s landscapes range from northern mountains and forests to warm southern seas.

3. Songkran is a festival when families and neighbors celebrate the Thai New Year together.

4. Sukhothai was an earlier Thai capital. Mapping it separately from Bangkok shows how a country’s political centre can change over time.

5. Sukhothai’s architecture and art combine local traditions with influences from elsewhere. Cultural encounters can lead to new forms of expression.

Explorer words: Bangkok · Grand Palace · Chao Phraya River · Chiang Mai · Asian elephant · pad thai · mango sticky rice · tuk-tuk · Thai · Songkran

Postcard scene: Grand Palace

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/574/

## Timor-Leste · TL

Capital / seat: Dili

1. Timor-Leste is in Asia. Its capital is Dili.

2. Timor-Leste's tais is a traditional handwoven textile. Preparing cotton, dyeing it with plants and weaving it require time and skill.

3. Tais colours and motifs vary between communities, and the cloth is used in clothing, ceremonies and festivals. Its patterns reveal culture expressed through everyday objects.

4. Draw threads crossing in different directions when studying tais. Surface patterns and the structure of interlaced threads are different features of one textile.

5. Tais traditions continue by teaching weaving to new generations. Preserving an old textile and making a new one are different parts of cultural continuity.

Explorer words: Dili · tais · handweaving · cotton · plant dyes · textile motifs · colours · traditional clothing · festivals · Dili and Cristo Rei hill

Postcard scene: Dili and Cristo Rei hill

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://ich.unesco.org/en/USL/tais-traditional-textile-01688

## Togo · TG

Capital / seat: Lomé

1. Togo is in Africa. Its capital is Lomé.

2. The Batammariba of Koutammakou build tower-like earth houses called takienta. Their design reveals both building knowledge and the community's ways of living.

3. Villages here include fields, forests, springs and ceremonial spaces. Studying homes together with their surroundings helps us understand a cultural landscape.

4. Koutammakou extends from Togo into neighbouring Benin. Its map shows how a community’s traditions continue across a modern national border.

5. Draw a Koutammakou house in plan and profile. Adding internal arrangement to its tower-like outline gives a fuller understanding of residential architecture.

Explorer words: Lomé · Koutammakou · Batammariba · takienta · earth houses · tower-houses · fields · springs · ceremonial spaces · cultural landscape

Postcard scene: Koutammakou and Batammariba earth houses

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tg/
- https://whc.unesco.org/en/list/1140/

## Tonga · TO

Capital / seat: Nuku'alofa

1. Tonga is in Oceania. Its capital is Nuku'alofa.

2. Haʻamonga ʻa Maui on Tongatapu is a historic gateway made from three large stones. Two uprights support a crosspiece, inviting us to explore structure and balance.

3. Tongan culture includes traditional dance and a long royal heritage. History survives not only in stone monuments but also in dances and performances passed between generations.

4. Draw Haʻamonga ʻa Maui’s supports separately from its horizontal stone. Compare the spanning element with the parts carrying its load from below.

5. Tonga’s lakalaka combines dance, spoken expression and singing. Performers arranged in rows connect sound and gesture within a shared cultural performance.

Explorer words: Nuku'alofa · Haʻamonga ʻa Maui · Tongatapu · stone gateway · three stones · uprights · crosspiece · balance · traditional dance · royal heritage

Postcard scene: Haʻamonga ʻa Maui

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://thekingdomoftonga.com/true-culture/
- https://ich.unesco.org/en/RL/lakalaka-dances-and-sung-speeches-of-tonga-00072?RL=00072
- https://ich.unesco.org/en/projects/safeguarding-of-lakalaka-sung-speeches-with-choreographed-movements-00016

## Trinidad and Tobago · TT

Capital / seat: Port of Spain

1. Trinidad and Tobago is in Americas. Its capital is Port of Spain.

2. The steelpan, developed in Trinidad and Tobago, is a metal percussion instrument. Striking different areas of its surface produces notes of different pitches.

3. The steelpan developed in the 1930s and 1940s and is the national instrument. Its history of transforming metal containers into instruments links music with creative making.

4. A steelpan produces sound through vibrating metal. Comparing it with a drum’s stretched surface reveals different sound-producing materials and structures within percussion.

5. Listen to steelpan notes and distinguish pitch from loudness. These are different properties: a higher note is not necessarily louder.

Explorer words: Port of Spain · steelpan · percussion instrument · metal · pitch · vibration · national instrument · 1930s–1940s · instrument making · Trinidad Carnival

Postcard scene: Trinidad Carnival

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://foreign.gov.tt/about/trinidad-tobago/national-symbols/national-instrument/

## Tunisia · TN

Capital / seat: Tunis

1. Tunisia is in Africa. Its capital is Tunis.

2. Carthage was founded on the Gulf of Tunis and grew into a Mediterranean trading centre. It shows how a harbour city connects distant regions through sea routes.

3. After the earlier Carthage was destroyed, a Roman city was built on the same site. Comparing remains from different periods reveals how a town can be rebuilt over time.

4. Locate Tunisia, Tunis and Carthage separately. Similar names describe a country, a present city and an ancient site, each with a different extent.

5. Place Carthage’s evidence from different periods on a coloured timeline. Compare several traces rather than using one building to represent every era.

Explorer words: Tunis · Carthage · Gulf of Tunis · Mediterranean trade · harbour city · sea routes · Roman period · urban rebuilding · comparing remains · archaeology

Postcard scene: Carthage

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tn/
- https://whc.unesco.org/en/list/37/

## Türkiye · TR

Capital / seat: Ankara

1. Ankara is Türkiye’s capital. Istanbul stretches across Europe and Asia on the Bosphorus.

2. Istanbul’s Hagia Sophia is an old landmark that has been used in different eras.

3. Türkiye has coastlines, high mountains and the unusual rock landscapes of Cappadocia.

4. Troy preserves successive settlements in overlapping layers. One site name can contain a long history of rebuilding homes and walls.

5. Troy is also associated with Homer’s stories. Distinguishing literary narratives from excavated objects helps explain the relationship between imagination and historical research.

Explorer words: Ankara · Istanbul · Hagia Sophia · Bosphorus · Cappadocia · Turkish · simit · baklava · tea · Mediterranean Sea

Postcard scene: Hagia Sophia & Blue Mosque

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/849/

## Turkmenistan · TM

Capital / seat: Ashgabat

1. Turkmenistan is in Asia. Its capital is Ashgabat.

2. Merv was an oasis city on the Central Asian Silk Roads. Where water and routes met in a dry region, people settled and exchanged goods.

3. Merv preserves traces of settlements across a long period. Walls and building locations reveal how urban life changed repeatedly around the same oasis.

4. Merv’s cities connect with the Murgab oasis. Mapping water sources alongside dryland trade routes explains relationships between settlement and movement.

5. Locate Merv separately from today’s capital, Ashgabat. Distinguish an earlier trading centre from a present political centre by location and period.

Explorer words: Ashgabat · Merv · Silk Roads · oasis · Central Asia · dry region · historic walls · trade · settlement remains · Ancient Merv

Postcard scene: Ancient Merv

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/tm/
- https://whc.unesco.org/en/list/886/

## Tuvalu · TV

Capital / seat: Funafuti

The capital Funafuti is an atoll made up of several islands. The pin marks Vaiaku on Fongafale, where government offices are located.

1. The capital Funafuti is an atoll made up of several islands. The pin marks Vaiaku on Fongafale, where government offices are located.

2. Tuvalu consists of nine low-lying coral islands in the Pacific. Several contain lagoons surrounded by reefs, revealing close connections between islands and sea.

3. A lagoon is a coastal body of water connected with the sea. Life on low islands invites us to consider reef and coastal care and cooperation on climate change.

4. Tuvalu lies with Kiribati to its north and Fiji to its south. Neighbouring island countries help locate small islands within the broad Pacific.

5. Study Tuvalu’s land and surrounding sea on maps at different scales. Broad and detailed views communicate different ranges of information about the same region.

Explorer words: Funafuti · coral islands · lagoons · coral reefs · Pacific Ocean · low-lying land · islands and sea · coastal care · climate change · Funafuti Conservation Area

Postcard scene: Funafuti Conservation Area

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://finance.gov.tv/contact-us/
- https://finance.gov.tv/wp-content/uploads/2023/11/181024-TvICT-ESMP-Rev-G-2.pdf
- https://thecommonwealth.org/our-member-countries/tuvalu

## Uganda · UG

Capital / seat: Kampala

1. Uganda is in Africa. Its capital is Kampala.

2. Bwindi National Park lies where lowland and mountain forests meet. Many trees, ferns, birds and butterflies live across its varied forest environments.

3. Bwindi is also habitat for endangered mountain gorillas. Protecting these animals requires caring for the forest that provides their food and homes.

4. Researchers study Bwindi’s probable role as a refuge during past climatic changes. Studying today’s forest connects with research into earlier environments and species distributions.

5. Record individual animals separately from social groups in Bwindi gorilla observation material. One animal and a group of animals are different counting units.

Explorer words: Kampala · Bwindi National Park · mountain gorilla · lowland forest · mountain forest · ferns · butterflies · birds · endangerment · Bwindi Impenetrable National Park

Postcard scene: Bwindi Impenetrable National Park

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ug/
- https://whc.unesco.org/en/list/682/

## Ukraine · UA

Capital / seat: Kyiv

1. Ukraine is in Europe. Its capital is Kyiv.

2. Kyiv's Saint-Sophia Cathedral records the city's eleventh-century history. Its connection with a cathedral in Constantinople reveals cultural links between distant cities.

3. Kyiv-Pechersk Lavra is a historic monastery with religious and intellectual influence. Comparing it with the cathedral reveals different roles for buildings within one city.

4. Kyiv’s Saint-Sophia Cathedral contains mosaics and wall paintings. Comparing assembled pieces with painted images introduces different techniques within one interior.

5. Saint-Sophia and Pechersk Lavra are separate heritage components. A combined property name does not necessarily describe one building, so locate each area.

Explorer words: Kyiv · Saint-Sophia Cathedral · Kyiv-Pechersk Lavra · 11th century · Constantinople · cultural connections · monastery · religious architecture · history of learning · building functions

Postcard scene: Saint Sophia Cathedral, Kyiv

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ua/
- https://whc.unesco.org/en/list/527/

## United Arab Emirates · AE

Capital / seat: Abu Dhabi

1. The United Arab Emirates is a federation of seven emirates. Abu Dhabi is the capital; Dubai is a city in another emirate.

2. Abu Dhabi has the Sheikh Zayed Grand Mosque, while Dubai is home to the tall Burj Khalifa.

3. The UAE has both deserts and a coast. Al Ain has oases and historic cultural sites.

4. Al Ain’s aflaj irrigation includes channels running partly underground. Different lines for surface and underground routes can represent watercourses hidden from view.

5. Al Ain preserves circular stone tombs and earthen building remains. Recording shape and material separately allows closer comparisons between historic structures.

Explorer words: Abu Dhabi · Dubai · seven emirates · Sheikh Zayed Grand Mosque · Burj Khalifa · Al Ain Oasis · Arabian Peninsula · desert · coast · Arabic

Postcard scene: Al Ain Oasis and falaj irrigation

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ae/
- https://u.ae/en/about-the-uae/fact-sheet
- https://u.ae/en/about-the-uae/the-seven-emirates
- https://whc.unesco.org/en/list/1343/

## United Kingdom · GB

Capital / seat: London

1. London is the UK’s capital. Big Ben is the bell inside the Elizabeth Tower.

2. The United Kingdom is made up of England, Scotland, Wales and Northern Ireland.

3. The River Thames flows through London, where red double-decker buses are a familiar sight.

4. Stonehenge and Avebury preserve stones erected by prehistoric communities. Stone arrangements and excavated objects provide evidence even when written records are scarce.

5. Researchers compare Stonehenge’s arrangement with movements in the sky. Distinguish observed evidence from unresolved meanings, and turn remaining uncertainties into questions.

Explorer words: London · Big Ben · River Thames · England · Scotland · Wales · Northern Ireland · double-decker bus · English · fish and chips

Postcard scene: Elizabeth Tower & Parliament

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/373/

## United States · US

Capital / seat: Washington D.C.

1. Washington, D.C. is the U.S. capital, and the country has 50 states.

2. Mount Rushmore is a mountain carving of four U.S. presidents in South Dakota.

3. The U.S. has many landscapes, from the Grand Canyon and Mississippi River to the islands of Hawaii.

4. Mesa Verde preserves stone dwellings built by Ancestral Pueblo communities near cliffs. Homes and storage spaces show ways of using natural terrain for everyday life.

5. Everyday objects at Mesa Verde are important evidence alongside buildings. Separating what was found from what it suggests introduces the reasoning used in archaeology.

Explorer words: Washington, D.C. · Mount Rushmore · Grand Canyon · Mississippi River · Alaska · Hawaii · 50 states · jazz · baseball · hamburger

Postcard scene: Mount Rushmore

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/27/

## Uruguay · UY

Capital / seat: Montevideo

1. Montevideo is Uruguay’s capital. The city stands beside the wide Río de la Plata estuary.

2. Montevideo’s Rambla follows the waterfront, offering places to walk, cycle and see the coast.

3. Candombe is drum music and dance rooted in communities of African descent. Several Montevideo neighbourhoods keep the tradition alive.

4. Fray Bentos preserves facilities for food processing, refrigeration and export. Their arrangement records stages of turning raw materials into food sent abroad.

5. Fray Bentos also preserves workers’ housing. Connecting factory machinery with nearby homes reveals how a workplace shaped urban life.

Explorer words: Montevideo · Río de la Plata · Rambla · candombe · drums · Sur district · Palermo district · Cordón district · estuary · Spanish

Postcard scene: Montevideo coast

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uy/
- https://montevideo.gub.uy/areas-tematicas/amiga-del-futbol/descubri-montevideo
- https://www.montevideo.gub.uy/areas-tematicas/cultura-y-tiempo-libre/parques/rambla
- https://ich.unesco.org/en/RL/candombe-and-its-socio-cultural-space-a-community-practice-00182
- https://whc.unesco.org/en/list/1464/

## Uzbekistan · UZ

Capital / seat: Tashkent

1. Tashkent is Uzbekistan’s capital. Samarkand and Bukhara were meeting places for cultures along the Silk Roads.

2. Samarkand has historic mosques and great squares, with blue tilework decorating its buildings.

3. Palov is a rice-based dish. Sharing it with guests and neighbours is an important living tradition.

4. Ulugh Beg’s observatory in Samarkand was a place for studying the sky. An old trading city could also be a centre of scientific learning.

5. Samarkand’s Afrasiab remains include evidence of residential life. Everyday spaces help explain urban history alongside grand squares and monuments.

Explorer words: Tashkent · Samarkand · Bukhara · Itchan Kala · Silk Roads · Registan Square · blue tilework · palov · oasis · Uzbek

Postcard scene: Registan, Samarkand

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/uz/
- https://whc.unesco.org/en/list/603/
- https://ich.unesco.org/en/RL/palov-culture-and-tradition-01166

## Vanuatu · VU

Capital / seat: Port Vila

1. Vanuatu is in Oceania. Its capital is Port Vila.

2. Chief Roi Mata's heritage survives on Efate, Lelepa and Artok. His residence and related places record a history extending across several islands.

3. Roi Mata's history is studied through both oral tradition and archaeology. Comparing people's remembered stories with physical remains gives us different ways to learn about the past.

4. Roi Mata’s heritage includes his residence, place of death and burial site. Connecting places in chronological order offers a way to study one person’s history.

5. Map Roi Mata’s story across Efate, Lelepa and Artok. Locating narrative places connects the sequence of events with geographical relationships.

Explorer words: Port Vila · Chief Roi Mata · Efate · Lelepa · Artok · historic residence · oral tradition · archaeology · historical evidence · Mount Yasur

Postcard scene: Mount Yasur

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/vu/
- https://whc.unesco.org/en/list/1280/

## Vatican City · VA

Capital / seat: Vatican City

1. Vatican City is in Europe. Its capital is Vatican City.

2. Vatican City brings together St Peter's Basilica, its square, palaces and gardens. A small state can contain a long history of architecture and art.

3. Artists including Michelangelo and Bernini contributed to the basilica and its surroundings. A major building can be the result of many people's designs and skills.

4. Vatican City is a small independent state within Rome. Distinguishing the surrounding city from a national boundary shows how a country can lie inside a city.

5. Columns frame St Peter’s Square. Architecture can shape outdoor gathering spaces as well as rooms enclosed beneath a roof.

Explorer words: Vatican City · St Peter's Basilica · St Peter's Square · Michelangelo · Bernini · palaces · gardens · colonnades · architecture and art · artistic collaboration

Postcard scene: Vatican City

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/va/
- https://whc.unesco.org/en/list/286/

## Venezuela · VE

Capital / seat: Caracas

1. Caracas is Venezuela’s capital. Venezuela lies in northern South America and has a Caribbean coast.

2. Angel Falls is in Canaima National Park, where water drops a long distance from a high cliff.

3. Canaima has flat-topped mountains called tepuis. Its distinctive landforms and wildlife are protected as World Heritage.

4. Canaima lies in Venezuela’s border region with Guyana and Brazil. Mapping park limits alongside national boundaries distinguishes natural features from political geography.

5. Draw a tepui’s flat summit and steep sides separately. Adding water flowing towards an edge links the shape of the land with high waterfalls.

Explorer words: Caracas · Canaima National Park · Angel Falls · tepuis · Auyán-tepui · highlands · waterfalls · cliffs · Caribbean Sea · Spanish

Postcard scene: Angel Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ve/
- https://whc.unesco.org/en/list/701/
- https://whc.unesco.org/document/218578

## Vietnam · VN

Capital / seat: Hanoi

1. Vietnam’s capital, Hanoi, is near the Red River, while Ho Chi Minh City is in the south.

2. Ha Long Bay has many limestone islands and rocks rising out of the sea.

3. Tết is Vietnam’s Lunar New Year festival, when families gather to welcome the new year.

4. Water has shaped the limestone landscape of Ha Long Bay and Cat Ba. Over long periods, rock can dissolve and erode into islands and caves.

5. Draw Ha Long Bay’s islands from above and from the side. One view shows their arrangement; the other reveals rock heights and outlines.

Explorer words: Hanoi · Ha Long Bay · Red River · Mekong River · rice fields · phở · bánh mì · Vietnamese · Tết · water puppetry

Postcard scene: Ha Long Bay

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/list/672/

## Yemen · YE

Capital / seat: Sana'a

1. Yemen is in Asia. Its capital is Sana'a.

2. Sana'a's old city lies in a high mountain valley and has been inhabited for a long time. Its setting offers a comparison with the environment of coastal towns.

3. Sana'a contains multi-storey tower-houses built with rammed earth. Using locally available material for substantial buildings reveals the knowledge of earlier builders.

4. Sana’a’s tower houses combine stone ground floors with earth and brick above. Drawing materials by level reveals construction beneath the visible façade.

5. Gardens lie among Sana’a’s dense buildings. Comparing a plan of houses with one including green spaces explores the role of open land in a city.

Explorer words: Sana'a · Old City of Sana'a · mountain valley · tower-houses · rammed earth · multiple storeys · local materials · historic architecture · urban setting · long-inhabited settlement

Postcard scene: Old City of Sana'a

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/ye/
- https://whc.unesco.org/en/list/385/

## Zambia · ZM

Capital / seat: Lusaka

1. Zambia is in Africa. Its capital is Lusaka.

2. Victoria Falls is where the Zambezi River plunges into basalt gorges. Falling water and worn rock help us study how water reshapes a landscape.

3. Sunlight can create rainbows in the spray rising from the falls. This heritage shared by Zambia and Zimbabwe also teaches us about cooperation across borders.

4. Victoria Falls’s heritage includes park areas in Zambia and Zimbabwe. Distinguish the falls themselves from the wider landscape managed around them.

5. Draw separate lines for Victoria Falls’s width and drop. A waterfall’s breadth and height describe dimensions in different directions.

Explorer words: Lusaka · Victoria Falls · Mosi-oa-Tunya · Zambezi River · basalt · gorges · water spray · rainbows · erosion · cross-border cooperation

Postcard scene: Victoria Falls

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zm/
- https://whc.unesco.org/en/list/509/

## Zimbabwe · ZW

Capital / seat: Harare

1. Zimbabwe is in Africa. Its capital is Harare.

2. Great Zimbabwe preserves a historic city of the Shona civilisation. Remains of this eleventh- to fifteenth-century trading centre reveal part of Africa's urban history.

3. The site's large stone walls preserve historic building skills. Observing their stones and curves helps us explore how people created major spaces using local materials.

4. Great Zimbabwe includes hill ruins, the Great Enclosure and valley ruins. Linking spaces across different elevations explains the whole historic city’s arrangement.

5. Distinguish Great Zimbabwe from today’s capital, Harare. An ancient site important to a country’s history need not occupy its present capital’s location.

Explorer words: Harare · Great Zimbabwe · Shona civilisation · stone walls · 11th–15th centuries · trading centre · curved walls · building skills · local materials · African urban history

Postcard scene: Great Zimbabwe stone enclosure

Sources:

- https://github.com/mledoze/countries
- https://api.worldbank.org/v2/country?format=json&per_page=400
- https://whc.unesco.org/en/statesparties/zw/
- https://whc.unesco.org/en/list/364/

## Greenland · GL

Capital / seat: Nuuk

Self-governing territory

Greenland is a self-governing territory within the Kingdom of Denmark. Its capital is Nuuk, distinct from Copenhagen in Denmark.

1. Greenland’s capital is Nuuk on the west coast. Greenland has its own self-government within the Kingdom of Denmark. Find Nuuk and Denmark’s capital, Copenhagen, separately on the map.

2. At Ilulissat Icefjord, shown in the postcard, large icebergs gather after breaking away from a glacier. A glacier is ice on land; an iceberg is a piece that has broken off and floats in the sea. Trace the channels between the icebergs.

3. Greenland’s flag has white and red bands and a disc whose colours reverse those of the background. Artist Thue Christiansen designed it. Compare the top and bottom colours of the disc with the bands while colouring.

4. Greenland is a large island in North America’s Arctic region. Antarctica lies near the opposite pole. Point to the Arctic and Antarctic on a globe, then explain which one is closer to Greenland.

5. In northern Greenland, the midnight sun can stay above the horizon through summer nights. In Nuuk, northern lights may appear on dark nights. Remember that a bright midnight-sun sky and an aurora in a dark sky are different scenes.

Explorer words: Nuuk · Ilulissat Icefjord · icebergs · glacier · fjord · Arctic region · self-government · Erfalasorput · midnight sun · northern lights

Postcard scene: Ilulissat Icefjord

Sources:

- https://www.norden.org/en/information/facts-about-greenland
- https://visitgreenland.com/destinations/nuuk/
- https://whc.unesco.org/en/list/1149/
- https://erfalasorput.gl/da/erfalasortaarsimanerup-paasissutissartaa/
- https://visitgreenland.com/activities/northern-lights/
- https://visitgreenland.com/plan-your-trip/best-time-to-visit/

## Antarctica · AQ

Capital / seat: None

Continent · Unofficial symbol

Antarctica is a continent, not a country, and has no capital. The map pin marks King Sejong research station, not a capital.

1. Antarctica is the continent at Earth’s southern end. It is not a country, so it has no capital and no permanent resident population. Researchers from many countries stay at scientific stations to study ice, oceans and weather.

2. The blue design with a white Antarctic outline is an unofficial symbol for Antarctica. The dark blue design with a polar grid and Antarctic map is the Antarctic Treaty emblem. Neither is presented as an official national flag.

3. Gentoo penguins live around the Antarctic Peninsula, as in this postcard. Look for the white patch above their eyes and their orange beaks. Penguins cannot fly, but swim well. Icebergs and rocky shores make different resting places and landscapes.

4. Scientists drill long cylinders of Antarctic ice called ice cores. Ancient air trapped inside helps them learn about the atmosphere in the past. Draw layers of ice and distinguish older layers below from newer ones above.

5. The Antarctic Treaty supports peaceful use of Antarctica and cooperation in scientific research. Korea’s King Sejong Station is on King George Island. The map pin marks this research station; it does not represent an Antarctic capital.

Explorer words: Antarctic continent · Antarctic Peninsula · gentoo penguin · icebergs · rocky coast · Antarctic Treaty · King Sejong Station · King George Island · ice cores · scientific cooperation

Postcard scene: Antarctic Peninsula icebergs and gentoo penguins

Sources:

- https://www.ats.aq/e/antarctictreaty.html
- https://www.ats.aq/devAS/Meetings/Measure?id=289&lang=e
- https://legacy.bas.ac.uk/about_antarctica/wildlife/birds/penguins/gentoo.php
- https://www.bas.ac.uk/data/our-data/publication/ice-core-records-of-atmospheric-carbon-dioxide/
- https://eng.kopri.re.kr/eng/html/infra/03010101.html
- https://www.bas.ac.uk/data/our-data/publication/high-resolution-spatial-mapping-of-human-footprint-across-antarctica-and-its-implications-for-the-strategic-conservation-of-avifauna/
